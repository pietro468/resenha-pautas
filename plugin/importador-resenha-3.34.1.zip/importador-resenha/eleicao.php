<?php
/**
 * Eleição 2026: apuração ao vivo com os dados oficiais do TSE.
 *
 * - Página /apuracao/ (Brasil, estado e cidade; presidente, governador, senador, deputados).
 * - Página inicial de eleição (liga e desliga sozinha no modo automático).
 * - Frase do dia no fim da página inicial (sempre, não só na eleição).
 *
 * Os números vêm de https://resultados.tse.jus.br (arquivos públicos do TSE).
 * O servidor do site busca cada arquivo no máximo a cada 30 segundos e guarda uma cópia,
 * então os visitantes nunca acessam o TSE diretamente.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RRI_EL_TSE', 'https://resultados.tse.jus.br/oficial' );
define( 'RRI_EL_INICIO', '2026-10-04 05:00' );  // página inicial de eleição liga
define( 'RRI_EL_URNAS', '2026-10-04 17:00' );   // urnas fecham, resultados começam
define( 'RRI_EL_FIM', '2026-10-06 00:00' );     // fim do dia do 1º turno
define( 'RRI_EL_T2_INICIO', '2026-10-25 05:00' ); // dia do 2º turno
define( 'RRI_EL_T2_URNAS', '2026-10-25 17:00' );
define( 'RRI_EL_T2_FIM', '2026-10-27 00:00' );

function rri_el_ts( $s ) { return ( new DateTimeImmutable( $s, new DateTimeZone( 'America/Sao_Paulo' ) ) )->getTimestamp(); }
function rri_el_opt() { return wp_parse_args( (array) get_option( 'rri_el', array() ), array( 'modo' => 'auto' ) ); }

/** modo desta visita: '' (site normal), 'teste' (só você vê, com dados de teste) ou 'eleicao' */
function rri_el_modo() {
	$m = rri_el_opt()['modo'];
	if ( 'desligado' === $m ) { return ''; }
	if ( 'teste' === $m ) { return current_user_can( 'manage_options' ) ? 'teste' : ''; }
	if ( 'ligado' === $m ) { return 'eleicao'; }
	$t = time();
	if ( $t >= rri_el_ts( RRI_EL_INICIO ) && $t < rri_el_ts( RRI_EL_FIM ) ) { return 'eleicao'; }
	if ( $t >= rri_el_ts( RRI_EL_T2_INICIO ) && $t < rri_el_ts( RRI_EL_T2_FIM ) ) { return 'eleicao'; }
	return '';
}
/** qual turno o site mostra: 1 até o dia 5/10, depois 2 (você pode ver o 2º antes com ?el_fase=2) */
function rri_el_fase() {
	if ( isset( $_GET['el_fase'] ) && current_user_can( 'manage_options' ) ) { return '2' === $_GET['el_fase'] ? 2 : 1; } // phpcs:ignore
	return time() >= rri_el_ts( RRI_EL_FIM ) ? 2 : 1;
}
function rri_el_urnas_ts( $turno ) { return rri_el_ts( 2 === (int) $turno ? RRI_EL_T2_URNAS : RRI_EL_URNAS ); }
/** dados de teste? (só no modo teste e só para você) */
function rri_el_teste() { return 'teste' === rri_el_opt()['modo'] && current_user_can( 'manage_options' ); }
/** a página /apuracao/ fica no ar sempre, menos com a chave em "desligado" */
function rri_el_pagina_ok() {
	return 'desligado' !== rri_el_opt()['modo'];
}
/** antes das 17h do dia do turno: nenhum número é mostrado (lei eleitoral) */
function rri_el_antes( $turno = null ) {
	if ( null === $turno ) { $turno = rri_el_fase(); }
	if ( isset( $_GET['el_antes'] ) && current_user_can( 'manage_options' ) && (int) $turno === rri_el_fase() ) { return '1' === $_GET['el_antes']; } // phpcs:ignore
	if ( rri_el_demo() ) { return false; }
	if ( rri_el_teste() && (int) $turno === rri_el_fase() && ! isset( $_GET['el_antes'] ) ) { return false; } // phpcs:ignore
	return time() < rri_el_urnas_ts( $turno );
}

/** exemplo com uma eleição já apurada (2024), só para você, com ?demo=1 */
function rri_el_demo() { return ! empty( $_GET['demo'] ) && current_user_can( 'manage_options' ); } // phpcs:ignore

/** cargos e de onde vem cada um */
function rri_el_cargos( $demo = null, $turno = 1 ) {
	if ( null === $demo ) { $demo = rri_el_demo(); }
	if ( 2 === (int) $turno && ! $demo ) {
		return array(
			'pres' => array( 'nome' => 'Presidente', 'ciclo' => 'ele2026', 'ele' => '6258', 'base' => '6257', 'cd' => 1, 'br' => 1 ),
			'gov'  => array( 'nome' => 'Governador', 'ciclo' => 'ele2026', 'ele' => '6260', 'base' => '6259', 'cd' => 3 ),
		);
	}
	if ( $demo ) {
		return array(
			'gov'  => array( 'nome' => 'Governador', 'ciclo' => 'ele2024', 'ele' => '6278', 'cd' => 3, 'ufs' => array( 'rr' ), 'nota' => 'Exemplo com votos: eleição suplementar para governador de Roraima (junho de 2026).' ),
			'pref' => array( 'nome' => 'Prefeito', 'ciclo' => 'ele2024', 'ele' => '619', 'cd' => 11, 'mun' => 1, 'nota' => 'Exemplo com votos: 1º turno de 2024. Escolha qualquer cidade.' ),
			'ver'  => array( 'nome' => 'Vereador', 'ciclo' => 'ele2024', 'ele' => '619', 'cd' => 13, 'mun' => 1, 'prop' => 1, 'nota' => 'Exemplo com votos: 1º turno de 2024 (funciona igual aos deputados).' ),
		);
	}
	return array(
		'pres' => array( 'nome' => 'Presidente', 'ciclo' => 'ele2026', 'ele' => '6257', 'cd' => 1, 'br' => 1 ),
		'gov'  => array( 'nome' => 'Governador', 'ciclo' => 'ele2026', 'ele' => '6259', 'cd' => 3 ),
		'sen'  => array( 'nome' => 'Senador', 'ciclo' => 'ele2026', 'ele' => '6259', 'cd' => 5 ),
		'df'   => array( 'nome' => 'Deputado federal', 'ciclo' => 'ele2026', 'ele' => '6259', 'cd' => 6, 'prop' => 1 ),
		'de'   => array( 'nome' => 'Deputado estadual', 'ciclo' => 'ele2026', 'ele' => '6259', 'cd' => 7, 'prop' => 1, 'cd_df' => 8 ),
	);
}

/* ---------- busca no TSE, com cópia guardada ---------- */
function rri_el_fetch( $url, $ttl = 30 ) {
	$k = 'rri_el_' . md5( $url );
	$v = get_transient( $k );
	if ( false !== $v ) { return $v; }
	$backup = get_transient( 'rri_elb_' . md5( $url ) );
	/* se outro visitante já está buscando, entrega a cópia guardada */
	if ( get_transient( 'rri_ell_' . md5( $url ) ) && false !== $backup ) { return $backup; }
	set_transient( 'rri_ell_' . md5( $url ), 1, 15 );
	$r = wp_remote_get( $url, array( 'timeout' => 10, 'user-agent' => 'ResenhaRentavel/1.0 (+https://resenharentavel.com)', 'headers' => array( 'Accept' => 'application/json' ) ) );
	delete_transient( 'rri_ell_' . md5( $url ) );
	if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) {
		$d = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( is_array( $d ) ) {
			set_transient( $k, $d, $ttl );
			set_transient( 'rri_elb_' . md5( $url ), $d, 3 * DAY_IN_SECONDS );
			return $d;
		}
	}
	set_transient( $k, false === $backup ? 0 : $backup, 10 ); // evita martelar o TSE se ele cair
	return false === $backup ? null : $backup;
}

function rri_el_nome( $s ) {
	$s = mb_convert_case( mb_strtolower( trim( preg_replace( '/\s+/', ' ', (string) $s ) ) ), MB_CASE_TITLE, 'UTF-8' );
	return preg_replace_callback( '/\b(Da|De|Do|Das|Dos|E)\b/u', function ( $m ) { return mb_strtolower( $m[1] ); }, $s );
}
function rri_el_num( $s ) { return (float) str_replace( ',', '.', (string) $s ); }

/** resultado de um cargo num lugar (uf = br, zz ou sigla; mu = código TSE da cidade) */
function rri_el_resultado( $key, $uf, $mu, $turno = 1 ) {
	$turno  = 2 === (int) $turno ? 2 : 1;
	$cargos = rri_el_cargos( null, $turno );
	if ( empty( $cargos[ $key ] ) ) { return array( 'ok' => false, 'erro' => 'Cargo não encontrado.' ); }
	$c  = $cargos[ $key ];
	$uf = strtolower( preg_replace( '/[^a-z]/i', '', (string) $uf ) );
	$mu = substr( preg_replace( '/\D/', '', (string) $mu ), 0, 5 );
	if ( $uf && 'zz' !== $uf && function_exists( 'rri_el_uf_ok' ) && ! rri_el_uf_ok( $uf ) ) { return array( 'ok' => false, 'erro' => 'Estado não encontrado.' ); }
	if ( ! $uf ) { $uf = ! empty( $c['br'] ) ? 'br' : 'sp'; }
	if ( ( 'br' === $uf || 'zz' === $uf ) && empty( $c['br'] ) ) { return array( 'ok' => false, 'erro' => 'Escolha um estado.' ); }
	if ( 'br' === $uf ) { $mu = ''; }
	if ( ! empty( $c['mun'] ) && ! $mu ) { return array( 'ok' => false, 'erro' => 'Escolha uma cidade.', 'precisa_cidade' => 1 ); }
	if ( ! empty( $c['ufs'] ) && ! in_array( $uf, $c['ufs'], true ) ) { return array( 'ok' => false, 'erro' => 'Neste teste só existe resultado para ' . strtoupper( implode( ', ', $c['ufs'] ) ) . '.' ); }
	$cd   = ( 'df' === $uf && ! empty( $c['cd_df'] ) ) ? $c['cd_df'] : $c['cd'];
	$e6   = str_pad( $c['ele'], 6, '0', STR_PAD_LEFT );
	$url  = RRI_EL_TSE . '/' . $c['ciclo'] . '/' . $c['ele'] . '/dados/' . $uf . '/' . $uf . $mu . '-c' . str_pad( $cd, 4, '0', STR_PAD_LEFT ) . '-e' . $e6 . '-u.json';
	$antes = rri_el_antes( $turno );
	$ck    = 'rri_eln_' . md5( $url . ( $antes ? 'a' : 'd' ) );
	$cache = get_transient( $ck );
	if ( is_array( $cache ) ) { return $cache; }
	$d = rri_el_fetch( $url, $antes ? 300 : 30 );
	if ( ( ! is_array( $d ) || empty( $d['carg'][0] ) ) && 2 === $turno ) { return rri_el_t2_lista( $key, $uf, $mu, $c, $antes ); }
	if ( ! is_array( $d ) || empty( $d['carg'][0] ) ) { return array( 'ok' => false, 'erro' => 'O TSE ainda não publicou este resultado. Tente de novo em instantes.' ); }
	$cg = $d['carg'][0];
	$cands = array(); $bench = array();
	foreach ( (array) $cg['agr'] as $a ) {
		if ( isset( $a['vag'] ) && (int) $a['vag'] > 0 && ! $antes ) { $bench[] = array( 'nome' => (string) ( $a['com'] ?: $a['nm'] ), 'vagas' => (int) $a['vag'] ); }
		foreach ( (array) $a['par'] as $p ) {
			foreach ( (array) $p['cand'] as $x ) {
				$vice = '';
				if ( ! empty( $x['vs'][0]['nmu'] ) && 'v' === ( $x['vs'][0]['tp'] ?? '' ) ) { $vice = rri_el_nome( $x['vs'][0]['nmu'] ); }
				$cands[] = array(
					'n' => (string) $x['n'], 'nome' => rri_el_nome( $x['nmu'] ?? $x['nm'] ), 'partido' => (string) $p['sg'], 'vice' => $vice,
					'sq' => (string) $x['sqcand'], 'v' => $antes ? 0 : (int) $x['vap'], 'p' => $antes ? 0 : rri_el_num( $x['pvapn'] ?? $x['pvap'] ),
					'st' => $antes ? '' : (string) ( $x['st'] ?? '' ), 'dvt' => (string) ( $x['dvt'] ?? '' ),
				);
			}
		}
	}
	if ( $antes ) { usort( $cands, function ( $a, $b ) { return strcoll( remove_accents( $a['nome'] ), remove_accents( $b['nome'] ) ); } ); }
	else { usort( $cands, function ( $a, $b ) { return $b['v'] <=> $a['v'] ?: strcmp( $a['nome'], $b['nome'] ); } ); }
	usort( $bench, function ( $a, $b ) { return $b['vagas'] <=> $a['vagas']; } );
	$s = (array) ( $d['s'] ?? array() ); $e = (array) ( $d['e'] ?? array() ); $v = (array) ( $d['v'] ?? array() );
	$fuf = ( ! empty( $c['br'] ) || 'zz' === $uf ) ? 'br' : $uf; // fotos de presidente ficam sempre na pasta br
	$fele = $c['base'] ?? $c['ele']; // no 2º turno as fotos são as do 1º
	$out = array(
		'ok'     => true,
		'cargo'  => (string) ( $cg['nmn'] ?? $c['nome'] ),
		'vagas'  => (int) ( $cg['nv'] ?? 1 ),
		'antes'  => $antes,
		'semvotos' => ! $antes && 0 === array_sum( wp_list_pluck( $cands, 'v' ) ),
		'pst'    => $antes ? 0 : rri_el_num( $s['pstn'] ?? 0 ),
		'final'  => ! $antes && 's' === ( $d['tf'] ?? '' ),
		'hora'   => $antes ? '' : trim( ( $d['dt'] ?? '' ) . ' ' . substr( (string) ( $d['ht'] ?? '' ), 0, 5 ) ),
		'foto'   => RRI_EL_TSE . '/' . $c['ciclo'] . '/' . $fele . '/fotos/' . $fuf . '/',
		'turno'  => $turno,
		'cands'  => $cands,
		'bench'  => $bench,
		'tot'    => $antes ? null : array(
			'validos' => (int) ( $v['vvc'] ?? 0 ), 'pvalidos' => rri_el_num( $v['pvvcn'] ?? 0 ),
			'brancos' => (int) ( $v['vb'] ?? 0 ), 'pbrancos' => rri_el_num( $v['pvbn'] ?? 0 ),
			'nulos'   => (int) ( $v['tvn'] ?? 0 ), 'pnulos' => rri_el_num( $v['ptvnn'] ?? 0 ),
			'abst'    => (int) ( $e['a'] ?? 0 ), 'pabst' => rri_el_num( $e['pan'] ?? 0 ),
			'eleitores' => (int) ( $e['te'] ?? 0 ),
		),
	);
	set_transient( $ck, $out, $antes ? 300 : 25 );
	return $out;
}

/** 2º turno antes de o TSE publicar o arquivo: a lista vem de quem ficou com "2º turno" no 1º */
function rri_el_t2_lista( $key, $uf, $mu, $c, $antes ) {
	$agg = ! empty( $c['br'] ) ? 'br' : $uf;
	$r1  = rri_el_resultado( $key, $agg, '', 1 );
	$nome = mb_strtolower( $c['nome'] );
	if ( empty( $r1['ok'] ) ) { return array( 'ok' => false, 'erro' => 'O resultado do 1º turno ainda não saiu. Tente de novo em instantes.' ); }
	$l = array_values( array_filter( $r1['cands'], function ( $x ) { return 0 === strpos( (string) $x['st'], '2º turno' ); } ) );
	if ( ! $l ) {
		$onde = 'br' === $agg ? '' : ' em ' . strtoupper( $agg );
		return array( 'ok' => false, 'sem2t' => 1, 'erro' => 'Não há 2º turno para ' . $nome . $onde . '. O resultado já foi decidido no 1º turno.' );
	}
	foreach ( $l as &$x ) { $x['v'] = 0; $x['p'] = 0; $x['st'] = ''; }
	unset( $x );
	usort( $l, function ( $a, $b ) { return strcoll( remove_accents( $a['nome'] ), remove_accents( $b['nome'] ) ); } );
	return array( 'ok' => true, 'cargo' => $c['nome'], 'vagas' => 1, 'antes' => $antes, 'semvotos' => ! $antes, 'pst' => 0, 'final' => false, 'hora' => '', 'foto' => $r1['foto'], 'turno' => 2, 'cands' => $l, 'bench' => array(), 'tot' => null );
}

/** lista de cidades de um cargo: { "sp": [["71072","São Paulo",1], ...] } */
function rri_el_cidades( $key ) {
	$cargos = rri_el_cargos();
	if ( empty( $cargos[ $key ] ) ) { return array(); }
	$c  = $cargos[ $key ];
	$ck = 'rri_elm_' . $c['ciclo'] . $c['ele'];
	$v  = get_transient( $ck );
	if ( is_array( $v ) ) { return $v; }
	$d = rri_el_fetch( RRI_EL_TSE . '/' . $c['ciclo'] . '/' . $c['ele'] . '/config/mun-e' . str_pad( $c['ele'], 6, '0', STR_PAD_LEFT ) . '-cm.json', 43200 );
	$out = array();
	foreach ( (array) ( $d['abr'] ?? array() ) as $a ) {
		$uf = strtolower( (string) $a['cd'] );
		foreach ( (array) ( $a['mu'] ?? array() ) as $m ) { $out[ $uf ][] = array( (string) $m['cd'], rri_el_nome( $m['nm'] ), 's' === ( $m['c'] ?? '' ) ? 1 : 0 ); }
	}
	if ( $out ) { set_transient( $ck, $out, 43200 ); }
	return $out;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'rri/v1', '/eleicao', array(
		'methods' => 'GET', 'permission_callback' => 'rri_el_pagina_ok',
		'callback' => function ( $r ) {
			$res = new WP_REST_Response( rri_el_resultado( (string) $r['c'], (string) $r['uf'], (string) $r['mu'], (int) $r['t'] ) );
			$res->header( 'Cache-Control', 'no-store' );
			return $res;
		},
	) );
	register_rest_route( 'rri/v1', '/eleicao-cidades', array(
		'methods' => 'GET', 'permission_callback' => 'rri_el_pagina_ok',
		'callback' => function ( $r ) { return new WP_REST_Response( rri_el_cidades( (string) $r['c'] ) ); },
	) );
} );

/* ---------- configuração para o JavaScript ---------- */
function rri_el_js_cfg() {
	$lista = function ( $turno ) {
		$cg = array();
		foreach ( rri_el_cargos( null, $turno ) as $k => $c ) {
			$cg[] = array( 'k' => $k, 'nome' => $c['nome'], 'br' => ! empty( $c['br'] ), 'mun' => ! empty( $c['mun'] ), 'prop' => ! empty( $c['prop'] ), 'ufs' => $c['ufs'] ?? array(), 'nota' => $c['nota'] ?? '' );
		}
		return $cg;
	};
	$fase = rri_el_fase();
	$cg   = $lista( 1 );
	return array(
		'rest'   => esc_url_raw( rest_url( 'rri/v1/' ) ),
		'nonce'  => wp_create_nonce( 'wp_rest' ),
		'cargos' => $cg,
		'cargos2' => rri_el_demo() ? $cg : $lista( 2 ),
		'fase'   => $fase,
		'antes'  => rri_el_antes(),
		'urnas'  => rri_el_urnas_ts( $fase ) * 1000,
		'teste'  => rri_el_teste(),
		'demo'   => rri_el_demo(),
		'pagina' => home_url( '/apuracao/' ),
	);
}
function rri_el_assets() {
	$base = plugin_dir_url( __FILE__ ) . 'assets/';
	$ver  = (string) filemtime( __DIR__ . '/assets/eleicao.js' );
	echo '<link rel="stylesheet" href="' . esc_url( $base . 'eleicao.css?v=' . $ver ) . '">';
	echo '<script>window.RREL=' . wp_json_encode( rri_el_js_cfg() ) . ';</script>';
	echo '<script src="' . esc_url( $base . 'eleicao.js?v=' . $ver ) . '" defer></script>';
}

/* ---------- página /apuracao/ ---------- */
function rri_el_eh_apuracao() {
	$p = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' ); // phpcs:ignore
	$h = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $h && 0 === strpos( $p, $h ) ) { $p = trim( substr( $p, strlen( $h ) ), '/' ); }
	return 'apuracao' === $p;
}
add_action( 'template_redirect', function () {
	if ( ! rri_el_eh_apuracao() || ! rri_el_pagina_ok() ) { return; }
	global $wp_query;
	$wp_query->is_404 = false;
	status_header( 200 );
	nocache_headers();
	$tt = 'Apuração ao vivo: resultado da eleição 2026';
	add_filter( 'pre_get_document_title', function () use ( $tt ) { return $tt . ' | Resenha Rentável'; }, 99 );
	add_filter( 'wpseo_title', function () use ( $tt ) { return $tt . ' | Resenha Rentável'; }, 99 );
	add_filter( 'wpseo_robots', function () { return 'index, follow'; }, 99 );
	add_filter( 'body_class', function ( $c ) { return array_diff( $c, array( 'error404' ) ); } );
	get_header();
	rri_el_assets();
	?>
<main id="conteudo" class="rrel rrel-ap">
  <section class="ap-head"><div class="wrap">
    <span class="tag">Eleições 2026<?php echo 2 === rri_el_fase() ? ' · 2º turno' : ' · 1º turno'; ?></span>
    <h1>Apuração ao vivo: resultado da eleição 2026</h1>
    <p>Escolha o cargo e o lugar. Os números vêm direto do TSE e a página se atualiza sozinha a cada 30 segundos.</p>
    <div class="status" id="el-status"></div>
    <?php if ( rri_el_demo() ) : ?><div class="fict">Exemplo com votos de uma eleição passada, só para você ver como fica. Os visitantes não veem esta versão.</div><?php endif; ?>
  </div></section>
  <div class="controls"><div class="wrap">
    <div class="tabs" role="tablist" aria-label="Cargo" id="el-tabs"></div>
    <div class="where">
      <label for="el-uf">Onde</label>
      <button type="button" class="chip brbtn" id="el-br" aria-pressed="true">Brasil inteiro</button>
      <select id="el-uf"></select>
      <div class="combo" id="el-combo">
        <svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 2a8 8 0 0 1 6.32 12.9l5.39 5.4-1.41 1.4-5.4-5.39A8 8 0 1 1 10 2zm0 2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z"/></svg>
        <input id="el-city" role="combobox" aria-expanded="false" aria-controls="el-clist" aria-autocomplete="list" placeholder="Digite ou escolha sua cidade" autocomplete="off">
        <button class="tg" type="button" id="el-ctg" aria-label="Mostrar cidades">▼</button>
        <ul id="el-clist" role="listbox" hidden></ul>
      </div>
      <span class="crumb" id="el-crumb"></span>
    </div>
  </div></div>
  <section class="ap-body"><div class="wrap">
    <div class="panel" id="el-res"><div id="el-top"></div><div class="csearch"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 2a8 8 0 0 1 6.32 12.9l5.39 5.4-1.41 1.4-5.4-5.39A8 8 0 1 1 10 2zm0 2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z"/></svg><input id="el-q" type="search" autocomplete="off" aria-label="Buscar candidato" placeholder="Busque pelo nome, partido ou número"></div><div id="el-list"><div class="nores">Carregando…</div></div></div>
    <aside class="el-side">
      <div class="panel"><div class="panel-h"><h2>Comparecimento</h2><span class="sub" id="el-stw"></span></div><div class="stats" id="el-stats"></div></div>
      <div class="panel"><div class="panel-h"><h2>Escolha o estado</h2><span class="sub">toque para ver</span></div><div class="states" id="el-states"></div></div>
      <div class="panel"><div class="panel-h"><h2>Como ler estes números</h2></div><div class="how">
        <p><b>Votos válidos</b> são os votos dados a candidatos. Brancos e nulos não entram na conta.</p>
        <p><b>Presidente e governador:</b> quem passa de 50% dos válidos vence no 1º turno. Se ninguém passar, os dois primeiros vão ao 2º turno, em 25 de outubro.</p>
        <p><b>Senado:</b> em 2026 cada estado elege dois senadores. Cada eleitor vota duas vezes.</p>
        <p><b>Deputados:</b> as vagas são divididas primeiro entre os partidos, pelo total de votos, e depois entre os mais votados de cada partido. Quem não entra, mas fica na fila do partido, é suplente.</p>
        <p><b>Eleito, Não eleito e 2º turno</b> só aparecem quando o TSE confirma.</p>
      </div></div>
    </aside>
  </div></section>
</main>
	<?php
	get_footer();
	exit;
}, 1 );

/* ---------- página inicial de eleição ---------- */
/** página inicial de verdade: is_front_page() também fica verdadeiro em páginas do tema feitas só com regra própria (/sobre/, /autor/...), então confere o endereço */
function rri_el_eh_home() {
	if ( ! is_front_page() ) { return false; }
	$p = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH ), '/' ); // phpcs:ignore
	$h = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	return $p === $h || 'index.php' === $p;
}
add_filter( 'template_include', function ( $t ) {
	if ( rri_el_eh_home() && ! is_paged() && ( rri_el_modo() || ( function_exists( 'rri_el_periodo' ) && rri_el_periodo() ) ) ) {
		nocache_headers();
		return __DIR__ . '/eleicao-home.php';
	}
	return $t;
}, 99 );

/* faixa "ao vivo" no topo das outras páginas no dia */
add_action( 'wp_body_open', function () {
	if ( ! rri_el_modo() || rri_el_eh_home() || rri_el_eh_apuracao() || ( function_exists( 'rr_is_canvas' ) && rr_is_canvas() ) ) { return; }
	$antes = rri_el_antes();
	echo '<div class="rrel-faixa"><div class="wrap"><span class="' . ( $antes ? 'livedot g' : 'aovivo' ) . '">' . ( $antes ? '' : '<span class="livedot"></span>AO VIVO' ) . '</span><span>' . ( $antes ? '<b>Hoje é dia de eleição.</b> Resultados a partir das 17h.' : 'Apuração da eleição 2026 em tempo real' ) . '</span><a href="' . esc_url( home_url( '/apuracao/' ) ) . '">' . ( $antes ? 'Veja quem concorre ›' : 'Acompanhe ›' ) . '</a></div></div>';
	echo '<style>.rrel-faixa{background:#e4efe8;border-bottom:1px solid #e1e8e4;font-size:14px;color:#163327}.rrel-faixa .wrap{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;padding-block:8px}.rrel-faixa a{margin-left:auto;font-weight:700;color:#33755a}.rrel-faixa .aovivo{display:inline-flex;align-items:center;gap:6px;background:#d93a2f;color:#fff;border-radius:99px;padding:3px 10px;font-size:11px;font-weight:800;letter-spacing:.12em}.rrel-faixa .livedot{width:8px;height:8px;border-radius:50%;background:#fff;display:inline-block}.rrel-faixa .livedot.g{background:#2f8a63}</style>';
} );

/* ---------- frase do dia no fim da página inicial (sempre) ---------- */
function rri_frase_do_dia() {
	$c = get_transient( 'rri_frase_hoje' );
	if ( is_array( $c ) ) { return $c; }
	$ids = get_posts( array(
		'post_type' => 'rr_insta', 'posts_per_page' => 40, 'fields' => 'ids', 'no_found_rows' => true,
		'meta_key' => '_rr_ig_quando', 'orderby' => 'meta_value_num', 'order' => 'DESC',
		'meta_query' => array( array( 'key' => '_rr_ig_quando', 'value' => time(), 'compare' => '<=', 'type' => 'NUMERIC' ) ),
	) );
	$by_day = array();
	foreach ( $ids as $id ) {
		$car = json_decode( (string) get_post_meta( $id, '_rr_carrossel', true ), true );
		if ( ! is_array( $car ) || 'frase_do_dia' !== ( $car['capa_estilo'] ?? '' ) ) { continue; }
		$q = (int) get_post_meta( $id, '_rr_ig_quando', true );
		$by_day[ wp_date( 'Y-m-d', $q ) ][ $q ] = $car;
	}
	$out = array();
	if ( $by_day ) {
		krsort( $by_day );
		$day = reset( $by_day );
		ksort( $day ); // a primeira frase do dia
		$car = reset( $day );
		$fr  = trim( str_replace( '==', '', (string) ( $car['frase'] ?? $car['gancho'] ?? '' ) ) );
		$out = array( 'frase' => $fr, 'autor' => (string) ( $car['autor'] ?? '' ), 'cargo' => (string) ( $car['cargo'] ?? '' ) );
	}
	set_transient( 'rri_frase_hoje', $out, 10 * MINUTE_IN_SECONDS );
	return $out;
}
add_action( 'get_footer', function () {
	if ( ! rri_el_eh_home() || is_paged() ) { return; }
	$f = rri_frase_do_dia();
	if ( empty( $f['frase'] ) ) { return; }
	?>
<section class="rr-fdd" aria-label="Frase do dia"><div class="wrap">
  <h2 class="sec-h">Frase do dia</h2>
  <figure class="box"><span class="mk" aria-hidden="true">“</span><div>
    <blockquote><?php echo esc_html( $f['frase'] ); ?></blockquote>
    <?php if ( $f['autor'] ) : ?><figcaption><b><?php echo esc_html( $f['autor'] ); ?></b><?php echo $f['cargo'] ? ', ' . esc_html( lcfirst( $f['cargo'] ) ) : ''; ?></figcaption><?php endif; ?>
  </div></figure>
</div></section>
<style>.rr-fdd{padding-block:0 clamp(40px,5vw,64px)}.rr-fdd .box{margin:0;border-radius:14px;background:var(--soft,#f3f6f4);padding:clamp(16px,2vw,22px) clamp(18px,2.4vw,26px);display:grid;grid-template-columns:auto minmax(0,1fr);gap:clamp(12px,2vw,18px);align-items:center;max-width:820px}.rr-fdd .mk{font-family:var(--face,Georgia,serif);font-size:64px;line-height:.7;color:var(--green,#33755a)}.rr-fdd blockquote{margin:0;font-family:var(--face,Georgia,serif);font-size:clamp(18px,1.9vw,23px);line-height:1.18;color:var(--deep,#163327);text-wrap:balance}.rr-fdd figcaption{margin-top:8px;font-size:13px;color:var(--muted,#62736b)}.rr-fdd figcaption b{color:var(--ink,#13221b)}@media(max-width:620px){.rr-fdd .box{grid-template-columns:minmax(0,1fr)}.rr-fdd .mk{font-size:54px;height:26px}}</style>
	<?php
} );
add_action( 'rri_depois_da_busca', function () { delete_transient( 'rri_frase_hoje' ); } );

/* ---------- Ferramentas > Eleição 2026 ---------- */
add_action( 'admin_menu', function () {
	add_management_page( 'Eleição 2026', 'Eleição 2026', 'manage_options', 'rri-eleicao', 'rri_el_admin' );
} );
function rri_el_admin() {
	if ( isset( $_POST['rri_el_modo'] ) && check_admin_referer( 'rri_el' ) ) {
		$m = sanitize_key( wp_unslash( $_POST['rri_el_modo'] ) );
		if ( in_array( $m, array( 'auto', 'ligado', 'teste', 'desligado' ), true ) ) {
			update_option( 'rri_el', array( 'modo' => $m ) );
			echo '<div class="notice notice-success"><p>Salvo.</p></div>';
		}
	}
	$m = rri_el_opt()['modo'];
	$teste = null;
	if ( isset( $_GET['testar'] ) ) { // phpcs:ignore
		$teste = rri_el_resultado( 'pres', 'br', '' );
	}
	$ops = array(
		'auto'      => array( 'Automático (recomendado)', 'Até 26/10 a página inicial mostra os botões das eleições e o botão Eleições 2026 no topo. Nos domingos 4/10 e 25/10: às 5h vira a página do dia da eleição e às 17h a apuração ao vivo. A partir de 6/10 tudo muda sozinho para o 2º turno (candidatos, tira-dúvidas e apuração). Na terça, 27/10, à 0h, o site volta a ser como era antes; as páginas continuam acessíveis pelo link, mas sem nenhum botão no site.' ),
		'teste'     => array( 'Teste do dia da eleição (só você vê)', 'Só você, logado no WordPress, vê a página inicial como ela vai ficar no dia 4. Os visitantes veem o site com os botões das eleições, como no automático.' ),
		'ligado'    => array( 'Dia da eleição agora', 'A página inicial do dia da eleição aparece para todo mundo, já, até você mudar esta opção.' ),
		'desligado' => array( 'Desligado', 'Site normal, sem nada das eleições.' ),
	);
	?>
<div class="wrap"><h1>Eleição 2026</h1>
<form method="post"><?php wp_nonce_field( 'rri_el' ); ?>
<?php foreach ( $ops as $k => $o ) : ?>
  <p><label><input type="radio" name="rri_el_modo" value="<?php echo esc_attr( $k ); ?>" <?php checked( $m, $k ); ?>> <b><?php echo esc_html( $o[0] ); ?></b><br><span style="color:#555;margin-left:22px;display:inline-block"><?php echo esc_html( $o[1] ); ?></span></label></p>
<?php endforeach; ?>
<p><button class="button button-primary">Salvar</button></p></form>
<p><a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">Abrir a página inicial</a> <a class="button" href="<?php echo esc_url( home_url( '/apuracao/' ) ); ?>" target="_blank">Abrir a apuração</a>
<?php if ( 'teste' === $m ) : ?> <a class="button" href="<?php echo esc_url( home_url( '/?el_antes=1' ) ); ?>" target="_blank">Dia 4 antes das 17h</a> <a class="button" href="<?php echo esc_url( home_url( '/?el_antes=0' ) ); ?>" target="_blank">Dia 4 depois das 17h</a><?php endif; ?> <a class="button" href="<?php echo esc_url( home_url( '/apuracao/?demo=1' ) ); ?>" target="_blank">Exemplo com votos (eleição passada)</a> <a class="button" href="<?php echo esc_url( home_url( '/candidatos/' ) ); ?>" target="_blank">Quem está na sua urna</a> <a class="button" href="<?php echo esc_url( home_url( '/guia-do-eleitor/' ) ); ?>" target="_blank">Tira-dúvidas</a>
 <a class="button" href="<?php echo esc_url( add_query_arg( 'testar', 1 ) ); ?>">Testar conexão com o TSE</a></p>
<p><b>Ver como fica no 2º turno</b> (só você vê; os candidatos do 2º turno só aparecem depois do resultado do dia 4):
 <a class="button" href="<?php echo esc_url( home_url( '/?el_fase=2' ) ); ?>" target="_blank">Página inicial</a>
 <a class="button" href="<?php echo esc_url( home_url( '/candidatos/?el_fase=2' ) ); ?>" target="_blank">Quem está na sua urna</a>
 <a class="button" href="<?php echo esc_url( home_url( '/guia-do-eleitor/?el_fase=2' ) ); ?>" target="_blank">Tira-dúvidas</a>
 <a class="button" href="<?php echo esc_url( home_url( '/apuracao/?el_fase=2' ) ); ?>" target="_blank">Apuração</a></p>
<?php if ( is_array( $teste ) ) : ?>
  <p><?php echo ! empty( $teste['ok'] ) ? '✅ Conexão com o TSE funcionando. ' . count( $teste['cands'] ) . ' candidatos a presidente encontrados.' : '❌ ' . esc_html( $teste['erro'] ?? 'Não conectou.' ); ?></p>
<?php endif; ?>
</div>
	<?php
}
