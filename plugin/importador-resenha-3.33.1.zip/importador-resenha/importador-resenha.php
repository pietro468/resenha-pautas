<?php
/**
 * Plugin Name: Importador de artigos Resenha
 * Description: Importa artigos (.md + imagens) por .zip ou automaticamente de um repositório do GitHub, com imagens, capa, categoria, tags, autor e SEO.
 * Version: 3.33.1
 * Author: Resenha Rentável
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/md.php';
require_once __DIR__ . '/capa.php';
require_once __DIR__ . '/busca.php';
require_once __DIR__ . '/seletor.php';
require_once __DIR__ . '/carrossel.php';
require_once __DIR__ . '/instagram.php';
require_once __DIR__ . '/insta.php';
require_once __DIR__ . '/missao.php';
require_once __DIR__ . '/horario.php';
require_once __DIR__ . '/eleicao.php';
require_once __DIR__ . '/eleicao-extra.php';
require_once __DIR__ . '/seguranca.php';

define( 'RRI_OK_EXT', 'md|png|jpg|jpeg|webp|gif|json' );

/* ================= utilidades ================= */

function rri_base() { $u = wp_upload_dir(); return trailingslashit( $u['basedir'] ) . 'rr-importador/'; }

function rri_rrmdir( $d ) {
	if ( ! is_dir( $d ) ) { return; }
	foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $d, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST ) as $f ) {
		$f->isDir() ? @rmdir( $f->getPathname() ) : @unlink( $f->getPathname() );
	}
	@rmdir( $d );
}

function rri_batch() { $b = get_option( 'rri_batch' ); return ( is_array( $b ) && ! empty( $b['dir'] ) && is_dir( $b['dir'] ) ) ? $b : null; }
function rri_batch_articles() { $b = rri_batch(); return $b ? rri_scan( $b['dir'] ) : array(); }

function rri_existing( $slug ) {
	$p = get_posts( array( 'name' => $slug, 'post_type' => 'post', 'post_status' => array( 'publish', 'future', 'draft', 'pending', 'private' ), 'numberposts' => 1, 'fields' => 'ids' ) );
	return $p ? (int) $p[0] : 0;
}

function rri_sig( $s ) {
	$s = strtolower( remove_accents( trim( (string) $s ) ) );
	if ( false !== strpos( $s, 'pietro' ) && false !== strpos( $s, 'pedro' ) ) { return 'both'; }
	if ( false !== strpos( $s, 'dois' ) || false !== strpos( $s, 'ambos' ) ) { return 'both'; }
	if ( false !== strpos( $s, 'pietro' ) ) { return 'pietro'; }
	if ( false !== strpos( $s, 'pedro' ) ) { return 'pedro'; }
	return 'redacao';
}

function rri_cat( $name ) {
	$name = trim( (string) $name );
	if ( '' === $name ) { return array(); }
	$ids = array();
	foreach ( preg_split( '/\s*[,;·]\s*/u', $name ) as $n ) {
		if ( '' === $n ) { continue; }
		$t = get_term_by( 'name', $n, 'category' );
		if ( ! $t ) { $t = get_term_by( 'slug', sanitize_title( $n ), 'category' ); }
		if ( $t ) { $ids[] = (int) $t->term_id; continue; }
		$r = wp_insert_term( $n, 'category' );
		if ( ! is_wp_error( $r ) ) { $ids[] = (int) $r['term_id']; }
	}
	return $ids;
}

/** baixa uma imagem por link e coloca na biblioteca de mídia */
/** baixa um arquivo tentando se passar por navegador (alguns sites bloqueiam o WordPress) */
function rri_download( $url ) {
	$r = rri_download_one( $url );
	/* Wikimedia só gera miniaturas em tamanhos padrão: se a miniatura falhar, tenta a 1280px e depois o arquivo original */
	if ( is_wp_error( $r ) && preg_match( '#^(https://upload\.wikimedia\.org/wikipedia/[a-z]+)/thumb/([0-9a-f]/[0-9a-f]{2}/[^/]+)/(\d+)px-[^/]+$#', $url, $m ) ) {
		$alt = $m[1] . '/thumb/' . $m[2] . '/1280px-' . basename( $m[2] );
		if ( '1280' !== $m[3] ) { $r = rri_download_one( $alt ); }
		if ( is_wp_error( $r ) ) { $r = rri_download_one( $m[1] . '/' . $m[2] ); }
	}
	/* Flickr: se um tamanho falhar, tenta os outros tamanhos da mesma foto (k=2048, h=1600, b=1024, c=800) */
	if ( is_wp_error( $r ) && preg_match( '#^(https://live\.staticflickr\.com/\d+/\d+_[0-9a-f]+)(_[a-z])?\.jpg$#', $url, $m ) ) {
		foreach ( array( '_b', '_c', '_z', '' ) as $suf ) {
			if ( ( $m[2] ?? '' ) === $suf ) { continue; }
			$r = rri_download_one( $m[1] . $suf . '.jpg' );
			if ( ! is_wp_error( $r ) ) { break; }
		}
	}
	return $r;
}
function rri_download_one( $url ) {
	$agents = array(
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
		'ResenhaRentavelBot/1.0 (+' . home_url( '/' ) . ')',
	);
	$p = wp_parse_url( $url );
	$last = new WP_Error( 'dl', 'não baixou' );
	$host = strtolower( (string) ( $p['host'] ?? '' ) );
	/* o Flickr aceita melhor quem vem do próprio flickr.com; a última tentativa vai sem Referer */
	$ref = false !== strpos( $host, 'staticflickr.com' ) ? 'https://www.flickr.com/' : ( $p['scheme'] ?? 'https' ) . '://' . $host . '/';
	$tries = array( array( $agents[0], $ref ), array( $agents[1], $ref ), array( $agents[0], '' ) );
	foreach ( $tries as $t ) {
		list( $ua, $rf ) = $t;
		$tmp = wp_tempnam( 'rri-img' );
		$hd = array( 'Accept' => 'image/jpeg,image/png,image/webp;q=0.9,*/*;q=0.5' );
		if ( $rf ) { $hd['Referer'] = $rf; }
		$r = wp_remote_get( $url, array(
			'timeout' => 60, 'stream' => true, 'filename' => $tmp, 'redirection' => 8, 'user-agent' => $ua,
			'headers' => $hd,
		) );
		$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		$type = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_header( $r, 'content-type' );
		if ( 200 === $code && filesize( $tmp ) > 2000 && ( '' === $type || 0 === strpos( $type, 'image/' ) || false !== strpos( $type, 'octet-stream' ) ) ) { return rri_avif_to_jpg( $tmp ); }
		@unlink( $tmp );
		$last = is_wp_error( $r ) ? $r : new WP_Error( 'dl', $code ? 'HTTP ' . $code : 'resposta vazia' );
	}
	return $last;
}

/** se o site mandou AVIF (o Instagram e o GD não usam), converte para JPEG */
function rri_avif_to_jpg( $tmp ) {
	$info = @getimagesize( $tmp );
	if ( ! $info || ! defined( 'IMAGETYPE_AVIF' ) || IMAGETYPE_AVIF !== $info[2] ) { return $tmp; }
	$ed = wp_get_image_editor( $tmp );
	if ( is_wp_error( $ed ) ) { return $tmp; }
	$sv = $ed->save( $tmp . '.jpg', 'image/jpeg' );
	if ( is_wp_error( $sv ) || empty( $sv['path'] ) ) { return $tmp; }
	@unlink( $tmp );
	@rename( $sv['path'], $tmp );
	return $tmp;
}

function rri_sideload_url( $url, $name, $post_id, $desc = '' ) {
	$tmp = rri_download( $url );
	if ( is_wp_error( $tmp ) ) { return $tmp; }
	$aid = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), $post_id, $desc );
	if ( is_wp_error( $aid ) ) { @unlink( $tmp ); }
	return $aid;
}
function rri_sideload_file( $path, $name, $post_id, $desc = '' ) {
	$tmp = wp_tempnam( $name );
	copy( $path, $tmp );
	$aid = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), $post_id, $desc );
	if ( is_wp_error( $aid ) ) { @unlink( $tmp ); }
	return $aid;
}
function rri_ext_name( $url, $fallback ) {
	return preg_match( '/\.(jpe?g|png|webp|gif)(\?|$)/i', $url, $mm ) ? $fallback . '.' . strtolower( $mm[1] ) : $fallback . '.jpg';
}

/**
 * Importa um artigo.
 * $o: mode (publish|draft|future|date), n, per, date, hour, redacao (bool)
 */
function rri_import_article( $a, $o ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	@set_time_limit( 300 );

	$slug = $a['slug'];
	if ( $ex = rri_existing( $slug ) ) { return array( 'id' => $ex, 'link' => get_permalink( $ex ), 'label' => 'Já existia', 'warn' => '' ); }

	$mode = in_array( $o['mode'] ?? '', array( 'publish', 'draft', 'future', 'date' ), true ) ? $o['mode'] : 'draft';
	$warn = array();
	$dt   = '';
	if ( 'date' === $mode ) {
		$dt = rri_parse_date( $a['data'] );
		if ( ! $dt ) {
			$mode = ! empty( $o['nodate_publish'] ) ? 'publish' : 'draft';
			$warn[] = 'sem data no arquivo, entrou como ' . ( 'publish' === $mode ? 'publicado agora' : 'rascunho' );
		}
	}
	$post = array(
		'post_type'      => 'post',
		'post_title'     => $a['titulo'],
		'post_name'      => $slug,
		'post_excerpt'   => $a['subtitulo'],
		'post_content'   => '',
		'post_status'    => 'publish' === $mode ? 'publish' : 'draft',
		'post_author'    => ! empty( $o['author'] ) ? (int) $o['author'] : get_current_user_id(),
		'post_category'  => rri_cat( $a['categoria'] ),
		'comment_status' => 'closed',
	);
	if ( 'date' === $mode ) {
		$post['post_date']     = $dt;
		$post['post_date_gmt'] = get_gmt_from_date( $dt );
		$mode = strtotime( get_gmt_from_date( $dt ) . ' UTC' ) > time() ? 'future' : 'publish';
		$post['post_status'] = $mode;
	} elseif ( 'future' === $mode ) {
		$n    = max( 0, (int) ( $o['n'] ?? 0 ) );
		$per  = max( 1, (int) ( $o['per'] ?? 1 ) );
		$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $o['date'] ?? '' ) ? $o['date'] : wp_date( 'Y-m-d', strtotime( '+1 day' ) );
		$hour = preg_match( '/^\d{2}:\d{2}$/', $o['hour'] ?? '' ) ? $o['hour'] : '09:00';
		$day  = (int) floor( $n / $per );
		$slot = $n % $per;
		$local = date( 'Y-m-d H:i:s', strtotime( $date . ' ' . $hour . ':00 +' . $day . ' days +' . ( $slot * 3 ) . ' hours' ) );
		$post['post_status']   = 'future';
		$post['post_date']     = $local;
		$post['post_date_gmt'] = get_gmt_from_date( $local );
	}
	/* cria como rascunho primeiro, e só publica depois de montar tudo */
	$final_status = $post['post_status'];
	$post['post_status'] = 'draft';
	$id = wp_insert_post( wp_slash( $post ), true );
	if ( is_wp_error( $id ) ) { return $id; }

	$dir     = $a['dir'];
	$content = $a['conteudo'];
	$photos  = array();
	if ( empty( $a['pessoa'] ) && ( 'biografias' === sanitize_title( $a['categoria'] ) ) ) { $a['pessoa'] = rri_person_from_title( $a['titulo'] ); }
	$imeta   = $a['imgmeta'] ?? array();
	foreach ( array_unique( $a['imagens'] ) as $f ) {
		$aid = null;
		if ( file_exists( $dir . $f ) ) {
			$aid = rri_sideload_file( $dir . $f, $f, $id );
		} elseif ( ! empty( $imeta[ $f ]['url'] ) ) {
			$aid = rri_sideload_url( $imeta[ $f ]['url'], $f, $id );
		} else {
			$warn[] = 'imagem faltando: ' . $f;
			$content = preg_replace( '/<!-- wp:image \{"id":%%ID:' . preg_quote( $f, '/' ) . '%%.*?<!-- \/wp:image -->\s*/s', '', $content );
			continue;
		}
		if ( is_wp_error( $aid ) ) {
			$falta_foto = 1;
			$warn[] = 'imagem ' . $f . ' não baixou';
			$content = preg_replace( '/<!-- wp:image \{"id":%%ID:' . preg_quote( $f, '/' ) . '%%.*?<!-- \/wp:image -->\s*/s', '', $content );
			continue;
		}
		if ( preg_match( '/alt="([^"]*)"[^>]*wp-image-%%ID:' . preg_quote( $f, '/' ) . '%%/', $content, $m ) ) {
			update_post_meta( $aid, '_wp_attachment_image_alt', html_entity_decode( $m[1], ENT_QUOTES ) );
		}
		if ( ! empty( $imeta[ $f ]['credito'] ) ) { wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $imeta[ $f ]['credito'] ) ); }
		$photos[] = $aid;
		$url = wp_get_attachment_image_url( $aid, 'large' );
		$content = str_replace( array( '%%ID:' . $f . '%%', '%%URL:' . $f . '%%' ), array( $aid, $url ), $content );
	}

	/* biografia: fotos da pessoa ao longo do texto */
	if ( ! empty( $a['pessoa'] ) && 'biografias' === sanitize_title( $a['categoria'] ?? '' ) ) { $content = rri_add_person_photos( $id, $a['pessoa'], $content, $warn ); }

	/* capa: a foto escolhida no artigo. Se ela não baixar, usa uma foto do próprio texto (ou da pessoa) e SEGURA o Instagram para conferir */
	$thumb = 0; $credit = $a['capa_credito'] ?? ''; $used = ''; $trocada = 0;
	if ( ! empty( $a['capa'] ) && file_exists( $dir . $a['capa'] ) ) {
		$thumb = rri_sideload_file( $dir . $a['capa'], $a['capa'], $id, $a['titulo'] );
	} elseif ( ! empty( $a['capa_url'] ) ) {
		$thumb = rri_sideload_url( $a['capa_url'], rri_ext_name( $a['capa_url'], $slug . '-capa' ), $id, $a['titulo'] );
	}
	if ( ! $thumb || is_wp_error( $thumb ) ) {
		$why = is_wp_error( $thumb ) ? ' (' . $thumb->get_error_message() . ')' : '';
		$thumb = 0; $trocada = 1;
		foreach ( (array) $photos as $ph_id ) {
			if ( wp_attachment_is_image( $ph_id ) ) { $thumb = (int) $ph_id; $c = wp_get_attachment_caption( $ph_id ); $credit = $c ? preg_replace( '/^Foto:\s*/', '', $c ) : ''; $used = 'uma foto do próprio texto'; break; }
		}
		if ( ! $thumb && ! empty( $a['pessoa'] ) ) {
			$pp = rri_person_photo( $a['pessoa'] );
			if ( $pp ) {
				$t = rri_sideload_url( $pp['url'], sanitize_title( $a['pessoa'] ) . '-capa.jpg', $id, $a['pessoa'] );
				if ( ! is_wp_error( $t ) ) { $thumb = $t; $credit = $pp['credit']; $used = 'uma foto de ' . $a['pessoa'] . ' do Wikimedia'; }
			}
		}
		if ( ! $thumb ) { $thumb = rri_pick_cover( $id, $a, array(), $used, $credit ); }
		$warn[] = 'capa escolhida não baixou' . $why . ', usei ' . $used . '. O Instagram ficou segurado até alguém conferir';
	}
	if ( $trocada || ! empty( $falta_foto ) ) { update_post_meta( $id, '_rr_foto_conferir', $trocada ? 'capa' : 'fotos' ); }
	if ( $thumb && ! is_wp_error( $thumb ) ) {
		set_post_thumbnail( $id, $thumb );
		update_post_meta( $thumb, '_wp_attachment_image_alt', $a['titulo'] );
		if ( $credit ) { wp_update_post( array( 'ID' => $thumb, 'post_excerpt' => 'Foto: ' . $credit ) ); }
	}

	$upd = array( 'ID' => $id, 'post_content' => $content, 'post_status' => $final_status );
	if ( isset( $post['post_date'] ) ) { $upd['post_date'] = $post['post_date']; $upd['post_date_gmt'] = $post['post_date_gmt']; $upd['edit_date'] = true; }
	update_post_meta( $id, '_rr_sig', ! empty( $o['redacao'] ) ? 'redacao' : rri_sig( $a['assina'] ) );
	if ( ! empty( $a['tags'] ) ) { wp_set_post_tags( $id, $a['tags'], false ); }
	if ( ! empty( $a['frase_chave'] ) ) { update_post_meta( $id, '_yoast_wpseo_focuskw', $a['frase_chave'] ); }
	if ( ! empty( $a['busca_imagem'] ) ) { update_post_meta( $id, '_rri_busca', $a['busca_imagem'] ); }
	if ( ! empty( $a['pessoa'] ) ) { update_post_meta( $id, '_rri_pessoa', $a['pessoa'] ); }
	if ( ! empty( $a['meta_descricao'] ) ) { update_post_meta( $id, '_yoast_wpseo_metadesc', $a['meta_descricao'] ); }
	wp_update_post( wp_slash( $upd ) );

	/* carrossel do Instagram (carrossel.json na pasta do artigo) */
	if ( ! empty( $a['carrossel'] ) ) { rri_car_attach( $id, $a['carrossel'] ); }

	$labels = array( 'publish' => 'Publicado', 'draft' => 'Rascunho', 'future' => 'Agendado' );
	$label  = $labels[ $final_status ] ?? $final_status;
	if ( 'future' === $final_status ) { $label .= ' para ' . get_the_date( 'd/m H:i', $id ); }
	return array(
		'id'    => $id,
		'link'  => 'publish' === $final_status ? get_permalink( $id ) : admin_url( 'post.php?post=' . $id . '&action=edit' ),
		'label' => $label,
		'warn'  => implode( ' · ', $warn ),
	);
}

/**
 * Plano B da capa, só com fotos (nunca infográfico):
 * 1) busca no Commons e no Openverse pelo assunto; 2) foto do texto baixada por link;
 * 3) miniatura do vídeo do canal; 4) capa gerada com o título (último caso).
 */
function rri_pick_cover( $post_id, $a, $photos, &$used, &$credit, $skip = array() ) {
	$used = ''; $tried = $skip;
	for ( $k = 0; $k < 3; $k++ ) {
		$f = rri_find_photo( $a, $tried );
		if ( ! $f ) { break; }
		$tried[] = $f['url'];
		$aid = rri_sideload_url( $f['url'], sanitize_title( $a['titulo'] ) . '-capa.jpg', $post_id, $a['titulo'] );
		if ( ! is_wp_error( $aid ) ) { update_post_meta( $aid, '_rri_searched', 1 ); $used = 'uma foto de acervo livre sobre o assunto'; $credit = $f['credit']; return $aid; }
	}
	foreach ( (array) $photos as $pid ) {
		if ( wp_attachment_is_image( $pid ) ) {
			$used = 'uma foto do próprio texto';
			$c = wp_get_attachment_caption( $pid ); $credit = $c ? preg_replace( '/^Foto:\s*/', '', $c ) : '';
			return (int) $pid;
		}
	}
	$yt = '';
	foreach ( array( $a['youtube'] ?? '', $a['conteudo'] ?? '' ) as $src ) {
		if ( $src && preg_match( '~(?:youtube(?:-nocookie)?\.com/(?:watch\?(?:[^"\s<]*&)?v=|embed/|shorts/|live/)|youtu\.be/)([A-Za-z0-9_-]{11})~', $src, $m ) ) { $yt = $m[1]; break; }
	}
	if ( $yt ) {
		foreach ( array( 'maxresdefault', 'sddefault', 'hqdefault' ) as $q ) {
			$aid = rri_sideload_url( 'https://i.ytimg.com/vi/' . $yt . '/' . $q . '.jpg', 'youtube-' . $yt . '.jpg', $post_id, $a['titulo'] );
			if ( ! is_wp_error( $aid ) ) { $used = 'a miniatura do vídeo do canal'; $credit = 'Resenha Rentável (acervo próprio)'; return $aid; }
		}
	}
	$png = rri_make_cover( $a['titulo'], $a['categoria'] );
	if ( ! is_wp_error( $png ) ) {
		$aid = media_handle_sideload( array( 'name' => sanitize_title( $a['titulo'] ) . '-capa.png', 'tmp_name' => $png ), $post_id, $a['titulo'] );
		if ( ! is_wp_error( $aid ) ) { update_post_meta( $aid, '_rri_generated', 1 ); $used = 'uma capa gerada com o título (nenhuma foto encontrada)'; $credit = ''; return $aid; }
		@unlink( $png );
	}
	return 0;
}

/** biografia: garante pelo menos 2 fotos da pessoa ao longo do texto */
function rri_add_person_photos( $post_id, $name, $content, &$warn ) {
	$have = preg_match_all( '/<!-- wp:image /', $content );
	if ( $have >= 2 ) { return $content; }
	$cands = rri_person_candidates( $name );
	$heads = array();
	if ( preg_match_all( '/<!-- wp:heading/', $content, $mm, PREG_OFFSET_CAPTURE ) ) { $heads = wp_list_pluck( $mm[0], 1 ); }
	$spots = array_values( array_filter( array( $heads[1] ?? null, $heads[3] ?? ( $heads[2] ?? null ) ) ) );
	$added = 0; $need = 2 - $have;
	$ins = array(); $authors = array();
	foreach ( $cands as $c ) {
		if ( $added >= $need || $added >= count( $spots ) ) { break; }
		/* nunca duas fotos do mesmo fotógrafo (costumam ser quase iguais, da mesma sessão) */
		$who = strtolower( trim( preg_replace( '/\s+(from|at)\s.*$/i', '', strtok( (string) $c['credit'], '/(' ) ) ) );
		if ( $who && isset( $authors[ $who ] ) ) { continue; }
		$aid = rri_sideload_url( $c['url'], sanitize_title( $name ) . '-' . ( $added + 1 ) . '.jpg', $post_id, $name );
		if ( is_wp_error( $aid ) ) { continue; }
		update_post_meta( $aid, '_wp_attachment_image_alt', $name );
		wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $c['credit'] ) );
		$url = wp_get_attachment_image_url( $aid, 'large' );
		if ( $who ) { $authors[ $who ] = 1; }
		$ins[ $spots[ $added ] ] = '<!-- wp:image {"id":' . $aid . ',"sizeSlug":"large","linkDestination":"none"} -->' . "\n"
			. '<figure class="wp-block-image size-large"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $name ) . '" class="wp-image-' . $aid . '"/><figcaption class="wp-element-caption">' . esc_html( $name . '. Foto: ' . $c['credit'] ) . '</figcaption></figure>' . "\n<!-- /wp:image -->\n\n";
		$added++;
	}
	krsort( $ins );
	foreach ( $ins as $pos => $html ) { $content = substr( $content, 0, $pos ) . $html . substr( $content, $pos ); }
	if ( $have + $added < 2 ) { $warn[] = 'achei só ' . ( $have + $added ) . ' foto(s) de ' . $name . ' para o texto'; }
	return $content;
}

/* botão: criar capa para posts que ficaram sem */
add_action( 'admin_post_rri_fix_covers', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! current_user_can( 'upload_files' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_fix_covers' );
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	@set_time_limit( 600 );
	$ids = get_posts( array( 'post_type' => 'post', 'post_status' => array( 'publish', 'future', 'draft' ), 'numberposts' => 300, 'fields' => 'ids' ) );
	$n = 0; $b = 0; $done = 0;
	foreach ( $ids as $pid ) {
		if ( $done >= 15 ) { break; }
		$p = get_post( $pid ); $cats = get_the_category( $pid ); $cat = $cats ? $cats[0]->name : '';
		$th = (int) get_post_thumbnail_id( $pid );
		$bio = 'biografias' === sanitize_title( $cat ) && ! get_post_meta( $pid, '_rri_person_ok', true );
		$cap = $th ? (string) wp_get_attachment_caption( $th ) : '';
		$fname = $th ? pathinfo( (string) get_attached_file( $th ), PATHINFO_FILENAME ) : '';
		$by_search = $th && ( get_post_meta( $th, '_rri_searched', true )
			|| ( 0 === strpos( $fname, sanitize_title( $p->post_title ) . '-capa' ) && sanitize_title( $p->post_title ) !== $p->post_name ) );
		$old_search = $by_search && ! get_post_meta( $pid, '_rri_person_ok', true ) && '3.6' !== get_post_meta( $pid, '_rri_recheck', true ) && ! get_post_meta( $pid, '_rri_manual_cover', true );
		if ( $old_search ) { update_post_meta( $pid, '_rri_recheck', '3.6' ); }
		$bad = ! $th || $old_search || get_post_meta( $th, '_rri_generated', true )
			|| ( 'image/png' === get_post_mime_type( $th ) && false !== strpos( $p->post_content, 'wp-image-' . $th ) );
		if ( ! $bio && ! $bad ) { continue; }
		$done++;
		$tags = wp_get_post_tags( $pid, array( 'fields' => 'names' ) );
		$a = array( 'titulo' => $p->post_title, 'categoria' => $cat, 'tags' => $tags, 'frase_chave' => get_post_meta( $pid, '_yoast_wpseo_focuskw', true ), 'conteudo' => $p->post_content, 'youtube' => '' );
		if ( $bio ) {
			$a['pessoa'] = rri_person_from_title( $p->post_title );
			$w = array();
			$c2 = rri_add_person_photos( $pid, $a['pessoa'], $p->post_content, $w );
			if ( $c2 !== $p->post_content ) { wp_update_post( wp_slash( array( 'ID' => $pid, 'post_content' => $c2 ) ) ); }
			$pp = rri_person_photo( $a['pessoa'] );
			if ( $pp ) {
				$aid = rri_sideload_url( $pp['url'], sanitize_title( $a['pessoa'] ) . '-capa.jpg', $pid, $a['pessoa'] );
				if ( ! is_wp_error( $aid ) ) {
					set_post_thumbnail( $pid, $aid ); update_post_meta( $aid, '_wp_attachment_image_alt', $a['pessoa'] );
					wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $pp['credit'] ) );
					update_post_meta( $pid, '_rri_person_ok', 1 ); $b++; continue;
				}
			}
			if ( ! $bad ) { continue; }
		}
		$used = ''; $credit = '';
		$a['busca_imagem'] = (string) get_post_meta( $pid, '_rri_busca', true );
		$aid = rri_pick_cover( $pid, $a, array(), $used, $credit, $th && $old_search ? array( (string) wp_get_attachment_url( $th ) ) : array() );
		if ( $aid ) {
			set_post_thumbnail( $pid, $aid ); $n++;
			if ( $credit ) { wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $credit ) ); }
		}
	}
	$msg = ( $n || $b ) ? trim( ( $n ? $n . ' capa(s) trocada(s) por foto. ' : '' ) . ( $b ? $b . ' biografia(s) com foto da pessoa na capa.' : '' ) ) : 'Nenhuma capa para corrigir.';
	if ( $done >= 15 ) { $msg .= ' Clique de novo para continuar com os próximos.'; }
	wp_safe_redirect( add_query_arg( 'rri_ok', rawurlencode( $msg ), admin_url( 'tools.php?page=rr-importador' ) ) ); exit;
} );

/* ================= menu e tela ================= */

add_action( 'admin_menu', function () {
	add_management_page( 'Importar artigos Resenha', 'Importar artigos Resenha', 'edit_posts', 'rr-importador', 'rri_page' );
} );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $l ) {
	array_unshift( $l, '<a href="' . esc_url( admin_url( 'tools.php?page=rr-importador' ) ) . '"><strong>Abrir importador</strong></a>' );
	return $l;
} );

function rri_gh_opts() {
	return wp_parse_args( get_option( 'rri_gh', array() ), array( 'repo' => '', 'branch' => 'main', 'on' => 0, 'redacao' => 1 ) );
}

function rri_page() {
	$b    = rri_batch();
	$arts = rri_batch_articles();
	$gh   = rri_gh_opts();
	$log  = get_option( 'rri_gh_log', array() );
	$next = wp_next_scheduled( 'rri_gh_cron' );
	$new  = 0;
	?>
	<div class="wrap" style="max-width:900px">
	<h1>Importar artigos Resenha</h1>
	<?php if ( ! empty( $_GET['rri_err'] ) ) : ?><div class="notice notice-error"><p><?php echo esc_html( wp_unslash( $_GET['rri_err'] ) ); ?></p></div><?php endif; ?>
	<?php if ( ! empty( $_GET['rri_ok'] ) ) : ?><div class="notice notice-success"><p><?php echo esc_html( wp_unslash( $_GET['rri_ok'] ) ); ?></p></div><?php endif; ?>

	<div style="background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px 20px;margin:16px 0">
		<h2 style="margin-top:0">Automático pelo GitHub</h2>
		<p>O site confere o repositório a cada 30 minutos e importa sozinho os artigos novos, na data que vem em cada arquivo. A rotina também avisa o site na hora em que envia artigos novos.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rri_gh_save"><?php wp_nonce_field( 'rri_gh_save' ); ?>
			<p><label>Repositório: <input type="text" name="repo" value="<?php echo esc_attr( $gh['repo'] ); ?>" placeholder="usuario/repositorio" style="width:260px"></label>
			&nbsp; <label>Ramo: <input type="text" name="branch" value="<?php echo esc_attr( $gh['branch'] ); ?>" style="width:90px"></label></p>
			<p><label><input type="checkbox" name="on" value="1" <?php checked( $gh['on'] ); ?>> <strong>Ligar a importação automática</strong></label></p>
			<p><label><input type="checkbox" name="redacao" value="1" <?php checked( $gh['redacao'] ); ?>> Sempre assinar como Redação</label></p>
			<p><button class="button button-primary">Salvar</button>
			<button class="button" name="now" value="1">Salvar e buscar agora</button></p>
		</form>
		<p class="description"><?php
			if ( $gh['on'] && $next ) { echo 'Próxima busca: ' . esc_html( wp_date( 'd/m H:i', $next ) ) . '.'; }
			elseif ( ! $gh['on'] ) { echo 'Desligado.'; }
		?></p>
		<?php if ( $log ) : ?>
		<details><summary style="cursor:pointer"><strong>Últimas importações automáticas</strong></summary>
			<ul style="margin:10px 0 0 18px;list-style:disc"><?php foreach ( array_slice( $log, 0, 30 ) as $l ) : ?><li><?php echo wp_kses_post( $l ); ?></li><?php endforeach; ?></ul>
		</details>
		<?php endif; ?>
	</div>

	<?php rri_ig_settings_box(); ?>

	<?php $keys = rri_keys(); ?>
	<div style="background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px 20px;margin:16px 0">
		<h2 style="margin-top:0">Bancos de fotos</h2>
		<p>Com estas chaves grátis, o importador busca fotos modernas quando a capa do artigo não baixa, e aparece a caixa <strong>Trocar capa por outra foto</strong> dentro de cada post.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rri_keys_save"><?php wp_nonce_field( 'rri_keys_save' ); ?>
			<p><label>Chave do Pexels: <input type="text" name="pexels" value="<?php echo esc_attr( $keys['pexels'] ); ?>" style="width:420px" autocomplete="off"></label> <?php echo $keys['pexels'] ? '<span style="color:#008a20">ativa</span>' : ''; ?></p>
			<p><label>Chave do Pixabay: <input type="text" name="pixabay" value="<?php echo esc_attr( $keys['pixabay'] ); ?>" style="width:420px" autocomplete="off"></label> <?php echo $keys['pixabay'] ? '<span style="color:#008a20">ativa</span>' : ''; ?></p>
			<p><button class="button button-primary">Salvar chaves</button></p>
		</form>
	</div>

	<div style="background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px 20px;margin:16px 0">
		<h2 style="margin-top:0">Importar por .zip</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
			<input type="hidden" name="action" value="rri_upload"><?php wp_nonce_field( 'rri_upload' ); ?>
			<input type="file" name="rri_zip[]" accept=".zip" multiple required>
			<button class="button button-primary">Enviar .zip</button>
		</form>
		<p class="description">Pode selecionar vários .zip de uma vez (segure Ctrl ao clicar nos arquivos). Uma pasta por artigo (.md + imagens). Tamanho máximo aceito pelo seu servidor: <?php echo esc_html( size_format( wp_max_upload_size() ) ); ?>.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px"><input type="hidden" name="action" value="rri_fix_covers"><?php wp_nonce_field( 'rri_fix_covers' ); ?><button class="button">Revisar capas (sem foto, com gráfico ou biografia sem a pessoa)</button></form>
	</div>
	<?php if ( ! $b ) : ?></div><?php return; endif; ?>
	<h2>Artigos do .zip</h2>
	<p style="font-size:15px">Enviado: <strong><?php echo esc_html( $b['name'] ); ?></strong>, com <strong><?php echo count( $arts ); ?> artigo(s)</strong>. Os que já existem no site são pulados automaticamente.
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"><input type="hidden" name="action" value="rri_clear"><?php wp_nonce_field( 'rri_clear' ); ?><button class="button-link" style="color:#b32d2e">Descartar este .zip</button></form></p>
	<?php if ( ! $arts ) : ?><div class="notice notice-warning inline"><p>Não achei nenhum artigo nesse .zip. Cada artigo precisa ser um arquivo .md com o título no topo.</p></div></div><?php return; endif; ?>
	<table class="widefat striped" style="margin:16px 0"><thead><tr><th>Artigo</th><th style="width:170px">Situação</th></tr></thead><tbody>
	<?php $withdate = 0; foreach ( $arts as $a ) : $ex = rri_existing( $a['slug'] ); if ( ! $ex ) { $new++; } $dt = rri_parse_date( $a['data'] ); if ( $dt && ! $ex ) { $withdate++; } ?>
		<tr data-slug="<?php echo esc_attr( $a['slug'] ); ?>" data-sig="<?php echo esc_attr( rri_sig( $a['assina'] ) ); ?>"><td><strong><?php echo esc_html( $a['titulo'] ); ?></strong><br><small><?php echo esc_html( $a['categoria'] . ' · ' . $a['assina'] . ( $dt ? ' · ' . mysql2date( 'd/m/Y H:i', $dt ) : '' ) ); ?></small></td>
		<td class="st"><?php echo $ex ? '<a href="' . esc_url( get_edit_post_link( $ex ) ) . '">Já existe</a>' : 'Novo'; ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
	<?php if ( $new ) : ?>
	<h2>Como publicar</h2>
	<?php if ( $withdate ) : ?>
	<p><label><input type="radio" name="rri_mode" value="date" checked> <strong>Usar a data de cada artigo</strong> (<?php echo (int) $withdate; ?> de <?php echo (int) $new; ?> têm data. Datas futuras ficam agendadas; os sem data entram como rascunho)</label></p>
	<?php endif; ?>
	<p><label><input type="radio" name="rri_mode" value="publish"<?php echo $withdate ? '' : ' checked'; ?>> <strong>Publicar agora</strong></label></p>
	<p><label><input type="radio" name="rri_mode" value="draft"> <strong>Salvar como rascunho</strong> (vocês revisam e publicam depois)</label></p>
	<p><label><input type="radio" name="rri_mode" value="future"> <strong>Agendar</strong>, começando em
		<input type="date" id="rri_date" value="<?php echo esc_attr( wp_date( 'Y-m-d', strtotime( '+1 day' ) ) ); ?>">
		às <input type="time" id="rri_hour" value="09:00">, com
		<input type="number" id="rri_per" value="3" min="1" max="20" style="width:60px"> artigo(s) por dia, a cada 3 horas</label></p>
	<p style="margin-left:24px"><label><input type="checkbox" id="rri_alt" checked> Alternar autores (um de Pietro, um de Pedro, um da Redação, e assim por diante)</label></p>
	<p><button class="button button-primary button-hero" id="rri_go">Importar <?php echo (int) $new; ?> artigo(s)</button></p>
	<p id="rri_msg" style="font-size:15px"></p>
	<script>
	(function(){
		var go = document.getElementById("rri_go"), msg = document.getElementById("rri_msg");
		go.addEventListener("click", function(){
			var rows = [].slice.call(document.querySelectorAll("tr[data-slug]")).filter(function(r){ return r.querySelector(".st").textContent.trim() === "Novo"; });
			var mode = document.querySelector("input[name=rri_mode]:checked").value;
			if(mode === "future" && document.getElementById("rri_alt").checked){
				var order = ["pietro","pedro","redacao","both"], g = {}, out = [];
				rows.forEach(function(r){ var k = r.getAttribute("data-sig"); (g[k] = g[k] || []).push(r); });
				var keys = order.filter(function(k){ return g[k]; });
				while(keys.some(function(k){ return g[k].length; })){ keys.forEach(function(k){ if(g[k].length) out.push(g[k].shift()); }); }
				rows = out;
			}
			go.disabled = true; var i = 0, ok = 0, fails = 0;
			function next(){
				if(i >= rows.length){ msg.innerHTML = "<strong>Pronto.</strong> " + ok + " importado(s)" + (fails ? ", " + fails + " com erro." : ".") + " Limpe o cache do site."; return; }
				var r = rows[i], st = r.querySelector(".st"); st.textContent = "Importando...";
				msg.textContent = "Importando " + (i+1) + " de " + rows.length + "... não feche esta página.";
				var fd = new FormData();
				fd.append("action","rri_one"); fd.append("_wpnonce","<?php echo esc_js( wp_create_nonce( 'rri' ) ); ?>");
				fd.append("slug", r.getAttribute("data-slug")); fd.append("mode", mode); fd.append("n", i);
				fd.append("date", document.getElementById("rri_date").value); fd.append("hour", document.getElementById("rri_hour").value); fd.append("per", document.getElementById("rri_per").value);
				fetch(ajaxurl, {method:"POST", body:fd, credentials:"same-origin"}).then(function(x){ return x.json(); }).then(function(j){
					if(j.success){ ok++; st.innerHTML = '<a href="'+j.data.link+'" target="_blank">'+j.data.label+'</a>' + (j.data.warn ? '<br><small style="color:#b26200">'+j.data.warn+'</small>' : ''); }
					else { fails++; st.innerHTML = '<span style="color:#b32d2e">Erro: '+(j.data||"desconhecido")+'</span>'; }
				}).catch(function(){ fails++; st.innerHTML = '<span style="color:#b32d2e">Erro de conexão</span>'; }).then(function(){ i++; next(); });
			}
			next();
		});
	})();
	</script>
	<?php else : ?>
	<p style="font-size:15px"><strong>Todos os artigos deste .zip já estão no site.</strong></p>
	<?php endif; ?>
	</div>
	<?php
}

add_action( 'admin_post_rri_keys_save', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_keys_save' );
	update_option( 'rri_keys', array( 'pexels' => sanitize_text_field( wp_unslash( $_POST['pexels'] ?? '' ) ), 'pixabay' => sanitize_text_field( wp_unslash( $_POST['pixabay'] ?? '' ) ) ), false );
	$k = rri_keys(); $msg = 'Chaves salvas.';
	if ( $k['pexels'] ) { $msg .= rri_pexels_search( 'money', 1 ) ? ' Pexels funcionando.' : ' A chave do Pexels não funcionou, confira.'; }
	if ( $k['pixabay'] ) { $msg .= rri_pixabay_search( 'money', 3 ) ? ' Pixabay funcionando.' : ' A chave do Pixabay não funcionou, confira.'; }
	wp_safe_redirect( add_query_arg( 'rri_ok', rawurlencode( $msg ), admin_url( 'tools.php?page=rr-importador' ) ) ); exit;
} );

/* ================= .zip ================= */

add_action( 'admin_post_rri_upload', function () {
	if ( ! current_user_can( 'edit_posts' ) || ! current_user_can( 'upload_files' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_upload' );
	$back = admin_url( 'tools.php?page=rr-importador' );
	$F = $_FILES['rri_zip'] ?? null;
	$files = array();
	if ( $F && is_array( $F['name'] ) ) {
		foreach ( $F['name'] as $i => $nm ) { $files[] = array( 'name' => $nm, 'tmp_name' => $F['tmp_name'][ $i ], 'error' => $F['error'][ $i ] ); }
	} elseif ( $F ) { $files[] = $F; }
	$files = array_filter( $files, function ( $f ) { return ! empty( $f['tmp_name'] ) && UPLOAD_ERR_OK === $f['error']; } );
	if ( ! $files ) {
		wp_safe_redirect( add_query_arg( 'rri_err', rawurlencode( 'Não consegui receber os arquivos. Se forem muito grandes, envie menos de cada vez.' ), $back ) ); exit;
	}
	$old = rri_batch(); if ( $old ) { rri_rrmdir( $old['dir'] ); }
	$dir = rri_base() . 'lote-' . time() . '-' . wp_generate_password( 6, false ) . '/';
	wp_mkdir_p( $dir );
	@file_put_contents( rri_base() . 'index.php', '<?php // silence' );
	$names = array(); $bad = array();
	foreach ( array_values( $files ) as $k => $f ) {
		if ( ! preg_match( '/\.zip$/i', $f['name'] ) ) { $bad[] = $f['name']; continue; }
		$sub = $dir . 'z' . $k . '/'; wp_mkdir_p( $sub );
		$ok = false;
		if ( class_exists( 'ZipArchive' ) ) {
			$z = new ZipArchive();
			if ( true === $z->open( $f['tmp_name'] ) ) { $ok = $z->extractTo( $sub ); $z->close(); }
		}
		if ( ! $ok ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
			$ok = ! is_wp_error( unzip_file( $f['tmp_name'], $sub ) );
		}
		if ( $ok ) { $names[] = sanitize_file_name( $f['name'] ); } else { $bad[] = $f['name']; }
	}
	if ( ! $names ) { rri_rrmdir( $dir ); wp_safe_redirect( add_query_arg( 'rri_err', rawurlencode( 'Não consegui abrir os arquivos. Envie arquivos .zip.' ), $back ) ); exit; }
	foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) ) as $f ) {
		if ( $f->isFile() && ! preg_match( '/\.(' . RRI_OK_EXT . ')$/i', $f->getFilename() ) ) { @unlink( $f->getPathname() ); }
	}
	update_option( 'rri_batch', array( 'dir' => $dir, 'name' => count( $names ) > 1 ? count( $names ) . ' arquivos .zip' : $names[0], 'time' => time() ), false );
	wp_safe_redirect( $bad ? add_query_arg( 'rri_err', rawurlencode( 'Estes arquivos não abriram: ' . implode( ', ', $bad ) ), $back ) : $back ); exit;
} );

add_action( 'admin_post_rri_clear', function () {
	if ( ! current_user_can( 'edit_posts' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_clear' );
	$b = rri_batch(); if ( $b ) { rri_rrmdir( $b['dir'] ); }
	delete_option( 'rri_batch' );
	wp_safe_redirect( admin_url( 'tools.php?page=rr-importador' ) ); exit;
} );

add_action( 'wp_ajax_rri_one', function () {
	check_ajax_referer( 'rri' );
	if ( ! current_user_can( 'edit_posts' ) || ! current_user_can( 'upload_files' ) ) { wp_send_json_error( 'sem permissão' ); }
	$slug = sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) );
	$a = null;
	foreach ( rri_batch_articles() as $x ) { if ( $x['slug'] === $slug ) { $a = $x; break; } }
	if ( ! $a ) { wp_send_json_error( 'artigo não encontrado no lote. Envie o .zip de novo.' ); }
	$r = rri_import_article( $a, array(
		'mode' => sanitize_key( $_POST['mode'] ?? '' ), 'n' => $_POST['n'] ?? 0, 'per' => $_POST['per'] ?? 1,
		'date' => $_POST['date'] ?? '', 'hour' => $_POST['hour'] ?? '',
	) );
	if ( is_wp_error( $r ) ) { wp_send_json_error( $r->get_error_message() ); }
	wp_send_json_success( $r );
} );

/* ================= GitHub ================= */

add_filter( 'cron_schedules', function ( $s ) {
	$s['rri_30min'] = array( 'interval' => 1800, 'display' => 'A cada 30 minutos' );
	return $s;
} );

function rri_gh_schedule() {
	$gh = rri_gh_opts();
	$ts = wp_next_scheduled( 'rri_gh_cron' );
	if ( $gh['on'] && $gh['repo'] && ! $ts ) { wp_schedule_event( time() + 60, 'rri_30min', 'rri_gh_cron' ); }
	if ( ( ! $gh['on'] || ! $gh['repo'] ) && $ts ) { wp_clear_scheduled_hook( 'rri_gh_cron' ); }
}
add_action( 'init', 'rri_gh_schedule' );
register_deactivation_hook( __FILE__, function () { wp_clear_scheduled_hook( 'rri_gh_cron' ); } );

add_action( 'admin_post_rri_gh_save', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_gh_save' );
	$repo = trim( preg_replace( '~^https?://github\.com/~i', '', wp_unslash( $_POST['repo'] ?? '' ) ), "/ \t" );
	$repo = preg_replace( '/\.git$/', '', $repo );
	update_option( 'rri_gh', array(
		'repo'    => preg_match( '~^[\w.-]+/[\w.-]+$~', $repo ) ? $repo : '',
		'branch'  => sanitize_text_field( wp_unslash( $_POST['branch'] ?? 'main' ) ) ?: 'main',
		'on'      => empty( $_POST['on'] ) ? 0 : 1,
		'redacao' => empty( $_POST['redacao'] ) ? 0 : 1,
	), false );
	wp_clear_scheduled_hook( 'rri_gh_cron' );
	rri_gh_schedule();
	$msg = 'Configuração salva.';
	if ( ! empty( $_POST['now'] ) ) {
		$r = rri_gh_run( true );
		$msg .= ' ' . $r;
	}
	wp_safe_redirect( add_query_arg( 'rri_ok', rawurlencode( $msg ), admin_url( 'tools.php?page=rr-importador' ) ) ); exit;
} );

function rri_gh_log( $line ) {
	$log = get_option( 'rri_gh_log', array() );
	array_unshift( $log, esc_html( wp_date( 'd/m H:i' ) ) . ' · ' . $line );
	update_option( 'rri_gh_log', array_slice( $log, 0, 60 ), false );
}

function rri_gh_get( $url ) {
	$r = wp_remote_get( $url, array( 'timeout' => 30, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
	if ( is_wp_error( $r ) ) { return $r; }
	if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) { return new WP_Error( 'http', 'HTTP ' . wp_remote_retrieve_response_code( $r ) ); }
	return wp_remote_retrieve_body( $r );
}

/** busca o index.json do repositório e importa o que for novo. Devolve um resumo. */
function rri_gh_run( $manual = false ) {
	$gh = rri_gh_opts();
	if ( ! $gh['repo'] ) { return 'Nenhum repositório configurado.'; }
	if ( get_transient( 'rri_gh_lock' ) ) { return 'Já existe uma busca em andamento.'; }
	set_transient( 'rri_gh_lock', 1, 10 * MINUTE_IN_SECONDS );

	/* publica agendados que ficaram para trás (site sem visitas na hora certa) */
	foreach ( get_posts( array( 'post_status' => 'future', 'numberposts' => 20, 'fields' => 'ids', 'date_query' => array( array( 'before' => current_time( 'mysql' ) ) ) ) ) as $late ) { wp_publish_post( $late ); }

	$raw  = apply_filters( 'rri_gh_raw_base', 'https://raw.githubusercontent.com/' . $gh['repo'] . '/' . rawurlencode( $gh['branch'] ) . '/', $gh );
	$body = rri_gh_get( $raw . 'index.json?t=' . time() );
	if ( is_wp_error( $body ) ) {
		delete_transient( 'rri_gh_lock' );
		$m = 'Não consegui ler o index.json do GitHub (' . $body->get_error_message() . ').';
		if ( $manual ) { rri_gh_log( $m ); }
		return $m;
	}
	$idx  = json_decode( $body, true );
	$list = is_array( $idx ) ? ( $idx['artigos'] ?? $idx ) : array();
	$done = get_option( 'rri_gh_done', array() );
	$count = 0; $news = 0; $out = array();
	foreach ( $list as $it ) {
		if ( empty( $it['slug'] ) || empty( $it['pasta'] ) || empty( $it['arquivos'] ) ) { continue; }
		$slug = sanitize_title( $it['slug'] );
		if ( in_array( $slug, $done, true ) || rri_existing( $slug ) ) {
			/* matéria que já está no site e ganhou carrossel depois */
			$ex = rri_existing( $slug );
			$recent = ! empty( $it['data'] ) && strtotime( $it['data'] ) > time() - 3 * DAY_IN_SECONDS;
			if ( $ex && in_array( 'carrossel.json', (array) $it['arquivos'], true ) && ( $recent || ! get_post_meta( $ex, '_rr_carrossel', true ) ) ) {
				$path = implode( '/', array_map( 'rawurlencode', explode( '/', trim( $it['pasta'], '/' ) ) ) ) . '/carrossel.json';
				$js = rri_gh_get( $raw . $path . '?t=' . time() );
				if ( ! is_wp_error( $js ) && is_array( $car = json_decode( $js, true ) ) && md5( $js ) !== get_post_meta( $ex, '_rr_car_hash', true ) ) {
					$had = (bool) get_post_meta( $ex, '_rr_carrossel', true );
					rri_car_attach( $ex, $car );
					update_post_meta( $ex, '_rr_car_hash', md5( $js ) );
					rri_gh_log( 'Carrossel do Instagram ' . ( $had ? 'atualizado' : 'criado' ) . ' para <a href="' . esc_url( get_permalink( $ex ) ) . '">' . esc_html( get_the_title( $ex ) ) . '</a>' );
				}
			}
			continue;
		}
		$news++;
		if ( $count >= 6 ) { continue; }
		$count++;
		$dir = rri_base() . 'github/' . $slug . '/';
		rri_rrmdir( $dir ); wp_mkdir_p( $dir );
		$ok = true;
		foreach ( (array) $it['arquivos'] as $f ) {
			$f = basename( $f );
			if ( ! preg_match( '/\.(' . RRI_OK_EXT . ')$/i', $f ) ) { continue; }
			$path = implode( '/', array_map( 'rawurlencode', explode( '/', trim( $it['pasta'], '/' ) ) ) ) . '/' . rawurlencode( $f );
			$data = rri_gh_get( $raw . $path );
			if ( is_wp_error( $data ) ) { $ok = false; $out[] = $slug . ': não baixou ' . $f; break; }
			file_put_contents( $dir . $f, $data );
		}
		if ( ! $ok ) { rri_gh_log( esc_html( $slug ) . ': arquivos não baixaram, tento de novo na próxima busca' ); continue; }
		$arts = rri_scan( $dir );
		if ( ! $arts ) { rri_gh_log( esc_html( $slug ) . ': .md sem título, ignorado' ); $done[] = $slug; continue; }
		$a = $arts[0];
		$admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
		$r = rri_import_article( $a, array( 'mode' => 'date', 'nodate_publish' => 1, 'redacao' => ! empty( $gh['redacao'] ), 'author' => $admins ? $admins[0] : 1 ) );
		if ( is_wp_error( $r ) ) { rri_gh_log( esc_html( $a['titulo'] ) . ': erro (' . esc_html( $r->get_error_message() ) . ')' ); continue; }
		$done[] = $slug;
		rri_gh_log( '<a href="' . esc_url( $r['link'] ) . '">' . esc_html( $a['titulo'] ) . '</a>: ' . esc_html( $r['label'] ) . ( $r['warn'] ? ' <em style="color:#b26200">(' . esc_html( $r['warn'] ) . ')</em>' : '' ) );
		rri_rrmdir( $dir );
	}
	update_option( 'rri_gh_done', array_slice( array_values( array_unique( $done ) ), -2000 ), false );
	update_option( 'rri_gh_last', time(), false );
	rri_link_new_videos();
	rri_insta_import( $raw, $idx );
	rri_repub_check( $raw );
	delete_transient( 'rri_gh_lock' );
	rri_ig_process( 3 );
	do_action( 'rri_depois_da_busca' );
	if ( ! $news ) { return 'Nenhum artigo novo no GitHub.'; }
	return $count . ' artigo(s) importado(s)' . ( $news > $count ? ', o resto vem na próxima busca.' : '.' ) . ' Veja a lista abaixo.';
}
add_action( 'rri_gh_cron', function () { rri_gh_run( false ); } );

/* Lista dos vídeos do canal (sem Shorts), para a rotina escolher o vídeo certo de cada artigo.
   Usa a chave do YouTube do tema e guarda o resultado por 6 horas. */
function rri_channel_videos() {
	$c = get_transient( 'rri_videos' );
	if ( is_array( $c ) ) { return $c; }
	if ( ! defined( 'RR_YT_KEY' ) || ! defined( 'RR_YT_HANDLE' ) ) { return new WP_Error( 'rri', 'Tema sem chave do YouTube.' ); }
	$api = 'https://www.googleapis.com/youtube/v3/';
	$k   = '&key=' . rawurlencode( RR_YT_KEY );
	$get = function ( $u ) {
		$r = wp_remote_get( $u, array( 'timeout' => 20, 'headers' => array( 'Referer' => home_url( '/' ) ) ) );
		if ( is_wp_error( $r ) ) { return $r; }
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		return is_array( $j ) ? $j : new WP_Error( 'rri', 'Resposta inválida do YouTube.' );
	};
	$ch = $get( $api . 'channels?part=contentDetails&forHandle=' . rawurlencode( RR_YT_HANDLE ) . $k );
	if ( is_wp_error( $ch ) ) { return $ch; }
	$up = $ch['items'][0]['contentDetails']['relatedPlaylists']['uploads'] ?? '';
	if ( ! $up ) { return new WP_Error( 'rri', 'Canal não encontrado.' ); }
	$ids = array(); $page = '';
	for ( $i = 0; $i < 4; $i++ ) {
		$pl = $get( $api . 'playlistItems?part=contentDetails&maxResults=50&playlistId=' . rawurlencode( $up ) . ( $page ? '&pageToken=' . rawurlencode( $page ) : '' ) . $k );
		if ( is_wp_error( $pl ) ) { break; }
		foreach ( (array) ( $pl['items'] ?? array() ) as $it ) { $ids[] = $it['contentDetails']['videoId']; }
		$page = $pl['nextPageToken'] ?? '';
		if ( ! $page ) { break; }
	}
	$out = array();
	foreach ( array_chunk( $ids, 50 ) as $chunk ) {
		$v = $get( $api . 'videos?part=snippet,contentDetails&id=' . implode( ',', $chunk ) . $k );
		if ( is_wp_error( $v ) ) { continue; }
		foreach ( (array) ( $v['items'] ?? array() ) as $it ) {
			$d = $it['contentDetails']['duration'] ?? '';
			$sec = 0;
			if ( preg_match( '/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/', $d, $m ) ) { $sec = (int) ( $m[1] ?? 0 ) * 3600 + (int) ( $m[2] ?? 0 ) * 60 + (int) ( $m[3] ?? 0 ); }
			if ( $sec && $sec < 180 ) { continue; } // Shorts
			if ( ( $it['snippet']['liveBroadcastContent'] ?? 'none' ) !== 'none' ) { continue; }
			$out[] = array(
				'titulo'    => $it['snippet']['title'],
				'link'      => 'https://youtu.be/' . $it['id'],
				'data'      => substr( $it['snippet']['publishedAt'], 0, 10 ),
				'descricao' => mb_substr( (string) $it['snippet']['description'], 0, 4000 ),
			);
		}
	}
	if ( $out ) { set_transient( 'rri_videos', $out, 6 * HOUR_IN_SECONDS ); }
	return $out;
}
add_action( 'rest_api_init', function () {
	register_rest_route( 'rri/v1', '/videos', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			$v = rri_channel_videos();
			if ( is_wp_error( $v ) ) { return array( 'ok' => 0, 'msg' => $v->get_error_message() ); }
			return array( 'ok' => 1, 'total' => count( $v ), 'videos' => $v );
		},
	) );
} );

/* Vídeo novo do canal entra sozinho nos artigos antigos do mesmo assunto.
   Regra rígida para não errar: o nome da pessoa do artigo, ou uma tag de duas ou mais palavras,
   precisa aparecer no título do vídeo. Só vale para vídeos que saírem depois desta versão,
   só em artigos publicados que ainda não têm vídeo, e no máximo 5 artigos por vídeo. */
function rri_video_terms( $pid ) {
	$t = array();
	$pes = get_post_meta( $pid, '_rri_pessoa', true );
	if ( ! $pes && has_category( 'biografias', $pid ) ) { $pes = rri_person_from_title( get_the_title( $pid ) ); }
	if ( $pes ) { $t[] = $pes; }
	foreach ( (array) wp_get_post_tags( $pid, array( 'fields' => 'names' ) ) as $tag ) {
		if ( str_word_count( remove_accents( $tag ) ) >= 2 ) { $t[] = $tag; }
	}
	$out = array();
	foreach ( $t as $x ) { $x = trim( preg_replace( '/[^a-z0-9 ]+/', ' ', rri_norm( $x ) ) ); if ( strlen( $x ) >= 6 ) { $out[] = $x; } }
	return array_unique( $out );
}
/**
 * republicar.json no GitHub: {"posts":[{"id":"r1","slug":"steve-jobs","depois":"2026-09-29 09:30"}]}
 * Depois do horário (Brasília), coloca o post de novo na fila do Instagram. Cada id vale uma vez só.
 */
function rri_repub_check( $raw ) {
	$js = rri_gh_get( $raw . 'republicar.json?t=' . time() );
	if ( is_wp_error( $js ) || ! is_array( $d = json_decode( $js, true ) ) ) { return; }
	$done = (array) get_option( 'rri_repub_done', array() );
	foreach ( (array) ( $d['posts'] ?? array() ) as $it ) {
		$id = (string) ( $it['id'] ?? '' ); $slug = sanitize_title( (string) ( $it['slug'] ?? ( $it['materia'] ?? '' ) ) ); // "materia": só versões 3.22+ leem (troca de capa)
		if ( '' === $id || '' === $slug || in_array( $id, $done, true ) ) { continue; }
		$when = ! empty( $it['depois'] ) ? strtotime( $it['depois'] . ' America/Sao_Paulo' ) : 0;
		if ( $when && time() < $when ) { continue; }
		$done[] = $id;
		/* "refazer": apaga a matéria (e as fotos dela) para ela ser importada de novo do zero na próxima busca, com texto, fotos, capa e Instagram novos */
		if ( ! empty( $it['refazer'] ) ) {
			$ex = rri_existing( $slug );
			if ( $ex ) {
				foreach ( get_attached_media( '', $ex ) as $m ) { wp_delete_attachment( $m->ID, true ); }
				$th = (int) get_post_thumbnail_id( $ex ); if ( $th ) { wp_delete_attachment( $th, true ); }
				$cdir = trailingslashit( wp_upload_dir()['basedir'] ) . 'carrossel/' . $ex . '/';
				if ( is_dir( $cdir ) ) { array_map( 'unlink', glob( $cdir . '*' ) ?: array() ); @rmdir( $cdir ); }
				wp_delete_post( $ex, true );
			}
			update_option( 'rri_gh_done', array_values( array_diff( (array) get_option( 'rri_gh_done', array() ), array( $slug ) ) ), false );
			rri_gh_log( 'Matéria ' . esc_html( $slug ) . ' apagada para ser importada de novo (refazer)' );
			continue;
		}
		$p = get_page_by_path( $slug, OBJECT, 'post' );
		if ( ! $p || 'publish' !== $p->post_status ) { continue; }
		/* troca opcional da foto de capa (site e Instagram) antes de postar de novo */
		if ( ! empty( $it['capa_url'] ) ) {
			$old = (int) get_post_thumbnail_id( $p->ID );
			$oldcred = $old ? trim( preg_replace( '/^Foto:\s*/i', '', wp_strip_all_tags( (string) wp_get_attachment_caption( $old ) ) ) ) : '';
			$aid = rri_sideload_url( $it['capa_url'], rri_ext_name( $it['capa_url'], $slug . '-capa-' . sanitize_title( $id ) ), $p->ID, get_the_title( $p ) );
			if ( is_wp_error( $aid ) ) {
				$done = array_diff( $done, array( $id ) ); // tenta de novo na próxima busca
				rri_gh_log( 'Republicar ' . esc_html( $slug ) . ': a nova capa não baixou (' . esc_html( $aid->get_error_message() ) . ')' );
				continue;
			}
			set_post_thumbnail( $p->ID, $aid );
			update_post_meta( $aid, '_wp_attachment_image_alt', get_the_title( $p ) );
			delete_post_meta( $p->ID, '_rr_foto_conferir' );
			$cred = trim( (string) ( $it['capa_credito'] ?? '' ) );
			if ( $cred ) {
				wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $cred ) );
				{
					$c = get_post_field( 'post_content', $p->ID );
					$c2 = preg_replace( '/Foto de capa: [^<*\n]+/u', 'Foto de capa: ' . str_replace( '$', '\\$', $cred ), $c, 1 );
					if ( $c2 !== $c ) { wp_update_post( array( 'ID' => $p->ID, 'post_content' => $c2 ) ); }
				}
			}
			if ( function_exists( 'rri_car_render' ) && get_post_meta( $p->ID, '_rr_carrossel', true ) ) { rri_car_render( $p->ID ); }
			rri_gh_log( 'Capa trocada: ' . esc_html( get_the_title( $p ) ) );
		}
		if ( isset( $it['instagram'] ) && ! $it['instagram'] ) { continue; } // "instagram": false = só troca no site, sem postar de novo
		foreach ( array( '_rr_ig_id', '_rr_ig_link', '_rr_ig_err', '_rr_ig_tries' ) as $k ) { delete_post_meta( $p->ID, $k ); }
		update_post_meta( $p->ID, '_rr_ig_pending', time() );
		rri_gh_log( 'Instagram: ' . esc_html( get_the_title( $p ) ) . ' voltou para a fila (republicar).' );
	}
	update_option( 'rri_repub_done', $done, false );
}

function rri_link_new_videos() {
	$v = rri_channel_videos();
	if ( is_wp_error( $v ) || ! $v ) { return; }
	$seen = get_option( 'rri_videos_seen', null );
	$links = wp_list_pluck( $v, 'link' );
	if ( null === $seen ) { update_option( 'rri_videos_seen', $links, false ); return; } // primeira vez: só anota os que já existem
	$new = array_filter( $v, function ( $x ) use ( $seen ) { return ! in_array( $x['link'], $seen, true ); } );
	if ( ! $new ) { return; }
	$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 500, 'fields' => 'ids' ) );
	foreach ( $new as $vid ) {
		$title = ' ' . trim( preg_replace( '/[^a-z0-9 ]+/', ' ', rri_norm( $vid['titulo'] ) ) ) . ' ';
		$done = 0;
		foreach ( $posts as $pid ) {
			if ( $done >= 5 ) { break; }
			$c = get_post_field( 'post_content', $pid );
			if ( false !== strpos( $c, 'youtu' ) ) { continue; }
			$hit = '';
			foreach ( rri_video_terms( $pid ) as $term ) { if ( false !== strpos( $title, ' ' . $term . ' ' ) ) { $hit = $term; break; } }
			if ( ! $hit ) { continue; }
			$u = esc_url_raw( $vid['link'] );
			$c .= "\n\n<!-- wp:paragraph -->\n<p>O Resenha Rentável fez um vídeo sobre esse assunto. Assista:</p>\n<!-- /wp:paragraph -->\n\n"
				. '<!-- wp:embed {"url":"' . $u . '","type":"video","providerNameSlug":"youtube","responsive":true,"className":"wp-embed-aspect-16-9 wp-has-aspect-ratio"} -->' . "\n"
				. '<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">' . "\n$u\n</div></figure>\n<!-- /wp:embed -->";
			wp_update_post( array( 'ID' => $pid, 'post_content' => $c ) );
			update_post_meta( $pid, '_rri_video_auto', $u );
			rri_gh_log( 'Vídeo novo "' . esc_html( $vid['titulo'] ) . '" colocado em <a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a>' );
			$done++;
		}
		$seen[] = $vid['link'];
	}
	update_option( 'rri_videos_seen', array_slice( array_values( array_unique( $seen ) ), -1000 ), false );
}

/* Endereço que a rotina chama logo depois de enviar os artigos, e que também serve
   para um "despertador" externo: importa o que é novo e publica os agendados atrasados,
   sem depender de visitas no site. Só lê o repositório configurado, então não precisa de senha. */
add_action( 'rest_api_init', function () {
	register_rest_route( 'rri/v1', '/buscar', array(
		'methods'             => array( 'GET', 'POST' ),
		'permission_callback' => '__return_true',
		'callback'            => function () {
			$gh = rri_gh_opts();
			if ( ! $gh['on'] || ! $gh['repo'] ) { return array( 'ok' => 0, 'msg' => 'Importação automática desligada.' ); }
			if ( get_transient( 'rri_gh_ping' ) ) {
				if ( get_transient( 'rri_gh_ping2' ) ) { return array( 'ok' => 1, 'msg' => 'Aguarde.' ); } // no máximo 1 vez a cada 15 segundos
				set_transient( 'rri_gh_ping2', 1, 15 );
				foreach ( get_posts( array( 'post_status' => 'future', 'numberposts' => 20, 'fields' => 'ids', 'date_query' => array( array( 'before' => current_time( 'mysql' ) ) ) ) ) as $late ) { wp_publish_post( $late ); }
				rri_ig_process( 3 );
				return array( 'ok' => 1, 'msg' => 'Busca feita há menos de 1 minuto.' );
			}
			set_transient( 'rri_gh_ping', 1, 60 );
			ignore_user_abort( true );
			@set_time_limit( 600 );
			$m = rri_gh_run( false );
			/* a resposta é pública: não mostra títulos (as matérias agendadas ainda são segredo) */
			$fut = get_posts( array( 'post_status' => 'future', 'numberposts' => 50, 'fields' => 'ids' ) );
			return array( 'ok' => 1, 'msg' => 'Busca feita.', 'agendados' => count( $fut ) );
		},
	) );
} );
