<?php
/** Tira-dúvidas do eleitor 2026 (texto do Resenha, com fontes oficiais no fim). */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$cand = home_url( '/candidatos/' );
$ap   = home_url( '/apuracao/' );
$box  = function ( $n ) { return str_repeat( '<i></i>', $n ); };
$t2   = 2 === rri_el_fase();
?>
<main id="conteudo" class="rrel rrel-ap rrel-guia">
  <section class="ap-head"><div class="wrap">
    <span class="tag">Eleições 2026</span>
    <h1>Tira-dúvidas do eleitor 2026</h1>
    <?php if ( $t2 ) : ?>
    <p>O que você precisa saber para votar no 2º turno, domingo, 25 de outubro: quem vota em quê, horário, documento, o que fazer se não puder ir e o que é proibido no dia.</p>
    <?php else : ?>
    <p>O que você precisa saber para votar no domingo, 4 de outubro, sem susto na fila: horário, documento, a ordem dos seis votos, o que fazer se não puder ir e o que é proibido no dia.</p>
    <?php endif; ?>
    <div class="atalhos">
      <a class="btn line" href="<?php echo esc_url( $cand ); ?>">Ver quem está na sua urna</a>
      <a class="btn line" href="<?php echo esc_url( $ap ); ?>">Apuração em tempo real</a>
    </div>
  </div></section>

  <div class="wrap gwrap">
    <nav class="toc" aria-label="Neste guia">
      <a href="#quando">Quando e que horas</a>
      <a href="#votos"><?php echo $t2 ? 'Em quem você vota' : 'Os 6 votos na urna'; ?></a>
      <a href="#documento">Qual documento levar</a>
      <a href="#onde">Onde eu voto</a>
      <a href="#cabine">Colinha e celular</a>
      <a href="#dia">O que pode e o que é crime</a>
      <a href="#obrigado">Quem é obrigado a votar</a>
      <a href="#faltar">Não vou votar. E agora?</a>
      <a href="#transito">Voto em trânsito</a>
      <a href="#prioridade">Prioridade e acessibilidade</a>
      <a href="#branco">Branco e nulo</a>
      <a href="#depois">Depois das 17h</a>
      <a href="#datas">Datas que importam</a>
      <a href="#fontes">Fontes</a>
    </nav>

    <div class="gcont">
      <div class="resumo">
        <?php if ( $t2 ) : ?>
        <div><b>25 de outubro</b><span>2º turno para presidente e, em alguns estados, governador.</span></div>
        <div><b>8h às 17h</b><span>Horário de Brasília, igual em todo o país.</span></div>
        <div><b>1 ou 2 votos</b><span>Presidente e, onde houver 2º turno, governador. Números de 2 dígitos.</span></div>
        <?php else : ?>
        <div><b>4 de outubro</b><span>1º turno. O 2º turno, se houver, é em 25 de outubro.</span></div>
        <div><b>8h às 17h</b><span>Horário de Brasília, igual em todo o país.</span></div>
        <div><b>6 votos</b><span>Deputado federal, estadual, 2 senadores, governador e presidente.</span></div>
        <?php endif; ?>
      </div>

      <section class="gs" id="quando">
        <h2>Quando e que horas</h2>
        <p><?php echo $t2 ? 'O 2º turno é no domingo, <b>25 de outubro de 2026</b>.' : 'O 1º turno é no domingo, <b>4 de outubro de 2026</b>.'; // phpcs:ignore ?> As seções abrem às <b>8h e fecham às 17h pelo horário de Brasília</b>, no Brasil inteiro. Quem mora em estado com fuso diferente abre a seção em outro horário no relógio local:</p>
        <ul>
          <li>Rondônia, Mato Grosso, Mato Grosso do Sul, Roraima e a maior parte do Amazonas: das 7h às 16h (hora local).</li>
          <li>Acre e parte do Amazonas: das 6h às 15h (hora local).</li>
          <li>Fernando de Noronha: das 9h às 18h (hora local).</li>
        </ul>
        <p>Chegou às 17h e ainda tem fila? Você vota. O portão fecha, mas quem já está na fila é atendido.</p>
        <?php if ( $t2 ) : ?>
        <p>O 2º turno existe onde nenhum candidato a presidente ou a governador teve mais da metade dos votos válidos no 1º turno. Os dois mais votados voltam para a disputa, e vence quem tiver mais votos válidos.</p>
        <?php else : ?>
        <p>Se nenhum candidato a presidente ou a governador tiver mais da metade dos votos válidos, os dois mais votados disputam o <b>2º turno em 25 de outubro</b>.</p>
        <?php endif; ?>
      </section>

<?php if ( $t2 ) : ?>
      <section class="gs" id="votos">
        <h2>Em quem você vota no 2º turno</h2>
        <p>No 2º turno só existem dois cargos na urna: <b>presidente</b> e <b>governador</b>. Você vota para presidente e, se o seu estado também tiver 2º turno para governador, vota para governador. Cada número tem 2 dígitos.</p>
        <ol class="urna">
          <li><span>Governador (só nos estados com 2º turno)</span><em><?php echo $box( 2 ); // phpcs:ignore ?></em></li>
          <li><span>Presidente</span><em><?php echo $box( 2 ); // phpcs:ignore ?></em></li>
        </ol>
        <p>Depois de digitar, confira a foto e o nome na tela e aperte o botão verde <b>Confirma</b>. Deputados e senadores já foram eleitos no 1º turno e não aparecem mais.</p>
        <p><a href="<?php echo esc_url( $cand ); ?>">Veja quem está no 2º turno no seu estado</a>.</p>
      </section>

<?php else : ?>
      <section class="gs" id="votos">
        <h2>Os 6 votos na urna, nesta ordem</h2>
        <p>Em 2026 você vota seis vezes. A urna pede sempre na mesma ordem e mostra uma barra de progresso para você saber quanto falta:</p>
        <ol class="urna">
          <li><span>Deputado federal</span><em><?php echo $box( 4 ); // phpcs:ignore ?></em></li>
          <li><span>Deputado estadual (ou distrital, no DF)</span><em><?php echo $box( 5 ); // phpcs:ignore ?></em></li>
          <li><span>Senador, 1ª vaga</span><em><?php echo $box( 3 ); // phpcs:ignore ?></em></li>
          <li><span>Senador, 2ª vaga</span><em><?php echo $box( 3 ); // phpcs:ignore ?></em></li>
          <li><span>Governador</span><em><?php echo $box( 2 ); // phpcs:ignore ?></em></li>
          <li><span>Presidente</span><em><?php echo $box( 2 ); // phpcs:ignore ?></em></li>
        </ol>
        <p>Os quadradinhos mostram quantos números tem cada voto. Depois de digitar, confira a foto e o nome na tela e aperte o botão verde <b>Confirma</b>.</p>
        <div class="box"><b>Atenção no Senado.</b> Este ano cada estado elege dois senadores, então você dá dois votos, em candidatos diferentes. Cada número de senador tem 3 dígitos. Se digitar só os 2 números do partido, a urna não deixa avançar.</div>
        <p>Não sabe os números? <a href="<?php echo esc_url( $cand ); ?>">Veja quem está na sua urna</a> e anote.</p>
      </section>

<?php endif; ?>
      <section class="gs" id="documento">
        <h2>Qual documento levar</h2>
        <p>Leve <b>um documento oficial com foto</b>. Valem:</p>
        <ul>
          <li>RG (carteira de identidade) ou a nova Carteira de Identidade Nacional (CIN)</li>
          <li>Identidade social</li>
          <li>Passaporte</li>
          <li>Carteira de motorista (CNH)</li>
          <li>Carteira de trabalho de papel</li>
          <li>Carteira de conselho profissional (OAB, CRM e outras)</li>
          <li>O aplicativo e-Título, <b>desde que mostre a sua foto</b></li>
        </ul>
        <p>Documento vencido também vale, se der para reconhecer você. <b>Não valem</b> certidão de nascimento, certidão de casamento e carteira de trabalho digital. O título de papel não é obrigatório.</p>
        <div class="box">Vai usar o e-Título? Abra o app antes de domingo e veja se a sua foto aparece. Se não aparecer, leve outro documento.</div>
      </section>

      <section class="gs" id="onde">
        <h2>Onde eu voto</h2>
        <p>O endereço da sua seção aparece no aplicativo <b>e-Título</b> e no site do TSE (tse.jus.br), na área de título e local de votação. Confira antes de sair: às vezes o local muda de uma eleição para outra.</p>
      </section>

      <section class="gs" id="cabine">
        <h2>Colinha pode. Celular não.</h2>
        <div class="duas">
          <div><h3>Pode levar</h3><ul><li>A "colinha": um papel com os números dos seus candidatos</li></ul></div>
          <div><h3>Não pode na cabine</h3><ul><li>Celular</li><li>Câmera ou filmadora</li><li>Qualquer aparelho que registre o voto</li></ul></div>
        </div>
        <p>A colinha tem que ser de papel. Foto dos números no celular não serve, porque o celular fica de fora. Você deixa o aparelho com os mesários enquanto vota.</p>
      </section>

      <section class="gs" id="dia">
        <h2>O que pode e o que é crime no dia</h2>
        <div class="duas">
          <div><h3>Pode</h3><ul><li>Mostrar em quem você vai votar de forma individual e silenciosa: camiseta, broche, adesivo, bandeira</li><li>Sair do trabalho pelo tempo necessário para votar, sem desconto no salário</li></ul></div>
          <div><h3>Não pode</h3><ul><li>Boca de urna: pedir voto, entregar santinho ou tentar convencer eleitor perto do local de votação. É crime eleitoral</li><li>Manifestação em grupo ou com barulho</li><li>Distribuir camisetas</li></ul></div>
        </div>
        <p>Entre 29 de setembro e 6 de outubro, nenhum eleitor pode ser preso, a não ser em flagrante ou por condenação definitiva, entre outros casos previstos em lei.</p>
      </section>

      <section class="gs" id="obrigado">
        <h2>Quem é obrigado a votar</h2>
        <div class="duas">
          <div><h3>Obrigatório</h3><ul><li>Quem sabe ler e escrever e tem de 18 a 69 anos</li></ul></div>
          <div><h3>Opcional</h3><ul><li>Quem tem 16 ou 17 anos</li><li>Quem tem 70 anos ou mais</li><li>Quem não sabe ler e escrever</li></ul></div>
        </div>
      </section>

      <section class="gs" id="faltar">
        <h2>Não vou votar. E agora?</h2>
        <p>Se você é obrigado a votar e não vai, precisa <b>justificar</b> ou <b>pagar a multa</b>. Dá para justificar de dois jeitos:</p>
        <ul>
          <li><b>No próprio dia:</b> pelo app e-Título ou preenchendo o requerimento de justificativa em qualquer seção eleitoral ou mesa de justificativa. Não precisa mostrar comprovante.</li>
          <li><b>Depois:</b> em até 60 dias, com um documento que explique o motivo. Para o 1º turno, o prazo vai até <b>3 de dezembro de 2026</b>. Para o 2º turno, até <b>8 de janeiro de 2027</b>.</li>
        </ul>
        <?php if ( $t2 ) : ?>
        <div class="box"><b>Faltou no 1º turno?</b> Você pode votar normalmente no 2º. Cada turno conta como uma eleição separada, então a falta do dia 4 precisa ser justificada à parte, até 3 de dezembro, ou paga com a multa.</div>
        <?php endif; ?>
        <p>Não justificou? A multa é de <b>R$ 3,51 por turno</b>. A guia sai pelo e-Título, pelo site do TRE do seu estado ou em qualquer cartório eleitoral, e dá para pagar por Pix ou cartão de crédito.</p>
        <div class="box alerta"><b>Cuidado com as três faltas.</b> Quem falta três vezes seguidas (cada turno conta como uma eleição) sem justificar nem pagar pode ter o título cancelado. E com o título irregular fica difícil tomar posse em concurso público, receber alguns pagamentos do governo, participar de licitações, se matricular em escola pública e tirar alguns documentos.</div>
      </section>

      <section class="gs" id="transito">
        <h2>Vou estar em outra cidade</h2>
        <p>O pedido de voto em trânsito foi de 20 de julho a 20 de agosto e já acabou. Quem pediu vota no local escolhido, nos turnos que marcou no pedido. Se estiver em outro estado, só vota para presidente. Quem não pediu e estiver longe de casa no domingo precisa justificar.</p>
      </section>

      <section class="gs" id="prioridade">
        <h2>Prioridade e acessibilidade</h2>
        <ul>
          <li>Pessoas com mais de 80 anos passam na frente de todo mundo na fila.</li>
          <li>Pessoas com deficiência podem ser ajudadas por alguém de confiança na hora de votar.</li>
          <li>A urna tem áudio com fone de ouvido, teclado em braile e intérprete de Libras.</li>
          <li>Eleitores indígenas podem votar na própria língua.</li>
        </ul>
      </section>

      <section class="gs" id="branco">
        <h2>Voto branco e voto nulo</h2>
        <p>Branco e nulo <b>não vão para nenhum candidato</b>. O resultado é calculado só com os votos válidos, que são os votos dados a candidatos. Para votar em branco, aperte a tecla <b>Branco</b> e depois <b>Confirma</b>. O voto nulo acontece quando você digita um número que não existe e confirma.</p>
      </section>

      <section class="gs" id="depois">
        <h2>Depois das 17h</h2>
        <p>Quando a votação termina, cada urna imprime o <b>boletim de urna</b>, com os votos daquela seção, e uma cópia fica colada no local. A urna não tem internet: o resultado sai num dispositivo de memória, é levado para a Justiça Eleitoral e enviado por uma rede própria. Antes de entrar na soma, o sistema confere a assinatura digital de cada urna.</p>
        <p>O TSE divulga o resultado de cada seção e o total. Você acompanha tudo, em tempo real, na nossa <a href="<?php echo esc_url( $ap ); ?>">página de apuração</a>, do Brasil até a sua cidade.</p>
      </section>

      <section class="gs" id="datas">
        <h2>Datas que importam</h2>
        <details class="qa"<?php echo $t2 ? '' : ' open'; ?>><summary>4 de outubro</summary><p>1º turno, das 8h às 17h (horário de Brasília).</p></details>
        <details class="qa"<?php echo $t2 ? ' open' : ''; ?>><summary>25 de outubro</summary><p>2º turno para presidente e governador, onde for preciso.</p></details>
        <details class="qa"><summary>3 de dezembro</summary><p>Último dia para justificar a falta no 1º turno.</p></details>
        <details class="qa"><summary>18 de dezembro</summary><p>Prazo final para a diplomação dos eleitos.</p></details>
        <details class="qa"><summary>5 e 6 de janeiro de 2027</summary><p>Posse do presidente (dia 5) e dos governadores (dia 6).</p></details>
        <details class="qa"><summary>8 de janeiro de 2027</summary><p>Último dia para justificar a falta no 2º turno.</p></details>
      </section>

      <section class="gs" id="fontes">
        <h2>Fontes</h2>
        <ul class="fontes">
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Setembro/manual-do-eleitor-veja-como-se-preparar-para-a-votacao" target="_blank" rel="noopener">TSE: Manual do Eleitor, como se preparar para a votação</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Setembro/faltam-26-dias-votacao-comeca-e-termina-no-mesmo-horario-em-todo-o-pais" target="_blank" rel="noopener">TSE: votação começa e termina no mesmo horário em todo o país</a></li>
          <li><a href="https://www.tre-sp.jus.br/comunicacao/noticias/2026/Agosto/eleicoes-2026-confira-a-ordem-dos-6-votos-na-urna-e-como-usar-a-colinha-eleitoral" target="_blank" rel="noopener">TRE-SP: a ordem dos 6 votos na urna e a colinha</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Setembro/por-dentro-das-eleicoes-confira-as-regras-para-o-dia-da-votacao" target="_blank" rel="noopener">TSE: regras para o dia da votação</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Setembro/faltam-13-dias-saiba-como-justificar-a-ausencia-nas-eleicoes-2026" target="_blank" rel="noopener">TSE: como justificar a ausência nas Eleições 2026</a></li>
          <li><a href="https://www.cnnbrasil.com.br/eleicoes/eleicoes-2026-saiba-qual-o-valor-da-multa-para-quem-nao-votar/" target="_blank" rel="noopener">CNN Brasil: o valor da multa para quem não votar</a></li>
          <li><a href="https://www.tre-rs.jus.br/comunicacao/noticias/2026/Setembro/eleicoes-2026-quem-e-obrigado-a-votar-nas-eleicoes-2026-veja-as-regras-e-as-consequencias-de-nao-comparecer" target="_blank" rel="noopener">TRE-RS: quem é obrigado a votar e as consequências de faltar</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Julho/manual-do-eleitor-saiba-como-funciona-o-voto-em-transito-nas-eleicoes-2026-1" target="_blank" rel="noopener">TSE: como funciona o voto em trânsito</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Setembro/faltam-7-dias-veja-qual-e-o-caminho-do-voto-depois-de-encerrada-a-votacao" target="_blank" rel="noopener">TSE: o caminho do voto depois da votação</a></li>
          <li><a href="https://www.tse.jus.br/comunicacao/noticias/2026/Marco/eleicoes-2026-confira-as-principais-datas-do-calendario-eleitoral" target="_blank" rel="noopener">TSE: principais datas do calendário eleitoral</a></li>
        </ul>
      </section>
    </div>
  </div>
</main>
