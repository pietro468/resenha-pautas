<?php
/**
 * Proteções do site (análise de segurança de 30/09/2026).
 * 1. Esconde a lista de usuários e o login do administrador de quem não está logado.
 * 4. Limita o contador de "Mais lidos" a 1 leitura por pessoa por hora em cada matéria.
 * 5. Cabeçalhos de segurança básicos e versão do WordPress escondida.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------- 1. usuários ---------- */
add_filter( 'rest_endpoints', function ( $e ) {
	if ( is_user_logged_in() ) { return $e; }
	foreach ( array_keys( $e ) as $rota ) {
		if ( 0 === strpos( $rota, '/wp/v2/users' ) ) { unset( $e[ $rota ] ); }
	}
	return $e;
} );
/* ?author=1 e /author/login/ levavam ao nome de login; o site usa as páginas /autor/ do tema */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() ) { return; }
	if ( is_author() || isset( $_GET['author'] ) ) { // phpcs:ignore
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}, 0 );
add_filter( 'oembed_response_data', function ( $d ) { unset( $d['author_name'], $d['author_url'] ); return $d; } );
add_filter( 'wpseo_sitemap_exclude_author', function () { return array(); } );
add_filter( 'wpseo_sitemap_author_content_types', '__return_empty_array' );
add_filter( 'wp_sitemaps_add_provider', function ( $p, $nome ) { return 'users' === $nome ? false : $p; }, 10, 2 );

/* ---------- 4. contador de leituras: 1 por pessoa por hora ---------- */
add_filter( 'rest_pre_dispatch', function ( $res, $server, $req ) {
	if ( ! preg_match( '#^/rr/v1/view/(\d+)$#', $req->get_route(), $m ) ) { return $res; }
	$ip  = isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? $_SERVER['HTTP_CF_CONNECTING_IP'] : ( $_SERVER['REMOTE_ADDR'] ?? '' ); // phpcs:ignore
	$k   = 'rr_v_' . md5( $ip . '|' . $m[1] );
	if ( get_transient( $k ) ) { return array( 'ok' => true ); } // já contou esta hora
	set_transient( $k, 1, HOUR_IN_SECONDS );
	return $res;
}, 10, 3 );

/* ---------- 5. cabeçalhos de segurança ---------- */
add_action( 'send_headers', function () {
	if ( is_admin() ) { return; }
	header( 'X-Content-Type-Options: nosniff' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()' );
	if ( is_ssl() || 'https' === strtolower( (string) ( $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '' ) ) ) { // phpcs:ignore
		 header( 'Strict-Transport-Security: max-age=31536000' ); }
} );
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );
