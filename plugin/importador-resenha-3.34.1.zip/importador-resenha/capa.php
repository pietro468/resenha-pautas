<?php
/* Capa gerada automaticamente quando nenhuma foto baixa */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function rri_wrap( $text, $font, $size, $maxw ) {
	$words = preg_split( '/\s+/u', trim( $text ) );
	$lines = array(); $cur = '';
	foreach ( $words as $w ) {
		$try = '' === $cur ? $w : $cur . ' ' . $w;
		$bb = imagettfbbox( $size, 0, $font, $try );
		if ( ( $bb[2] - $bb[0] ) > $maxw && '' !== $cur ) { $lines[] = $cur; $cur = $w; } else { $cur = $try; }
	}
	if ( '' !== $cur ) { $lines[] = $cur; }
	return $lines;
}

/** cria um PNG 1600x900 com o título e devolve o caminho, ou WP_Error */
function rri_make_cover( $title, $cat = '' ) {
	if ( ! function_exists( 'imagettftext' ) ) { return new WP_Error( 'gd', 'servidor sem GD/FreeType' ); }
	$W = 1600; $H = 900;
	$font = __DIR__ . '/assets/brim-face.ttf';
	$im = imagecreatetruecolor( $W, $H );
	for ( $y = 0; $y < $H; $y++ ) {
		$t = $y / $H;
		$c = imagecolorallocate( $im, (int) ( 26 - 9 * $t ), (int) ( 60 - 24 * $t ), (int) ( 45 - 18 * $t ) );
		imageline( $im, 0, $y, $W, $y, $c );
	}
	$sym = @imagecreatefrompng( __DIR__ . '/assets/simbolo.png' );
	if ( $sym ) {
		imagealphablending( $im, true );
		$sw = imagesx( $sym );
		$tmp = imagecreatetruecolor( $sw, $sw ); imagealphablending( $tmp, false ); imagesavealpha( $tmp, true );
		imagecopy( $tmp, $sym, 0, 0, 0, 0, $sw, $sw );
		for ( $x = 0; $x < $sw; $x++ ) { for ( $y = 0; $y < $sw; $y++ ) {
			$px = imagecolorat( $tmp, $x, $y ); $a = ( $px >> 24 ) & 0x7F;
			$na = 127 - (int) round( ( 127 - $a ) * 0.09 );
			imagesetpixel( $tmp, $x, $y, imagecolorallocatealpha( $tmp, 255, 255, 255, $na ) );
		} }
		imagecopy( $im, $tmp, $W - $sw + 120, (int) ( ( $H - $sw ) / 2 ), 0, 0, $sw, $sw );
	}
	$white = imagecolorallocate( $im, 255, 255, 255 );
	$mint  = imagecolorallocate( $im, 143, 217, 179 );
	$muted = imagecolorallocate( $im, 185, 205, 195 );
	$pad = 110; $maxw = $W - $pad * 2 - 120;
	$title = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $title, 'UTF-8' ) : strtoupper( $title );
	for ( $size = 96; $size >= 50; $size -= 4 ) { $lines = rri_wrap( $title, $font, $size, $maxw ); if ( count( $lines ) <= 4 ) { break; } }
	$lh = (int) ( $size * 1.32 );
	$blockh = count( $lines ) * $lh;
	$y0 = (int) ( ( $H - $blockh ) / 2 ) + $size;
	if ( $cat ) { imagettftext( $im, 26, 0, $pad, $y0 - $size - 44, $mint, $font, function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $cat, 'UTF-8' ) : strtoupper( $cat ) ); }
	foreach ( $lines as $i => $ln ) { imagettftext( $im, $size, 0, $pad, $y0 + $i * $lh, $white, $font, $ln ); }
	imagettftext( $im, 24, 0, $pad, $H - 70, $muted, $font, 'RESENHA RENTÁVEL' );
	$path = wp_tempnam( 'capa-resenha.png' );
	imagepng( $im, $path, 6 );
	imagedestroy( $im );
	return $path;
}
