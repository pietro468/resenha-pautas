<?php
/* Conversor de Markdown (formato dos artigos Resenha) para blocos do WordPress */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function rri_yval( $v ) {
	$v = trim( $v );
	if ( '' === $v ) { return ''; }
	if ( '[' === $v[0] ) {
		$j = json_decode( $v, true );
		if ( is_array( $j ) ) { return $j; }
		$inner = trim( $v, '[] ' );
		if ( '' === $inner ) { return array(); }
		return array_map( function ( $x ) { return trim( trim( $x ), '"\'' ); }, str_getcsv( $inner ) );
	}
	if ( strlen( $v ) >= 2 && $v[0] === substr( $v, -1 ) && ( '"' === $v[0] || "'" === $v[0] ) ) {
		$q = $v[0]; $v = substr( $v, 1, -1 );
		if ( '"' === $q ) { $v = str_replace( array( '\\"', '\\\\' ), array( '"', '\\' ), $v ); }
	}
	return $v;
}

function rri_frontmatter( $text ) {
	$text = preg_replace( "/^\xEF\xBB\xBF/", '', str_replace( "\r\n", "\n", $text ) );
	if ( ! preg_match( '/^---\s*\n(.*?)\n---\s*\n/s', $text, $m ) ) { return array( array(), $text ); }
	$meta = array(); $key = null; $item = null;
	foreach ( explode( "\n", $m[1] ) as $line ) {
		if ( '' === trim( $line ) || 0 === strpos( ltrim( $line ), '#' ) ) { continue; }
		if ( preg_match( '/^([A-Za-z_]+)\s*:\s*(.*)$/u', $line, $mm ) ) {
			$key = strtolower( $mm[1] );
			$meta[ $key ] = '' === trim( $mm[2] ) ? array() : rri_yval( $mm[2] );
			$item = null; continue;
		}
		if ( null === $key ) { continue; }
		if ( preg_match( '/^\s*-\s+([A-Za-z_]+)\s*:\s*(.*)$/u', $line, $mm ) ) {
			if ( ! is_array( $meta[ $key ] ) ) { $meta[ $key ] = array(); }
			$meta[ $key ][] = array( strtolower( $mm[1] ) => rri_yval( $mm[2] ) );
			$item = count( $meta[ $key ] ) - 1; continue;
		}
		if ( preg_match( '/^\s*-\s+(.*)$/u', $line, $mm ) ) {
			if ( ! is_array( $meta[ $key ] ) ) { $meta[ $key ] = array(); }
			$meta[ $key ][] = rri_yval( $mm[1] ); $item = null; continue;
		}
		if ( null !== $item && preg_match( '/^\s+([A-Za-z_]+)\s*:\s*(.*)$/u', $line, $mm ) ) {
			$meta[ $key ][ $item ][ strtolower( $mm[1] ) ] = rri_yval( $mm[2] );
		}
	}
	return array( $meta, substr( $text, strlen( $m[0] ) ) );
}

function rri_s( $meta, $k ) { return isset( $meta[ $k ] ) && is_string( $meta[ $k ] ) ? $meta[ $k ] : ''; }

/** mapa arquivo => dados da imagem (url, credito, legenda) */
function rri_imgmeta( $meta ) {
	$out = array();
	if ( ! empty( $meta['imagens'] ) && is_array( $meta['imagens'] ) ) {
		foreach ( $meta['imagens'] as $im ) {
			if ( is_array( $im ) && ! empty( $im['arquivo'] ) ) { $out[ basename( $im['arquivo'] ) ] = $im; }
		}
	}
	return $out;
}

function rri_inline( $s ) {
	$s = htmlspecialchars( $s, ENT_NOQUOTES, 'UTF-8' );
	$s = preg_replace( '/`([^`]+)`/u', '<code>$1</code>', $s );
	$s = preg_replace_callback( '/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/u', function ( $m ) { return '<a href="' . str_replace( '"', '%22', $m[2] ) . '">' . $m[1] . '</a>'; }, $s );
	$s = preg_replace( '/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $s );
	$s = preg_replace( '/(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])/u', '<em>$1</em>', $s );
	$s = preg_replace( '/(?<![\w])_(?!\s)(.+?)(?<!\s)_(?![\w])/u', '<em>$1</em>', $s );
	return $s;
}

function rri_convert( $body, $meta ) {
	$YT    = '/^https?:\/\/(www\.)?(youtube\.com\/(watch\?v=|shorts\/|live\/)|youtu\.be\/)[\w-]{11}\S*$/';
	$LIST  = '/^\s*([-*+]|\d+[.)])\s+/';
	$lines = explode( "\n", trim( $body, "\n" ) );
	$n     = count( $lines );
	$b     = array();
	$imgs  = array();
	$cred  = rri_s( $meta, 'capa_credito' );
	$imeta = rri_imgmeta( $meta );
	$i     = 0;
	while ( $i < $n ) {
		$s = trim( $lines[ $i ] );
		if ( '' === $s ) { $i++; continue; }
		if ( preg_match( '/^(#{2,4})\s+(.*)$/u', $s, $m ) ) {
			$lv = strlen( $m[1] );
			$b[] = '<!-- wp:heading' . ( 2 === $lv ? '' : ' {"level":' . $lv . '}' ) . " -->\n<h$lv class=\"wp-block-heading\">" . rri_inline( $m[2] ) . "</h$lv>\n<!-- /wp:heading -->";
			$i++; continue;
		}
		if ( preg_match( '/^!\[([^\]]*)\]\(([^)\s]+)\)$/u', $s, $m ) ) {
			$f = basename( $m[2] ); $imgs[] = $f;
			$im = $imeta[ $f ] ?? array(); $cap = '';
			$leg = trim( (string) ( $im['legenda'] ?? '' ) ); $cr = trim( (string) ( $im['credito'] ?? '' ) );
			if ( $leg || $cr ) { $cap = rtrim( $leg, '. ' ) . ( $leg && $cr ? '. ' : '' ) . ( $cr ? 'Foto: ' . $cr : '' ); }
			$b[] = '<!-- wp:image {"id":%%ID:' . $f . '%%,"sizeSlug":"large","linkDestination":"none"} -->' . "\n"
				. '<figure class="wp-block-image size-large"><img src="%%URL:' . $f . '%%" alt="' . esc_attr( $m[1] ) . '" class="wp-image-%%ID:' . $f . '%%"/>'
				. ( $cap ? '<figcaption class="wp-element-caption">' . esc_html( $cap ) . '</figcaption>' : '' ) . "</figure>\n<!-- /wp:image -->";
			$i++; continue;
		}
		if ( preg_match( $YT, $s ) ) {
			$b[] = '<!-- wp:embed {"url":"' . $s . '","type":"video","providerNameSlug":"youtube","responsive":true,"className":"wp-embed-aspect-16-9 wp-has-aspect-ratio"} -->' . "\n"
				. '<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">' . "\n$s\n</div></figure>\n<!-- /wp:embed -->";
			$i++; continue;
		}
		if ( preg_match( '/^(-{3,}|\*{3,})$/', $s ) ) {
			$b[] = "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->";
			$i++; continue;
		}
		if ( $cred && preg_match( '/^[*_]?\s*Foto de capa\s*:/iu', $s ) ) { $i++; continue; }
		if ( '>' === $s[0] ) {
			$q = array();
			while ( $i < $n && '' !== trim( $lines[ $i ] ) && '>' === trim( $lines[ $i ] )[0] ) { $q[] = trim( substr( trim( $lines[ $i ] ), 1 ) ); $i++; }
			$txt = trim( implode( ' ', array_filter( $q ) ) );
			if ( preg_match( '/^["“](.+?)["”]\s*(.*)$/u', $txt, $m ) ) { $inner = '“' . $m[1] . '”'; $cite = trim( $m[2], " ,." ); }
			else { $inner = $txt; $cite = ''; }
			$b[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><!-- wp:paragraph -->\n<p>" . rri_inline( $inner ) . "</p>\n<!-- /wp:paragraph -->" . ( $cite ? '<cite>' . rri_inline( $cite ) . '</cite>' : '' ) . "</blockquote>\n<!-- /wp:quote -->";
			continue;
		}
		if ( preg_match( $LIST, $s ) ) {
			$ordered = (bool) preg_match( '/^\d/', $s );
			$items = array();
			while ( $i < $n && preg_match( $LIST, $lines[ $i ] ) ) {
				$items[] = trim( preg_replace( $LIST, '', $lines[ $i ] ) ); $i++;
				while ( $i < $n && 0 === strpos( $lines[ $i ], '  ' ) && '' !== trim( $lines[ $i ] ) && ! preg_match( $LIST, $lines[ $i ] ) ) { $items[ count( $items ) - 1 ] .= ' ' . trim( $lines[ $i ] ); $i++; }
			}
			$lis = '';
			foreach ( $items as $it ) { $lis .= "<!-- wp:list-item -->\n<li>" . rri_inline( $it ) . "</li>\n<!-- /wp:list-item -->"; }
			$tag = $ordered ? 'ol' : 'ul';
			$b[] = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . " -->\n<$tag class=\"wp-block-list\">$lis</$tag>\n<!-- /wp:list -->";
			continue;
		}
		if ( '|' === $s[0] ) {
			$rows = array();
			while ( $i < $n && '' !== trim( $lines[ $i ] ) && '|' === trim( $lines[ $i ] )[0] ) { $rows[] = array_map( 'trim', explode( '|', trim( trim( $lines[ $i ] ), '|' ) ) ); $i++; }
			$head = array_shift( $rows ); $th = ''; $tb = '';
			foreach ( $head as $c ) { $th .= '<th>' . rri_inline( $c ) . '</th>'; }
			foreach ( $rows as $r ) {
				$sep = true; foreach ( $r as $c ) { if ( ! preg_match( '/^:?-{2,}:?$/', $c ) ) { $sep = false; } }
				if ( $sep ) { continue; }
				$tb .= '<tr>'; foreach ( $r as $c ) { $tb .= '<td>' . rri_inline( $c ) . '</td>'; } $tb .= '</tr>';
			}
			$b[] = "<!-- wp:table -->\n<figure class=\"wp-block-table\"><table><thead><tr>$th</tr></thead><tbody>$tb</tbody></table></figure>\n<!-- /wp:table -->";
			continue;
		}
		$p = array( $s ); $i++;
		while ( $i < $n && '' !== trim( $lines[ $i ] ) && ! preg_match( '/^(#{2,4}\s|!\[|>|[-*+]\s|\d+[.)]\s|\|)/u', trim( $lines[ $i ] ) ) && ! preg_match( $YT, trim( $lines[ $i ] ) ) ) { $p[] = trim( $lines[ $i ] ); $i++; }
		$b[] = "<!-- wp:paragraph -->\n<p>" . rri_inline( implode( ' ', $p ) ) . "</p>\n<!-- /wp:paragraph -->";
	}
	return array( implode( "\n\n", $b ), $imgs );
}

/** Lê uma pasta (recursiva) e devolve os artigos encontrados */
function rri_scan( $dir ) {
	$arts = array();
	$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
	$mds = array();
	foreach ( $it as $f ) {
		if ( $f->isFile() && preg_match( '/\.md$/i', $f->getFilename() ) && false === strpos( $f->getPathname(), '__MACOSX' ) ) { $mds[] = $f->getPathname(); }
	}
	sort( $mds );
	foreach ( $mds as $md ) {
		list( $meta, $body ) = rri_frontmatter( file_get_contents( $md ) );
		if ( '' === rri_s( $meta, 'titulo' ) ) { continue; }
		$slug = sanitize_title( rri_s( $meta, 'slug' ) ? rri_s( $meta, 'slug' ) : pathinfo( $md, PATHINFO_FILENAME ) );
		list( $content, $imgs ) = rri_convert( $body, $meta );
		$folder = dirname( $md ) . '/';
		$capa = ( rri_s( $meta, 'capa' ) && file_exists( $folder . rri_s( $meta, 'capa' ) ) ) ? rri_s( $meta, 'capa' ) : '';
		$tags = isset( $meta['tags'] ) ? ( is_array( $meta['tags'] ) ? $meta['tags'] : array_map( 'trim', explode( ',', $meta['tags'] ) ) ) : array();
		$arts[] = array(
			'slug' => $slug, 'dir' => $folder,
			'titulo' => rri_s( $meta, 'titulo' ), 'subtitulo' => rri_s( $meta, 'subtitulo' ), 'categoria' => rri_s( $meta, 'categoria' ), 'assina' => rri_s( $meta, 'assina' ),
			'frase_chave' => rri_s( $meta, 'frase_chave' ), 'meta_descricao' => rri_s( $meta, 'meta_descricao' ),
			'capa' => $capa, 'capa_url' => rri_s( $meta, 'capa_url' ), 'capa_credito' => rri_s( $meta, 'capa_credito' ),
			'data' => rri_s( $meta, 'data' ) ? rri_s( $meta, 'data' ) : rri_s( $meta, 'data_publicacao' ),
			'tags' => array_values( array_filter( array_map( 'strval', $tags ) ) ),
			'imgmeta' => rri_imgmeta( $meta ),
			'youtube' => rri_s( $meta, 'youtube' ),
			'pessoa' => rri_s( $meta, 'pessoa' ),
			'busca_imagem' => rri_s( $meta, 'busca_imagem' ),
			'imagens' => array_values( array_unique( array_merge( (array) $imgs, array_keys( rri_imgmeta( $meta ) ) ) ) ), 'conteudo' => $content, // fotos listadas e fora do texto também baixam (servem para o Instagram)
			'carrossel' => file_exists( $folder . 'carrossel.json' ) ? json_decode( (string) file_get_contents( $folder . 'carrossel.json' ), true ) : null,
		);
	}
	return $arts;
}

/** Aceita 2026-10-05 09:00, 2026-10-05, 05/10/2026 09:00 ou 05/10/2026. Devolve Y-m-d H:i:s ou vazio. */
function rri_parse_date( $s ) {
	$s = trim( (string) $s );
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{1,2}):(\d{2}))?/', $s, $m ) ) { $y = $m[1]; $mo = $m[2]; $d = $m[3]; $h = $m[4] ?? '09'; $mi = $m[5] ?? '00'; }
	elseif ( preg_match( '/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2})[:h](\d{2}))?/', $s, $m ) ) { $d = $m[1]; $mo = $m[2]; $y = $m[3]; $h = $m[4] ?? '09'; $mi = $m[5] ?? '00'; }
	else { return ''; }
	if ( '' === $h ) { $h = '09'; } if ( '' === $mi ) { $mi = '00'; }
	if ( ! checkdate( (int) $mo, (int) $d, (int) $y ) ) { return ''; }
	return sprintf( '%04d-%02d-%02d %02d:%02d:00', $y, $mo, $d, $h, $mi );
}
