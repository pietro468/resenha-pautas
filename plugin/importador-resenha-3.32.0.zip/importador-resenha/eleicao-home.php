<?php
/**
 * Página inicial no período eleitoral (usada pelo plugin no lugar da página inicial do tema).
 * - Até o dia 4: matéria mais recente em destaque + botões "Quem está na sua urna" e "Tira-dúvidas".
 * - Dia 4 antes das 17h: destaque com contagem regressiva + quem concorre + tira-dúvidas.
 * - Dia 4 depois das 17h: apuração ao vivo em destaque + gráfico de presidente.
 * Embaixo à direita, sempre: matérias passando sozinhas.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
rri_el_assets();
$dia   = (bool) rri_el_modo();
$antes = rri_el_antes();
$vivo  = $dia && ! $antes;
$ids   = get_posts( array( 'post_type' => 'post', 'posts_per_page' => 13, 'fields' => 'ids', 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
$feat  = ! $vivo && $ids ? array_shift( $ids ) : 0;
$rot   = array_splice( $ids, 0, 6 );
$grid  = array_slice( $ids, 0, 6 );
$ap    = home_url( '/apuracao/' );
$cand  = home_url( '/candidatos/' );
$guia  = home_url( '/guia-do-eleitor/' );
$img   = function ( $id, $size ) { return function_exists( 'rr_image' ) ? rr_image( $id, $size ) : get_the_post_thumbnail( $id, 'large' ); };
$tag   = function ( $id ) { return function_exists( 'rr_tag_line' ) ? rr_tag_line( $id ) : ''; };
$t2    = 2 === rri_el_fase();
$dias  = (int) ceil( ( rri_el_ts( $t2 ? '2026-10-25 08:00' : '2026-10-04 08:00' ) - time() ) / DAY_IN_SECONDS );
$turno = $t2 ? '2º turno' : '1º turno';
?>
<main id="conteudo" class="rrel rrel-home">
  <?php if ( $dia ) : ?>
  <div class="strip"><div class="wrap">
    <?php if ( $antes ) : ?>
      <span><b><?php echo $t2 ? 'HOJE É DIA DE 2º TURNO' : 'HOJE É DIA DE ELEIÇÃO'; ?></b> · Votação das 8h às 17h (horário de Brasília) · resultados a partir das 17h</span>
      <a class="go" href="<?php echo esc_url( $cand ); ?>">Veja quem concorre ›</a>
    <?php else : ?>
      <span class="aovivo"><span class="livedot"></span>AO VIVO</span>
      <span>Apuração do <?php echo esc_html( $turno ); ?> · <b class="num js-pst">…</b> das urnas apuradas<span class="js-hora-w"> · atualizado <span class="js-hora"></span></span></span>
      <a class="go" href="<?php echo esc_url( $ap ); ?>">Acompanhe em tempo real ›</a>
    <?php endif; ?>
  </div></div>
  <?php endif; ?>

  <section class="lead"><div class="wrap">
    <?php if ( $feat ) : $t = $tag( $feat ); ?>
      <a class="feature" href="<?php echo esc_url( get_permalink( $feat ) ); ?>">
        <?php echo $img( $feat, 'rr-wide' ); // phpcs:ignore ?>
        <?php if ( $t ) : ?><span class="tag"><?php echo esc_html( $t ); ?></span><?php endif; ?>
        <?php if ( $dia ) : ?><span class="soon"><span class="livedot g"></span>Apuração ao vivo às 17h · <b class="js-cd num"></b></span><?php endif; ?>
        <div class="f-txt">
          <h1><?php echo esc_html( get_the_title( $feat ) ); ?></h1>
          <?php if ( function_exists( 'rr_teaser' ) && ( $s = rr_teaser( $feat, 24 ) ) ) : ?><p><?php echo esc_html( $s ); ?></p><?php endif; ?>
        </div>
      </a>
    <?php else : ?>
      <a class="feature hero" href="<?php echo esc_url( $ap ); ?>">
        <div class="kick"><span class="aovivo"><span class="livedot"></span>AO VIVO</span><span>Eleições 2026 · <?php echo esc_html( $turno ); ?></span></div>
        <div class="h-txt">
          <h1>Apuração em tempo real: veja o resultado no Brasil, no seu estado e na sua cidade</h1>
          <p><?php echo $t2 ? 'Presidente e governador. A página se atualiza sozinha, sem precisar recarregar.' : 'Presidente, governador, senador e deputados. A página se atualiza sozinha, sem precisar recarregar.'; ?></p>
        </div>
        <div class="urnas">
          <div class="row"><span>Urnas apuradas</span><span class="big num js-pst">…</span></div>
          <div class="bar"><i class="js-pstbar" style="width:0%"></i></div>
        </div>
        <div class="ctas"><span class="btn brand">Abrir a apuração</span><span class="btn ghost">Buscar minha cidade</span></div>
      </a>
    <?php endif; ?>

    <div class="duo">
      <?php if ( $vivo ) : ?>
      <section class="card-el" aria-label="Presidente">
        <div class="card-h"><h2><span class="livedot"></span>Presidente</h2><small><span class="js-pst num">…</span> apuradas</small></div>
        <div class="mini-list" id="el-mini"><div class="nores">Carregando…</div></div>
        <div class="cfoot"><span class="fonte">Dados: TSE · votos válidos</span><a href="<?php echo esc_url( $ap ); ?>">Ver completo ›</a></div>
      </section>
      <?php else : ?>
      <section class="card-el el-cta" aria-label="Eleições 2026">
        <div class="card-h"><h2>Eleições 2026</h2><small><?php echo $dia ? 'É hoje' : ( $dias > 1 ? ( $t2 ? '2º turno em ' : 'Faltam ' ) . (int) $dias . ' dias' : ( 1 === $dias ? ( $t2 ? '2º turno amanhã' : 'É amanhã' ) : '' ) ); ?></small></div>
        <?php if ( $dia ) : ?>
          <a class="cta-cand" href="<?php echo esc_url( $cand ); ?>"><b><?php echo $t2 ? 'Quem disputa o 2º turno' : 'Quem concorre a presidente'; ?></b></a>
          <div class="mini-list scroll sm" id="el-mini"><div class="nores">Carregando…</div></div>
        <?php else : ?>
          <a class="cta big" href="<?php echo esc_url( $cand ); ?>">
            <span class="faces" id="el-faces" aria-hidden="true"></span>
            <b>Quem está na sua urna</b><span><?php echo $t2 ? 'Os candidatos do 2º turno, com foto, número, bens e dinheiro da campanha' : 'Todos os candidatos com foto, número, bens e dinheiro da campanha'; ?></span><i aria-hidden="true">›</i>
          </a>
        <?php endif; ?>
        <a class="cta light" href="<?php echo esc_url( $guia ); ?>"><b>Tira-dúvidas do eleitor</b><span>Horário, documentos, ordem dos votos e como justificar</span><i aria-hidden="true">›</i></a>
      </section>
      <?php endif; ?>
      <?php if ( $rot ) : ?>
      <div class="rot" id="el-rot">
        <?php foreach ( $rot as $i => $id ) : $t = $tag( $id ); ?>
        <a class="feature mini<?php echo 0 === $i ? ' on' : ''; ?>" href="<?php echo esc_url( get_permalink( $id ) ); ?>">
          <?php echo $img( $id, 'rr-card' ); // phpcs:ignore ?>
          <?php if ( $t ) : ?><span class="tag"><?php echo esc_html( $t ); ?></span><?php endif; ?>
          <div class="f-txt"><h2><?php echo esc_html( get_the_title( $id ) ); ?></h2></div>
        </a>
        <?php endforeach; ?>
        <div class="dots"><?php foreach ( $rot as $i => $id ) : ?><i<?php echo 0 === $i ? ' class="on"' : ''; ?>></i><?php endforeach; ?></div>
      </div>
      <?php endif; ?>
    </div>
  </div></section>

  <?php if ( $grid ) : ?>
  <section class="latest"><div class="wrap">
    <h2 class="sec-h">Últimos artigos</h2>
    <?php if ( function_exists( 'rr_grid' ) ) { rr_grid( $grid ); } ?>
    <div class="more-row"><a class="btn line" href="<?php echo esc_url( function_exists( 'rr_link' ) ? rr_link( 'artigos' ) : home_url( '/' ) ); ?>">Ver todos os artigos</a></div>
  </div></section>
  <?php endif; ?>
</main>
<?php
get_footer();
