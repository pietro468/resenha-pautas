<?php
/* Busca de fotos com licença livre: Wikipédia, Wikimedia Commons e Openverse */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function rri_api_json( $url ) {
	$r = wp_remote_get( $url, array( 'timeout' => 25, 'user-agent' => 'ResenhaRentavelBot/1.0 (+' . home_url( '/' ) . ')' ) );
	if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) { return null; }
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	return is_array( $j ) ? $j : null;
}

function rri_lic_ok( $lic ) {
	$l = strtolower( trim( (string) $lic ) );
	if ( '' === $l ) { return false; }
	if ( preg_match( '/\bnc\b|-nc\b|non.?commercial/', $l ) ) { return false; }
	if ( preg_match( '/\bnd\b|-nd\b|no.?deriv/', $l ) ) { return false; }
	if ( false !== strpos( $l, 'fair use' ) || false !== strpos( $l, 'copyright' ) ) { return false; }
	return (bool) preg_match( '/\bcc\b|cc[ -]|cc0|public domain|domínio público|dominio publico|\bpd\b|pd-|gfdl/u', $l );
}

/** dados de um arquivo do Commons: url (2000px), crédito, largura, altura, licença */
function rri_commons_info( $file ) {
	$file = preg_replace( '/^(File|Ficheiro|Arquivo|Imagem):/i', '', $file );
	$j = rri_api_json( 'https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=2000&titles=' . rawurlencode( 'File:' . $file ) );
	$p = $j['query']['pages'][0] ?? null;
	if ( ! $p || ! empty( $p['missing'] ) || empty( $p['imageinfo'][0] ) ) { return null; }
	return rri_commons_pick( $p['imageinfo'][0], $p['title'] ?? $file );
}

function rri_commons_pick( $ii, $title ) {
	$m   = $ii['extmetadata'] ?? array();
	$lic = $m['LicenseShortName']['value'] ?? '';
	if ( ! rri_lic_ok( $lic ) ) { return null; }
	if ( ! empty( $ii['mime'] ) && ! in_array( $ii['mime'], array( 'image/jpeg', 'image/webp' ), true ) ) { return null; }
	$artist = trim( wp_strip_all_tags( html_entity_decode( $m['Artist']['value'] ?? '', ENT_QUOTES ) ) );
	$artist = preg_replace( '/\s+/', ' ', $artist );
	if ( strlen( $artist ) > 60 || '' === $artist ) { $artist = 'Wikimedia Commons'; } else { $artist .= '/Wikimedia Commons'; }
	$txt = $title . ' ' . wp_strip_all_tags( html_entity_decode( ( $m['ImageDescription']['value'] ?? '' ) . ' ' . ( $m['ObjectName']['value'] ?? '' ) . ' ' . str_replace( '|', ' ', $m['Categories']['value'] ?? '' ), ENT_QUOTES ) );
	return array(
		'url'    => $ii['thumburl'] ?? $ii['url'],
		'w'      => (int) ( $ii['width'] ?? 0 ),
		'h'      => (int) ( $ii['height'] ?? 0 ),
		'credit' => $artist . ' (' . $lic . ')',
		'title'  => $title,
		'text'   => $txt,
	);
}

/** foto principal da pessoa na Wikipédia (pt, depois en), só se a licença for livre */
function rri_person_photo( $name ) {
	$name = trim( $name );
	if ( '' === $name ) { return null; }
	foreach ( array( 'pt', 'en' ) as $lang ) {
		$j = rri_api_json( 'https://' . $lang . '.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&redirects=1&prop=pageimages&piprop=name&generator=search&gsrlimit=1&gsrsearch=' . rawurlencode( $name ) );
		$p = $j['query']['pages'][0] ?? null;
		if ( $p && ! empty( $p['pageimage'] ) ) {
			$info = rri_commons_info( $p['pageimage'] );
			if ( $info ) { return $info; }
		}
	}
	/* a Wikipédia não tem foto: procura no Commons e no Openverse fotos cujo título tenha o nome da pessoa */
	$c = rri_person_candidates( $name );
	return $c ? $c[0] : null;
}

/** fotos em que o título do arquivo traz o nome da pessoa (evita foto de outra coisa) */
function rri_person_candidates( $name, $minw = 500 ) {
	$toks = array_filter( preg_split( '/\s+/', rri_norm( $name ) ), function ( $t ) { return strlen( $t ) > 2; } );
	$first = reset( $toks ); $last = end( $toks );
	$out = array(); $seen = array();
	foreach ( array_merge( rri_commons_search( $name, 20, false, $minw ), rri_openverse_person( $name ) ) as $c ) {
		$t = rri_norm( ( $c['title'] ?? '' ) . ' ' . ( $c['text'] ?? '' ) );
		if ( ! $first || false === strpos( $t, $first ) || false === strpos( $t, $last ) ) { continue; }
		if ( isset( $seen[ $c['url'] ] ) ) { continue; }
		$seen[ $c['url'] ] = 1; $out[] = $c;
	}
	usort( $out, function ( $a, $b ) { return ( $b['w'] ?? 0 ) <=> ( $a['w'] ?? 0 ); } );
	return $out;
}

function rri_openverse_person( $name ) {
	$j = rri_api_json( 'https://api.openverse.org/v1/images/?page_size=20&license_type=commercial&q=' . rawurlencode( '"' . $name . '"' ) );
	$out = array();
	foreach ( (array) ( $j['results'] ?? array() ) as $r ) {
		if ( empty( $r['url'] ) || (int) ( $r['width'] ?? 0 ) < 500 || ! in_array( strtolower( $r['license'] ?? '' ), array( 'by', 'by-sa', 'cc0', 'pdm' ), true ) ) { continue; }
		$lic = strtolower( $r['license'] );
		$lic = 'cc0' === $lic ? 'CC0' : ( 'pdm' === $lic ? 'domínio público' : 'CC ' . strtoupper( $lic ) . ' ' . ( $r['license_version'] ?? '' ) );
		$who = trim( (string) ( $r['creator'] ?? '' ) );
		$out[] = array( 'url' => $r['url'], 'w' => (int) $r['width'], 'h' => (int) ( $r['height'] ?? 0 ), 'credit' => ( $who ? $who . '/' : '' ) . ucfirst( (string) ( $r['source'] ?? 'Openverse' ) ) . ' (' . trim( $lic ) . ')', 'title' => $r['title'] ?? '', 'text' => $r['title'] ?? '' );
	}
	return $out;
}

/** busca no Commons; devolve lista de fotos boas (paisagem de preferência) */
function rri_commons_search( $q, $limit = 12, $wide = true, $minw = 1000 ) {
	$j = rri_api_json( 'https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrnamespace=6&gsrlimit=' . (int) $limit . '&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=2000&gsrsearch=' . rawurlencode( 'filetype:bitmap ' . $q . ' -chart -graph -map -logo -diagram -plot -flag' ) );
	$out = array();
	foreach ( (array) ( $j['query']['pages'] ?? array() ) as $p ) {
		if ( empty( $p['imageinfo'][0] ) ) { continue; }
		$i = rri_commons_pick( $p['imageinfo'][0], $p['title'] );
		if ( ! $i || $i['w'] < $minw ) { continue; }
		if ( $wide && $i['w'] < $i['h'] ) { continue; }
		$out[] = $i;
	}
	return $out;
}

/** busca no Openverse (Flickr e outros acervos com licença livre para uso comercial) */
function rri_openverse_search( $q ) {
	$j = rri_api_json( 'https://api.openverse.org/v1/images/?page_size=10&license_type=commercial&aspect_ratio=wide&size=large&q=' . rawurlencode( $q ) );
	$out = array();
	foreach ( (array) ( $j['results'] ?? array() ) as $r ) {
		if ( empty( $r['url'] ) || ! in_array( strtolower( $r['license'] ?? '' ), array( 'by', 'by-sa', 'cc0', 'pdm' ), true ) ) { continue; }
		$lic = strtolower( $r['license'] );
		$lic = 'cc0' === $lic ? 'CC0' : ( 'pdm' === $lic ? 'domínio público' : 'CC ' . strtoupper( $lic ) . ' ' . ( $r['license_version'] ?? '' ) );
		$who = trim( (string) ( $r['creator'] ?? '' ) );
		$src = ucfirst( (string) ( $r['source'] ?? 'Openverse' ) );
		$tags = implode( ' ', wp_list_pluck( (array) ( $r['tags'] ?? array() ), 'name' ) );
		$out[] = array( 'url' => $r['url'], 'w' => (int) ( $r['width'] ?? 0 ), 'h' => (int) ( $r['height'] ?? 0 ), 'credit' => ( $who ? $who . '/' : '' ) . $src . ' (' . trim( $lic ) . ')', 'title' => $r['title'] ?? '', 'text' => ( $r['title'] ?? '' ) . ' ' . $tags );
	}
	return $out;
}

/** tira o nome da pessoa do título ("Quem é Daniel Vorcaro: a ascensão..." vira "Daniel Vorcaro") */
function rri_person_from_title( $title ) {
	$t = trim( preg_split( '/[:?]/u', $title )[0] );
	$t = preg_replace( '/^(quem (é|foi)|a história de|história de|patrimônio de|fortuna de|vida de|biografia de|a vida de)\s+/iu', '', $t );
	$t = preg_replace( '/\s+(bilionário|bilionária|milionário|milionária|rico|rica)$/iu', '', $t );
	return trim( $t );
}

/* ---------- relevância ---------- */

function rri_norm( $s ) { return strtolower( remove_accents( (string) $s ) ); }

function rri_stop( $w ) {
	static $stop = null;
	if ( null === $stop ) {
		$stop = array_flip( explode( ' ', 'a o as os um uma de da do das dos e em no na nos nas por para com sem que qual quais quem como quanto quanta hoje agora ja seu sua seus suas ele ela eles elas mais menos muito pouco sobre entre ate apos antes depois porque pq nao sim ser foi sao tem ter vai vale pena isso esse essa este esta ano anos novo nova tudo todo toda entenda veja saiba guia completo explicado explicada the of and in on for to with from what how why who is are' ) );
	}
	return isset( $stop[ $w ] ) || strlen( $w ) < 3;
}

/** palavras-chave de um texto, cada uma com seus sinônimos em inglês */
function rri_keywords( $q ) {
	static $en = array(
		'dolar' => 'dollar', 'cambio' => 'currency', 'moeda' => 'currency', 'moedas' => 'coins', 'nota' => 'banknote', 'notas' => 'banknotes', 'cedula' => 'banknote', 'cedulas' => 'banknotes',
		'dinheiro' => 'money', 'real' => 'real', 'reais' => 'real', 'bolsa' => 'stock', 'acoes' => 'stocks', 'juros' => 'interest', 'inflacao' => 'inflation', 'imposto' => 'tax', 'impostos' => 'taxes',
		'banco' => 'bank', 'bancos' => 'banks', 'central' => 'central', 'economia' => 'economy', 'mercado' => 'market', 'empresa' => 'company', 'empresas' => 'companies', 'bilionario' => 'billionaire',
		'eleicao' => 'election', 'eleicoes' => 'elections', 'urna' => 'ballot', 'voto' => 'vote', 'presidente' => 'president', 'senado' => 'senate', 'senador' => 'senator', 'camara' => 'chamber',
		'deputado' => 'deputy', 'deputados' => 'deputies', 'congresso' => 'congress', 'supremo' => 'supreme', 'tribunal' => 'court', 'governo' => 'government', 'lei' => 'law', 'policia' => 'police',
		'guerra' => 'war', 'petroleo' => 'oil', 'diesel' => 'diesel', 'combustivel' => 'fuel', 'gasolina' => 'gasoline', 'apostas' => 'betting', 'bets' => 'betting', 'cassino' => 'casino', 'golpe' => 'scam',
		'fraude' => 'fraud', 'crime' => 'crime', 'faccao' => 'gang', 'prisao' => 'prison', 'viagem' => 'travel', 'aeroporto' => 'airport', 'praia' => 'beach', 'cidade' => 'city', 'turismo' => 'tourism',
		'filme' => 'film', 'cinema' => 'cinema', 'futebol' => 'football', 'copa' => 'world cup', 'estadio' => 'stadium', 'carro' => 'car', 'trabalho' => 'work', 'emprego' => 'job', 'salario' => 'wage',
		'aposentadoria' => 'retirement', 'casa' => 'house', 'imovel' => 'real estate', 'aluguel' => 'rent', 'brasil' => 'brazil', 'brasilia' => 'brasilia', 'estados' => 'states', 'unidos' => 'united',
	);
	$out = array();
	foreach ( preg_split( '/[^a-z0-9]+/', rri_norm( $q ) ) as $w ) {
		if ( rri_stop( $w ) ) { continue; }
		$out[ $w ] = isset( $en[ $w ] ) ? array( $w, $en[ $w ] ) : array( $w );
	}
	return $out;
}

/** quantas palavras-chave aparecem no texto da foto */
function rri_score( $kws, $text ) {
	$t = ' ' . preg_replace( '/[^a-z0-9]+/', ' ', rri_norm( $text ) ) . ' ';
	$n = 0;
	foreach ( $kws as $vars ) {
		foreach ( $vars as $v ) { if ( false !== strpos( $t, ' ' . $v ) ) { $n++; break; } }
	}
	return $n;
}

/** é foto de verdade? (nada de gráfico, mapa, logo, gravura antiga ou página de livro) */
function rri_is_photo( $cand ) {
	if ( ! empty( $cand['strict'] ) && preg_match( '/\b(book|books|engraving|illustration|drawing|painting|scan|scanned|page|lithograph|woodcut|1[5-8]\d\d|19[0-5]\d)\b/', rri_norm( $cand['text'] ?? '' ) ) ) { return false; }
	if ( preg_match( '/\b(chart|charts|graph|graphs|diagram|plot|map|maps|logo|logos|infographic|screenshot|flag|flags|coat of arms|icon|timeline|statistics|rate|rates|grafico|mapa|tabela|bandeira|brasao|svg)\b/', rri_norm( $cand['text'] ?? '' ) ) ) { return false; }
	return true;
}

/** a foto é sobre o assunto? a descrição precisa ter pelo menos 2 palavras diferentes do assunto */
function rri_relevant( $kws, $cand ) {
	if ( count( $kws ) < 2 ) { return false; }
	/* só foto de verdade: nada de gráfico, mapa, logo, tabela ou print */
	if ( ! rri_is_photo( $cand ) ) { return false; }
	return rri_score( $kws, $cand['text'] ?? $cand['title'] ?? '' ) >= 2;
}

/** versão em inglês de uma busca (o Commons é quase todo em inglês) */
function rri_en_query( $q ) {
	$kw = rri_keywords( $q );
	$w = array();
	foreach ( $kw as $vars ) { $w[] = end( $vars ); }
	return implode( ' ', $w );
}

/** termos de busca de um artigo, do mais específico ao mais genérico. Nunca uma palavra solta. */
function rri_queries( $a ) {
	$base = array();
	if ( ! empty( $a['busca_imagem'] ) ) { $base[] = $a['busca_imagem']; }
	if ( ! empty( $a['frase_chave'] ) ) { $base[] = $a['frase_chave']; }
	$tags = array_slice( (array) ( $a['tags'] ?? array() ), 0, 3 );
	if ( count( $tags ) >= 2 ) { $base[] = $tags[0] . ' ' . $tags[1]; }
	$base[] = $a['titulo'];
	$q = array();
	foreach ( $base as $b ) {
		$kw = array_slice( rri_keywords( $b ), 0, 4, true );
		if ( count( $kw ) < 2 ) { continue; }
		$en = rri_en_query( $b );
		if ( $en && rri_norm( $en ) !== implode( ' ', array_keys( $kw ) ) ) { $q[] = array( $en, $kw ); }
		$q[] = array( implode( ' ', array_keys( $kw ) ), $kw );
	}
	return $q;
}

/**
 * Procura uma foto que combine com o assunto. Devolve array(url, credit) ou null.
 * $skip: urls que não servem.
 */
function rri_find_photo( $a, $skip = array() ) {
	if ( ! empty( $a['pessoa'] ) ) {
		$p = rri_person_photo( $a['pessoa'] );
		if ( $p && ! in_array( $p['url'], $skip, true ) ) { return $p; }
	}
	/* 1) bancos de fotos modernos (Pexels, Pixabay) */
	foreach ( rri_stock_queries( $a ) as $q ) {
		$kw = rri_keywords( $q );
		foreach ( array_merge( rri_pexels_search( $q, 8 ), rri_pixabay_search( $q, 8 ) ) as $r ) {
			if ( in_array( $r['url'], $skip, true ) ) { continue; }
			if ( ! $kw || rri_score( $kw, $r['text'] ) >= 1 ) { return $r; }
		}
	}
	/* 2) acervos livres (Commons, Openverse), com regra mais rígida */
	$seen = array();
	foreach ( rri_queries( $a ) as $item ) {
		list( $q, $kw ) = $item;
		if ( isset( $seen[ $q ] ) ) { continue; }
		$seen[ $q ] = 1;
		$all = array_merge( rri_commons_search( $q, 12 ), rri_openverse_search( $q ) );
		usort( $all, function ( $x, $y ) use ( $kw ) { return rri_score( $kw, $y['text'] ?? '' ) <=> rri_score( $kw, $x['text'] ?? '' ); } );
		foreach ( $all as $r ) {
			if ( in_array( $r['url'], $skip, true ) ) { continue; }
			$r['strict'] = 1;
			if ( rri_relevant( $kw, $r ) ) { return $r; }
		}
	}
	return null;
}

/* ---------- bancos de fotos modernos (precisam de chave grátis) ---------- */

function rri_keys() { return wp_parse_args( get_option( 'rri_keys', array() ), array( 'pexels' => '', 'pixabay' => '' ) ); }

function rri_pexels_search( $q, $n = 12 ) {
	$k = rri_keys()['pexels'];
	if ( ! $k ) { return array(); }
	$r = wp_remote_get( 'https://api.pexels.com/v1/search?orientation=landscape&size=large&per_page=' . (int) $n . '&query=' . rawurlencode( $q ), array( 'timeout' => 20, 'headers' => array( 'Authorization' => $k ) ) );
	if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) { return array(); }
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	$out = array();
	foreach ( (array) ( $j['photos'] ?? array() ) as $p ) {
		$src = $p['src']['large2x'] ?? ( $p['src']['original'] ?? '' );
		if ( ! $src ) { continue; }
		$out[] = array( 'url' => $src, 'thumb' => $p['src']['medium'] ?? $src, 'w' => (int) ( $p['width'] ?? 0 ), 'h' => (int) ( $p['height'] ?? 0 ),
			'credit' => trim( ( $p['photographer'] ?? '' ) . '/Pexels', '/' ), 'title' => $p['alt'] ?? '', 'text' => ( $p['alt'] ?? '' ) . ' ' . str_replace( '-', ' ', (string) ( $p['url'] ?? '' ) ), 'stock' => 1 );
	}
	return $out;
}

function rri_pixabay_search( $q, $n = 20 ) {
	$k = rri_keys()['pixabay'];
	if ( ! $k ) { return array(); }
	$j = rri_api_json( 'https://pixabay.com/api/?image_type=photo&orientation=horizontal&safesearch=true&min_width=1600&per_page=' . max( 3, (int) $n ) . '&key=' . rawurlencode( $k ) . '&q=' . rawurlencode( mb_substr( $q, 0, 95 ) ) );
	$out = array();
	foreach ( (array) ( $j['hits'] ?? array() ) as $h ) {
		if ( empty( $h['largeImageURL'] ) ) { continue; }
		$out[] = array( 'url' => $h['largeImageURL'], 'thumb' => $h['webformatURL'] ?? $h['largeImageURL'], 'w' => (int) ( $h['imageWidth'] ?? 0 ), 'h' => (int) ( $h['imageHeight'] ?? 0 ),
			'credit' => trim( ( $h['user'] ?? '' ) . '/Pixabay', '/' ), 'title' => $h['tags'] ?? '', 'text' => ( $h['tags'] ?? '' ) . ' ' . str_replace( '-', ' ', (string) ( $h['pageURL'] ?? '' ) ), 'stock' => 1 );
	}
	return $out;
}

/** buscas curtas em inglês para os bancos de fotos (aceitam uma palavra só) */
function rri_stock_queries( $a ) {
	$q = array();
	if ( ! empty( $a['busca_imagem'] ) ) { $q[] = $a['busca_imagem']; }
	foreach ( array( $a['frase_chave'] ?? '', implode( ' ', array_slice( (array) ( $a['tags'] ?? array() ), 0, 2 ) ), $a['titulo'] ?? '' ) as $b ) {
		$kw = array_slice( rri_keywords( $b ), 0, 3, true );
		if ( ! $kw ) { continue; }
		$en = rri_en_query( implode( ' ', array_keys( $kw ) ) );
		if ( $en ) { $q[] = $en; }
		$first = reset( $kw );
		if ( count( $first ) > 1 ) { $q[] = end( $first ); }
	}
	return array_values( array_unique( array_filter( $q ) ) );
}

/** fotos candidatas para a capa (seletor manual): bancos modernos primeiro, depois acervos livres */
function rri_candidates( $a, $custom = '', $max = 18 ) {
	$out = array(); $seen = array();
	$qs = $custom ? array( $custom, rri_en_query( $custom ) ) : rri_stock_queries( $a );
	foreach ( array_unique( array_filter( $qs ) ) as $q ) {
		foreach ( array_merge( rri_pexels_search( $q, 9 ), rri_pixabay_search( $q, 9 ) ) as $c ) {
			if ( isset( $seen[ $c['url'] ] ) ) { continue; }
			$seen[ $c['url'] ] = 1; $out[] = $c;
			if ( count( $out ) >= $max ) { return $out; }
		}
	}
	if ( count( $out ) < 6 ) {
		foreach ( array_slice( $qs, 0, 2 ) as $q ) {
			foreach ( rri_commons_search( $q, 12 ) as $c ) {
				$c['strict'] = 1;
				if ( isset( $seen[ $c['url'] ] ) || ! rri_is_photo( $c ) ) { continue; }
				$seen[ $c['url'] ] = 1; $c['thumb'] = preg_replace( '~/\d+px-~', '/400px-', $c['url'] ); $out[] = $c;
				if ( count( $out ) >= $max ) { return $out; }
			}
		}
	}
	return $out;
}
