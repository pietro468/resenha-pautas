<?php
/**
 * Horário de publicação em todas as datas do site.
 * O tema mostra a data com o formato 'j M Y' (ex.: 30 set 2026).
 * Aqui acrescentamos o horário: "30 set 2026 às 18h15".
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_filter( 'date_i18n', 'rri_data_com_hora', 10, 4 );
function rri_data_com_hora( $data, $formato, $ts, $gmt ) {
	static $dentro = false;
	if ( $dentro || is_admin() || 'j M Y' !== $formato || ! $ts ) {
		return $data;
	}
	$dentro = true;
	$hora   = date_i18n( 'H\hi', $ts, $gmt );
	$dentro = false;
	return $data . ' às ' . $hora;
}
