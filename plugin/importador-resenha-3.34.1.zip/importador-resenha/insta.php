<?php
/**
 * Posts só do Instagram (não aparecem no site).
 * No GitHub: instagram/AAAA-MM-DD/SLUG/post.json, listado em index.json na chave "instagram".
 * post.json: {"titulo","data":"AAAA-MM-DD HH:MM","fotos":[{"arquivo","url","credito"}],"carrossel":{...}}
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	register_post_type( 'rr_insta', array(
		'label'  => 'Posts só do Instagram',
		'labels' => array( 'name' => 'Posts só do Instagram', 'singular_name' => 'Post do Instagram', 'menu_name' => 'Só Instagram' ),
		'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-instagram',
		'supports' => array( 'title', 'thumbnail' ), 'exclude_from_search' => true, 'publicly_queryable' => false, 'show_in_rest' => false,
	) );
} );

function rri_insta_import( $raw, $idx ) {
	$list = is_array( $idx ) ? (array) ( $idx['instagram'] ?? array() ) : array();
	if ( ! $list ) { return; }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$done = (array) get_option( 'rri_insta_done', array() );
	$n = 0;
	foreach ( $list as $it ) {
		$slug = sanitize_title( (string) ( $it['slug'] ?? '' ) );
		if ( $slug && in_array( $slug, $done, true ) ) {
			/* já importado: se o post.json mudou e ainda não foi para o Instagram, atualiza horário e slides */
			$ex = get_page_by_path( $slug, OBJECT, 'rr_insta' );
			if ( $ex && ! get_post_meta( $ex->ID, '_rr_ig_id', true ) && ! empty( $it['pasta'] ) ) {
				$path = implode( '/', array_map( 'rawurlencode', explode( '/', trim( $it['pasta'], '/' ) ) ) ) . '/post.json';
				$js = rri_gh_get( $raw . $path . '?t=' . time() );
				if ( ! is_wp_error( $js ) && md5( $js ) !== get_post_meta( $ex->ID, '_rr_insta_hash', true ) && is_array( $d = json_decode( $js, true ) ) && ! empty( $d['carrossel'] ) ) {
					rri_car_attach( $ex->ID, $d['carrossel'] );
					if ( ! empty( $d['data'] ) ) { update_post_meta( $ex->ID, '_rr_ig_quando', strtotime( $d['data'] . ' America/Sao_Paulo' ) ); }
					update_post_meta( $ex->ID, '_rr_insta_hash', md5( $js ) );
				}
			}
			continue;
		}
		if ( ! $slug || empty( $it['pasta'] ) ) { continue; }
		if ( $n >= 2 ) { break; }
		$path = implode( '/', array_map( 'rawurlencode', explode( '/', trim( $it['pasta'], '/' ) ) ) ) . '/post.json';
		$js = rri_gh_get( $raw . $path . '?t=' . time() );
		if ( is_wp_error( $js ) || ! is_array( $d = json_decode( $js, true ) ) || empty( $d['carrossel'] ) ) { continue; }
		$n++;
		$pid = wp_insert_post( array( 'post_type' => 'rr_insta', 'post_status' => 'publish', 'post_title' => (string) ( $d['titulo'] ?? $slug ), 'post_name' => $slug ) );
		if ( is_wp_error( $pid ) || ! $pid ) { continue; }
		$first = 0;
		foreach ( (array) ( $d['fotos'] ?? array() ) as $f ) {
			if ( empty( $f['url'] ) ) { continue; }
			$name = ! empty( $f['arquivo'] ) ? sanitize_file_name( $f['arquivo'] ) : $slug . '.jpg';
			$aid = rri_sideload_url( $f['url'], $name, $pid, (string) ( $d['titulo'] ?? '' ) );
			if ( is_wp_error( $aid ) ) { rri_gh_log( 'Só Instagram: não baixou a foto ' . esc_html( $name ) . ' (' . esc_html( $aid->get_error_message() ) . ')' ); continue; }
			if ( ! empty( $f['credito'] ) ) { wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . $f['credito'] ) ); }
			if ( ! $first ) { $first = $aid; set_post_thumbnail( $pid, $aid ); }
		}
		rri_car_attach( $pid, $d['carrossel'] );
		$when = ! empty( $d['data'] ) ? strtotime( $d['data'] . ' America/Sao_Paulo' ) : time();
		update_post_meta( $pid, '_rr_ig_quando', $when );
		update_post_meta( $pid, '_rr_insta_hash', md5( $js ) );
		if ( rri_ig_opts()['on'] ) { update_post_meta( $pid, '_rr_ig_pending', time() ); }
		$done[] = $slug;
		update_option( 'rri_insta_done', $done, false );
		rri_gh_log( 'Só Instagram: preparado <a href="' . esc_url( get_edit_post_link( $pid, 'url' ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a>, sai às ' . esc_html( wp_date( 'd/m H:i', $when ) ) );
	}
}
