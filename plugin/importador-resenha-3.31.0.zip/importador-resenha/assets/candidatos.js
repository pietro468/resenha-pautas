/* Quem está na sua urna: lista, filtros e perfil dos candidatos de 2026 (dados abertos do TSE) */
(function () {
  var C = window.RREL; if (!C || !document.getElementById('cd-tabs')) return;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var norm = function (t) { return String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); };
  var brl = function (v) { return (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); };
  var SIL = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12.5a4.8 4.8 0 1 0 0-9.6 4.8 4.8 0 0 0 0 9.6zm0 1.7c-4.6 0-8.6 2.6-9.4 7.8h18.8c-.8-5.2-4.8-7.8-9.4-7.8z"/></svg>';
  var CARGOS = [['pres', 'Presidente'], ['gov', 'Governador'], ['sen', 'Senador'], ['df', 'Dep. federal'], ['de', 'Dep. estadual']];
  var UFS = ['ac','al','ap','am','ba','ce','df','es','go','ma','mt','ms','mg','pa','pb','pr','pe','pi','rj','rn','rs','ro','rr','sc','sp','se','to'];
  var UFN = { ac:'Acre',al:'Alagoas',ap:'Amapá',am:'Amazonas',ba:'Bahia',ce:'Ceará',df:'Distrito Federal',es:'Espírito Santo',go:'Goiás',ma:'Maranhão',mt:'Mato Grosso',ms:'Mato Grosso do Sul',mg:'Minas Gerais',pa:'Pará',pb:'Paraíba',pr:'Paraná',pe:'Pernambuco',pi:'Piauí',rj:'Rio de Janeiro',rn:'Rio Grande do Norte',rs:'Rio Grande do Sul',ro:'Rondônia',rr:'Roraima',sc:'Santa Catarina',sp:'São Paulo',se:'Sergipe',to:'Tocantins',br:'Brasil' };
  var CORES = ['#2f6f8f','#7a4e9c','#b5563d','#3f7d4f','#a1782a','#8c3b5e','#35647a','#6b6f2e','#9a4a2f','#4a5fa8','#5d7a3a','#a04e76','#2e7d74','#7b5a3a','#556270','#8a6d1f'];
  function cor(p) { var h = 0; for (var i = 0; i < p.length; i++) h = (h * 31 + p.charCodeAt(i)) >>> 0; return CORES[h % CORES.length]; }
  function chip(p) { return '<span class="pchip" style="background:' + cor(p || '?') + '">' + esc(p) + '</span>'; }
  function foto(c) {
    var url = c.cargo === 'pres' ? 'https://resultados.tse.jus.br/oficial/ele2026/6257/fotos/br/' : 'https://resultados.tse.jus.br/oficial/ele2026/6259/fotos/' + c.uf + '/';
    return '<span class="photo">' + SIL + '<img src="' + url + esc(c.sq) + '.jpeg" alt="" loading="lazy" onerror="this.remove()"></span>';
  }
  function get(p) { return fetch(C.rest + p, { credentials: 'same-origin' }).then(function (r) { return r.json(); }); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }

  var FAIXAS = [['0', 'Não declarou bens', function (v) { return !v; }], ['1', 'Até R$ 100 mil', function (v) { return v > 0 && v <= 1e5; }], ['2', 'De R$ 100 mil a R$ 1 milhão', function (v) { return v > 1e5 && v <= 1e6; }], ['3', 'De R$ 1 milhão a R$ 10 milhões', function (v) { return v > 1e6 && v <= 1e7; }], ['4', 'Mais de R$ 10 milhões', function (v) { return v > 1e7; }]];
  var GRUPOS = [['p', 'Partido'], ['g', 'Gênero'], ['cor', 'Cor ou raça'], ['instr', 'Grau de instrução'], ['ocup', 'Ocupação'], ['faixa', 'Patrimônio'], ['sit', 'Situação da candidatura'], ['reel', 'Reeleição']];

  var qs = new URLSearchParams(location.search);
  var S = { cargo: qs.get('cargo') || 'pres', uf: (qs.get('uf') || ls('rr_uf') || 'sp').toLowerCase(), q: '', ord: 'nome', f: {}, lim: 48, dados: {}, sq: qs.get('sq') || '' };
  if (!UFN[S.uf] || S.uf === 'br') S.uf = 'sp';
  if (!CARGOS.some(function (c) { return c[0] === S.cargo; })) S.cargo = 'pres';

  $('#cd-tabs').innerHTML = CARGOS.map(function (c) { return '<button type="button" role="tab" data-c="' + c[0] + '">' + c[1] + '</button>'; }).join('');
  $('#cd-uf').innerHTML = '<option value="br">Brasil</option>' + UFS.map(function (u) { return '<option value="' + u + '">' + UFN[u] + '</option>'; }).join('');

  function ufAtual() { return S.cargo === 'pres' ? 'br' : S.uf; }
  function lista() {
    var d = S.dados[ufAtual()]; if (!d || !d.c) return null;
    return d.c.filter(function (c) { return c.cargo === S.cargo && c.urna !== 0; });
  }
  function valor(c, k) {
    if (k === 'faixa') { for (var i = 0; i < FAIXAS.length; i++) if (FAIXAS[i][2](c.bens || 0)) return FAIXAS[i][0]; return ''; }
    if (k === 'reel') return c.reel ? 'Tentando a reeleição' : '';
    return c[k] || '';
  }
  function passa(c, pular) {
    for (var k in S.f) {
      if (k === pular || !S.f[k].length) continue;
      if (S.f[k].indexOf(valor(c, k)) < 0) return false;
    }
    if (S.q) {
      var q = norm(S.q.trim());
      if (q && norm(c.nome).indexOf(q) < 0 && norm(c.nc).indexOf(q) < 0 && norm(c.p).indexOf(q) < 0 && String(c.n).indexOf(q) !== 0) return false;
    }
    return true;
  }
  function filtros(all) {
    var html = '<h3>Filtrar</h3>';
    GRUPOS.forEach(function (g) {
      var k = g[0], cnt = {};
      all.forEach(function (c) { if (!passa(c, k)) return; var v = valor(c, k); if (v) cnt[v] = (cnt[v] || 0) + 1; });
      var ops = Object.keys(cnt);
      if (k === 'faixa') ops = FAIXAS.map(function (f) { return f[0]; }).filter(function (v) { return cnt[v] || (S.f.faixa || []).indexOf(v) >= 0; });
      else ops.sort(function (a, b) { return k === 'p' || k === 'ocup' ? cnt[b] - cnt[a] || a.localeCompare(b) : a.localeCompare(b); });
      (S.f[k] || []).forEach(function (v) { if (ops.indexOf(v) < 0) ops.unshift(v); });
      if (!ops.length) return;
      var sel = (S.f[k] || []).length;
      html += '<details' + (sel ? ' open' : '') + '><summary>' + g[1] + (sel ? '<em>' + sel + '</em>' : '') + '</summary><div class="ops">' + ops.map(function (v) {
        var rot = k === 'faixa' ? FAIXAS.filter(function (f) { return f[0] === v; })[0][1] : v;
        return '<label><input type="checkbox" data-k="' + k + '" value="' + esc(v) + '"' + ((S.f[k] || []).indexOf(v) >= 0 ? ' checked' : '') + '> <span>' + esc(rot) + '</span><small>' + (cnt[v] || 0) + '</small></label>';
      }).join('') + '</div></details>';
    });
    if (Object.keys(S.f).some(function (k) { return S.f[k].length; })) html += '<button type="button" class="limpar" id="cd-limpar">Limpar filtros</button>';
    var box = $('#cd-filtros'), open = $$('details[open] summary', box).map(function (s) { return s.textContent; });
    box.innerHTML = html;
    $$('details', box).forEach(function (d) { if (open.indexOf($('summary', d).textContent) >= 0) d.open = true; });
    var l = $('#cd-limpar'); if (l) l.onclick = function () { S.f = {}; S.lim = 48; render(); };
  }
  function aviso(c) {
    if (/sub judice/i.test(c.voto || '')) return 'Candidatura sub judice';
    if (/indeferid|cancelad|cassad|renúncia|renuncia/i.test(c.sit || '')) return c.sit;
    return '';
  }
  function ordenar(l) {
    var o = S.ord;
    return l.sort(function (a, b) {
      if (o === 'n') return (+a.n) - (+b.n);
      if (o === 'p') return a.p.localeCompare(b.p) || a.nome.localeCompare(b.nome);
      if (o === 'bens') return (b.bens || 0) - (a.bens || 0);
      if (o === 'rec') return (b.rec || 0) - (a.rec || 0);
      return a.nome.localeCompare(b.nome);
    });
  }
  function render() {
    $$('#cd-tabs button').forEach(function (b) { b.setAttribute('aria-selected', b.dataset.c === S.cargo); });
    var sel = $('#cd-uf'); sel.value = ufAtual(); sel.disabled = S.cargo === 'pres';
    $$('option', sel)[0].hidden = S.cargo !== 'pres';
    var u = new URL(location.href); u.searchParams.set('cargo', S.cargo); if (S.cargo !== 'pres') u.searchParams.set('uf', S.uf); else u.searchParams.delete('uf');
    if (S.sq) u.searchParams.set('sq', S.sq); else u.searchParams.delete('sq');
    history.replaceState(null, '', u);
    var all = lista();
    if (!all) { $('#cd-cards').innerHTML = '<div class="nores">' + esc((S.dados[ufAtual()] && S.dados[ufAtual()].erro) || 'Carregando…') + '</div>'; $('#cd-count').textContent = ''; $('#cd-more').hidden = true; return; }
    filtros(all);
    var l = ordenar(all.filter(function (c) { return passa(c); }));
    var nome = CARGOS.filter(function (c) { return c[0] === S.cargo; })[0][1].toLowerCase();
    $('#cd-count').textContent = l.length + (l.length === 1 ? ' candidato' : ' candidatos') + (l.length !== all.length ? ' de ' + all.length : '') + ' · ' + nome + (S.cargo === 'pres' ? '' : ' · ' + UFN[S.uf]);
    $('#cd-cards').innerHTML = l.length ? l.slice(0, S.lim).map(function (c) {
      var ruim = aviso(c);
      return '<button type="button" class="ccard" data-sq="' + esc(c.sq) + '">' + foto(c) + '<span class="nm">' + esc(c.nome) + '</span><span class="ln">' + chip(c.p) + '<span>' + esc(c.n) + '</span></span>' + (ruim ? '<span class="sit">' + esc(ruim) + '</span>' : '') + '<span class="ver">Ver perfil ›</span></button>';
    }).join('') : '<div class="nores">Nenhum candidato com esses filtros.</div>';
    $('#cd-more').hidden = l.length <= S.lim;
    $('#cd-more').textContent = 'Ver mais (' + (l.length - S.lim) + ')';
  }
  function carregar() {
    var uf = ufAtual();
    if (S.dados[uf]) { render(); abrirSeLink(); return; }
    render();
    get('candidatos?uf=' + uf).then(function (d) {
      S.dados[uf] = d && d.c ? d : { erro: (d && d.erro) || 'Não foi possível carregar agora.' };
      render(); abrirSeLink();
    }).catch(function () { S.dados[uf] = { erro: 'Não foi possível carregar agora.' }; render(); });
  }

  /* ---------- perfil ---------- */
  var P = $('#cd-perfil');
  function acha(sq) { var d = S.dados[ufAtual()]; return d && d.c ? d.c.filter(function (c) { return c.sq === sq; })[0] : null; }
  function abrirSeLink() { if (S.sq && acha(S.sq) && P.hidden) abrir(S.sq); }
  function linha(dt, dd) { return dd ? '<div><dt>' + dt + '</dt><dd>' + esc(dd) + '</dd></div>' : ''; }
  function abrir(sq) {
    var c = acha(sq); if (!c) return;
    S.sq = sq; render();
    var cargo = { pres: 'Presidente', gov: 'Governador', sen: 'Senador', df: 'Deputado federal', de: c.cd === 8 ? 'Deputado distrital' : 'Deputado estadual' }[c.cargo];
    var chapa = [];
    if (c.vice) chapa.push(['Vice', c.vice]);
    if (c.sup1) chapa.push(['1º suplente', c.sup1]);
    if (c.sup2) chapa.push(['2º suplente', c.sup2]);
    var alianca = c.comp && c.comp !== c.p ? c.comp : '';
    P.innerHTML = '<div class="pbox"><button type="button" class="fechar" aria-label="Fechar">×</button>' +
      '<div class="phead"><div><h2>' + esc(c.nome) + '</h2>' + (c.nc && norm(c.nc) !== norm(c.nome) ? '<p class="nc">' + esc(c.nc) + '</p>' : '') +
      '<div class="ln">' + chip(c.p) + '<span>' + esc(c.n) + '</span><small>' + cargo + (c.cargo === 'pres' ? '' : ' · ' + UFN[c.uf]) + '</small></div></div>' + foto(c) + '</div>' +
      '<div class="psec"><h3>Quem é</h3><dl class="pdl">' +
        linha('Idade na posse', c.idade ? c.idade + ' anos' : '') + linha('Gênero', c.g) + linha('Cor ou raça', c.cor) + linha('Grau de instrução', c.instr) +
        linha('Profissão', c.ocup) + linha('Estado civil', c.ec) + linha('Nasceu em', [c.nmun, c.nuf].filter(Boolean).join(' (') + (c.nmun && c.nuf ? ')' : '')) +
        linha('Situação da candidatura', c.sit) + linha('Votos', /sub judice/i.test(c.voto || '') ? 'Sub judice: a candidatura está sendo julgada. Os votos só valem se ela for aprovada.' : '') + linha('Tentando a reeleição', c.reel ? 'Sim' : '') +
        chapa.map(function (x) { return linha(x[0], x[1]); }).join('') + linha('Partido', c.pn) + linha('Aliança', alianca) +
      '</dl></div><div id="cd-extra"><div class="nores">Carregando bens, candidaturas anteriores e contas…</div></div>' +
      '<p class="pnota">Informações declaradas pelo próprio candidato à Justiça Eleitoral. Dados abertos do TSE, atualizados todo dia.</p></div>';
    P.hidden = false; document.body.style.overflow = 'hidden';
    $('.fechar', P).onclick = fechar; $('.fechar', P).focus();
    get('candidato?uf=' + c.uf + '&sq=' + sq).then(function (r) {
      if (S.sq !== sq) return;
      var p = (r && r.p) || {}, h = '';
      var hist = p.hist || [];
      h += '<div class="psec"><h3>Candidaturas anteriores</h3>' + (hist.length ? '<div class="pscroll"><table class="ptab">' + hist.map(function (x) {
        return '<tr><td>' + x[0] + '</td><td>' + esc(x[1]) + (x[2] ? ' · ' + esc(x[2]) : '') + '</td><td>' + esc(x[3]) + '</td><td>' + esc(x[4]) + '</td></tr>';
      }).join('') + '</table></div>' : '<p class="pnota">Nenhuma candidatura anterior registrada pelo TSE.</p>') + '</div>';
      var bens = p.bens || [];
      h += '<div class="psec"><h3>Bens declarados</h3><p class="pbig">' + brl(c.bens || 0) + '</p>' + (bens.length ? '<div class="pscroll"><table class="ptab">' + bens.map(function (b) {
        return '<tr><td>' + brl(b[2]) + '</td><td><b>' + esc(b[0]) + '</b>' + (b[1] && norm(b[1]) !== norm(b[0]) ? '<br>' + esc(b[1]) : '') + '</td></tr>';
      }).join('') + '</table></div>' : '<p class="pnota">Não declarou bens.</p>') + '</div>';
      var rec = c.rec || 0, desp = c.desp || 0, lim = c.lim || 0, mx = Math.max(rec, desp, lim, 1);
      h += '<div class="psec"><h3>Dinheiro da campanha</h3><div class="pbars">' +
        '<div><b>Arrecadou</b><span class="v">' + brl(rec) + '</span><i><em style="width:' + (rec / mx * 100) + '%"></em></i></div>' +
        '<div class="d"><b>Gastos contratados</b><span class="v">' + brl(desp) + '</span><i><em style="width:' + (desp / mx * 100) + '%"></em></i></div>' +
        (lim ? '<div class="l"><b>Limite de gastos</b><span class="v">' + brl(lim) + '</span><i><em style="width:' + (lim / mx * 100) + '%"></em></i></div>' : '') + '</div></div>';
      function rank(t, arr, tot) {
        if (!arr || !arr.length) return '';
        return '<div class="psec"><h3>' + t + '</h3><div class="prank">' + arr.map(function (x) {
          var pc = tot ? x[1] / tot * 100 : 0;
          return '<div><b>' + esc(x[0]) + '</b><i><em style="width:' + Math.min(100, pc) + '%"></em></i><span><span>' + brl(x[1]) + '</span><span>' + pc.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%</span></span></div>';
        }).join('') + '</div></div>';
      }
      h += rank('Quem mais doou', p.doad, rec) + rank('Onde mais gastou', p.forn, desp);
      $('#cd-extra').innerHTML = h;
    }).catch(function () { $('#cd-extra').innerHTML = '<div class="nores">Não foi possível carregar agora.</div>'; });
  }
  function fechar() { P.hidden = true; P.innerHTML = ''; document.body.style.overflow = ''; S.sq = ''; render(); }
  P.addEventListener('click', function (e) { if (e.target === P) fechar(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !P.hidden) fechar(); });

  /* ---------- eventos ---------- */
  $('#cd-tabs').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; S.cargo = b.dataset.c; S.f = {}; S.lim = 48; carregar(); });
  $('#cd-uf').addEventListener('change', function () { if (this.value === 'br') return; S.uf = this.value; ls('rr_uf', S.uf); S.f = {}; S.lim = 48; carregar(); });
  var t; $('#cd-q').addEventListener('input', function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { S.q = v; S.lim = 48; render(); }, 120); });
  $('#cd-ord').addEventListener('change', function () { S.ord = this.value; render(); });
  $('#cd-more').addEventListener('click', function () { S.lim += 48; render(); });
  $('#cd-fbtn').addEventListener('click', function () { $('#cd-filtros').classList.toggle('open'); });
  $('#cd-filtros').addEventListener('change', function (e) {
    var i = e.target; if (!i.dataset || !i.dataset.k) return;
    var k = i.dataset.k, a = S.f[k] || (S.f[k] = []), p = a.indexOf(i.value);
    if (i.checked && p < 0) a.push(i.value); if (!i.checked && p >= 0) a.splice(p, 1);
    S.lim = 48; render();
  });
  $('#cd-cards').addEventListener('click', function (e) { var b = e.target.closest('.ccard'); if (b) abrir(b.dataset.sq); });
  carregar();
})();
