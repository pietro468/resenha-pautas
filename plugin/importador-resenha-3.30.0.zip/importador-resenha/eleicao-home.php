<?php
/**
 * Página inicial no dia da eleição (usada pelo plugin no lugar da página inicial do tema).
 * Antes das 17h: matéria em destaque + quem concorre. Depois das 17h: apuração ao vivo.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
rri_el_assets();
$antes = rri_el_antes();
$ids   = get_posts( array( 'post_type' => 'post', 'posts_per_page' => 12, 'fields' => 'ids', 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
$feat  = $antes && $ids ? array_shift( $ids ) : 0;
$rot   = array_splice( $ids, 0, 5 );
$grid  = array_slice( $ids, 0, 6 );
$ap    = home_url( '/apuracao/' );
$img   = function ( $id, $size ) { return function_exists( 'rr_image' ) ? rr_image( $id, $size ) : get_the_post_thumbnail( $id, 'large' ); };
$tag   = function ( $id ) { return function_exists( 'rr_tag_line' ) ? rr_tag_line( $id ) : ''; };
?>
<main id="conteudo" class="rrel rrel-home">
  <div class="strip"><div class="wrap">
    <?php if ( $antes ) : ?>
      <span><b>HOJE É DIA DE ELEIÇÃO</b> · Votação das 8h às 17h (horário de Brasília) · resultados a partir das 17h</span>
      <a class="go" href="<?php echo esc_url( $ap ); ?>">Veja quem concorre ›</a>
    <?php else : ?>
      <span class="aovivo"><span class="livedot"></span>AO VIVO</span>
      <span>Apuração do 1º turno · <b class="num js-pst">…</b> das urnas apuradas<span class="js-hora-w"> · atualizado <span class="js-hora"></span></span></span>
      <a class="go" href="<?php echo esc_url( $ap ); ?>">Acompanhe em tempo real ›</a>
    <?php endif; ?>
  </div></div>

  <section class="lead"><div class="wrap">
    <?php if ( $antes && $feat ) : $t = $tag( $feat ); ?>
      <a class="feature" href="<?php echo esc_url( get_permalink( $feat ) ); ?>">
        <?php echo $img( $feat, 'rr-wide' ); // phpcs:ignore ?>
        <?php if ( $t ) : ?><span class="tag"><?php echo esc_html( $t ); ?></span><?php endif; ?>
        <span class="soon"><span class="livedot g"></span>Apuração ao vivo às 17h · <b class="js-cd num"></b></span>
        <div class="f-txt">
          <h1><?php echo esc_html( get_the_title( $feat ) ); ?></h1>
          <?php if ( function_exists( 'rr_teaser' ) && ( $s = rr_teaser( $feat, 24 ) ) ) : ?><p><?php echo esc_html( $s ); ?></p><?php endif; ?>
        </div>
      </a>
    <?php else : ?>
      <a class="feature hero" href="<?php echo esc_url( $ap ); ?>">
        <div class="kick"><span class="aovivo"><span class="livedot"></span>AO VIVO</span><span>Eleições 2026 · 1º turno</span></div>
        <div class="h-txt">
          <h1>Apuração em tempo real: veja o resultado no Brasil, no seu estado e na sua cidade</h1>
          <p>Presidente, governador, senador e deputados. A página se atualiza sozinha, sem precisar recarregar.</p>
        </div>
        <div class="urnas">
          <div class="row"><span>Urnas apuradas</span><span class="big num js-pst">…</span></div>
          <div class="bar"><i class="js-pstbar" style="width:0%"></i></div>
        </div>
        <div class="ctas"><span class="btn brand">Abrir a apuração</span><span class="btn ghost">Buscar minha cidade</span></div>
      </a>
    <?php endif; ?>

    <div class="duo">
      <section class="card-el" aria-label="Presidente">
        <div class="card-h">
          <?php if ( $antes ) : ?><h2>Quem concorre a presidente</h2><?php else : ?><h2><span class="livedot"></span>Presidente</h2><small><span class="js-pst num">…</span> apuradas</small><?php endif; ?>
        </div>
        <div class="mini-list<?php echo $antes ? ' scroll' : ''; ?>" id="el-mini"><div class="nores">Carregando…</div></div>
        <div class="cfoot"><span><?php echo $antes ? 'Fonte: TSE' : 'Fonte: TSE · votos válidos'; ?></span><a href="<?php echo esc_url( $ap ); ?>"><?php echo $antes ? 'Ver todos os cargos ›' : 'Ver completo ›'; ?></a></div>
      </section>
      <?php if ( $rot ) : ?>
      <div class="rot" id="el-rot">
        <?php foreach ( $rot as $i => $id ) : $t = $tag( $id ); ?>
        <a class="feature mini<?php echo 0 === $i ? ' on' : ''; ?>" href="<?php echo esc_url( get_permalink( $id ) ); ?>">
          <?php echo $img( $id, 'rr-card' ); // phpcs:ignore ?>
          <?php if ( $t ) : ?><span class="tag"><?php echo esc_html( $t ); ?></span><?php endif; ?>
          <div class="f-txt"><h2><?php echo esc_html( get_the_title( $id ) ); ?></h2><span class="when"><?php echo esc_html( function_exists( 'rr_date' ) ? rr_date( $id ) : get_the_date( '', $id ) ); ?></span></div>
        </a>
        <?php endforeach; ?>
        <div class="dots"><?php foreach ( $rot as $i => $id ) : ?><i<?php echo 0 === $i ? ' class="on"' : ''; ?>></i><?php endforeach; ?></div>
      </div>
      <?php endif; ?>
    </div>
  </div></section>

  <?php if ( $grid ) : ?>
  <section class="latest"><div class="wrap">
    <h2 class="sec-h">Últimos artigos</h2>
    <?php if ( function_exists( 'rr_grid' ) ) { rr_grid( $grid ); } ?>
    <div class="more-row"><a class="btn line" href="<?php echo esc_url( function_exists( 'rr_link' ) ? rr_link( 'artigos' ) : home_url( '/' ) ); ?>">Ver todos os artigos</a></div>
  </div></section>
  <?php endif; ?>
</main>
<?php
get_footer();
