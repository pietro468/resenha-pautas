<?php
/**
 * Publicação automática no Instagram (API do Instagram com login do Instagram).
 * Quando uma matéria com carrossel é publicada no site, ela entra na fila; a fila roda
 * a cada busca do GitHub (aviso da rotina e despertador) e publica no @ configurado.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RRI_IG_API', 'https://graph.instagram.com/v23.0/' );

function rri_ig_opts() {
	return wp_parse_args( get_option( 'rri_ig', array() ), array( 'token' => '', 'uid' => '', 'user' => '', 'on' => 0, 'desde' => 0, 'refreshed' => 0 ) );
}

function rri_ig_req( $method, $path, $args = array() ) {
	$o = rri_ig_opts();
	$args['access_token'] = $o['token'];
	$url = ( 0 === strpos( $path, 'http' ) ? $path : RRI_IG_API . ltrim( $path, '/' ) );
	if ( 'GET' === $method ) {
		$r = wp_remote_get( add_query_arg( array_map( 'rawurlencode', $args ), $url ), array( 'timeout' => 40 ) );
	} else {
		$r = wp_remote_post( $url, array( 'timeout' => 60, 'body' => $args ) );
	}
	if ( is_wp_error( $r ) ) { return $r; }
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( ! is_array( $j ) ) { return new WP_Error( 'rri_ig', 'Resposta inválida do Instagram.' ); }
	if ( ! empty( $j['error'] ) ) { return new WP_Error( 'rri_ig', ( $j['error']['message'] ?? 'Erro do Instagram' ) ); }
	return $j;
}

/** confere o token e descobre a conta */
function rri_ig_check() {
	$me = rri_ig_req( 'GET', 'me', array( 'fields' => 'user_id,username' ) );
	if ( is_wp_error( $me ) ) { return $me; }
	$o = rri_ig_opts();
	$o['uid'] = (string) ( $me['user_id'] ?? $me['id'] ?? '' );
	$o['user'] = (string) ( $me['username'] ?? '' );
	update_option( 'rri_ig', $o, false );
	return $o;
}

/** renova o token (vale 60 dias) uma vez por semana */
function rri_ig_refresh() {
	$o = rri_ig_opts();
	if ( ! $o['token'] || ( time() - (int) $o['refreshed'] ) < WEEK_IN_SECONDS ) { return; }
	$r = rri_ig_req( 'GET', 'https://graph.instagram.com/refresh_access_token', array( 'grant_type' => 'ig_refresh_token' ) );
	if ( ! is_wp_error( $r ) && ! empty( $r['access_token'] ) ) {
		$o['token'] = $r['access_token']; $o['refreshed'] = time();
		update_option( 'rri_ig', $o, false );
	}
}

/** espera o Instagram terminar de processar uma mídia */
function rri_ig_wait( $id ) {
	for ( $i = 0; $i < 12; $i++ ) {
		$s = rri_ig_req( 'GET', $id, array( 'fields' => 'status_code' ) );
		if ( is_wp_error( $s ) ) { return $s; }
		$c = $s['status_code'] ?? '';
		if ( 'FINISHED' === $c ) { return true; }
		if ( 'ERROR' === $c || 'EXPIRED' === $c ) { return new WP_Error( 'rri_ig', 'O Instagram não conseguiu processar a imagem.' ); }
		sleep( 3 );
	}
	return new WP_Error( 'rri_ig', 'O Instagram demorou demais para processar.' );
}

/** publica o carrossel (ou imagem única) de um post */
function rri_ig_publish( $pid ) {
	$o = rri_ig_opts();
	if ( ! $o['token'] || ! $o['uid'] ) { return new WP_Error( 'rri_ig', 'Instagram não conectado.' ); }
	if ( get_post_meta( $pid, '_rr_ig_id', true ) ) { return new WP_Error( 'rri_ig', 'Este post já foi publicado no Instagram.' ); }
	$car = json_decode( (string) get_post_meta( $pid, '_rr_carrossel', true ), true );
	$slides = (array) get_post_meta( $pid, '_rr_car_slides', true );
	if ( ! is_array( $car ) || ! $slides ) { return new WP_Error( 'rri_ig', 'Este post não tem carrossel.' ); }
	if ( $fc = get_post_meta( $pid, '_rr_foto_conferir', true ) ) { return new WP_Error( 'rri_ig', 'capa' === $fc ? 'A foto de capa escolhida não baixou e o site pôs outra no lugar. Confira a capa (troque se precisar) e clique em Gerar os slides de novo para liberar o Instagram.' : 'Alguma foto dos slides não baixou. Confira os slides e clique em Gerar os slides de novo para liberar o Instagram.' ); }
	if ( get_post_meta( $pid, '_rr_car_semfoto', true ) ) { rri_car_render( $pid ); $slides = (array) get_post_meta( $pid, '_rr_car_slides', true ); }
	if ( get_post_meta( $pid, '_rr_car_semfoto', true ) ) { return new WP_Error( 'rri_ig', 'Os slides saíram sem a foto (o site não conseguiu abrir a imagem). Troque a foto de capa e clique em Gerar os slides de novo.' ); }
	@set_time_limit( 300 );
	$caption = mb_substr( (string) ( $car['legenda'] ?? get_the_title( $pid ) ), 0, 2150 );
	$uid = $o['uid'];
	if ( 1 === count( $slides ) ) {
		$c = rri_ig_req( 'POST', $uid . '/media', array( 'image_url' => $slides[0], 'caption' => $caption ) );
		if ( is_wp_error( $c ) ) { return $c; }
		$w = rri_ig_wait( $c['id'] ); if ( is_wp_error( $w ) ) { return $w; }
		$creation = $c['id'];
	} else {
		$kids = array();
		foreach ( array_slice( $slides, 0, 10 ) as $u ) {
			$c = rri_ig_req( 'POST', $uid . '/media', array( 'image_url' => $u, 'is_carousel_item' => 'true' ) );
			if ( is_wp_error( $c ) ) { return $c; }
			$kids[] = $c['id'];
		}
		foreach ( $kids as $k ) { $w = rri_ig_wait( $k ); if ( is_wp_error( $w ) ) { return $w; } }
		$c = rri_ig_req( 'POST', $uid . '/media', array( 'media_type' => 'CAROUSEL', 'children' => implode( ',', $kids ), 'caption' => $caption ) );
		if ( is_wp_error( $c ) ) { return $c; }
		$w = rri_ig_wait( $c['id'] ); if ( is_wp_error( $w ) ) { return $w; }
		$creation = $c['id'];
	}
	$p = rri_ig_req( 'POST', $uid . '/media_publish', array( 'creation_id' => $creation ) );
	if ( is_wp_error( $p ) ) { return $p; }
	update_post_meta( $pid, '_rr_ig_id', $p['id'] );
	update_post_meta( $pid, '_rr_ig_quando_postado', time() );
	delete_post_meta( $pid, '_rr_ig_pending' );
	delete_post_meta( $pid, '_rr_ig_err' );
	$pl = rri_ig_req( 'GET', $p['id'], array( 'fields' => 'permalink' ) );
	if ( ! is_wp_error( $pl ) && ! empty( $pl['permalink'] ) ) { update_post_meta( $pid, '_rr_ig_link', $pl['permalink'] ); }
	return $p['id'];
}

/* matéria publicada no site entra na fila (só as publicadas depois de ligar a automação) */
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'publish' !== $new || 'publish' === $old || 'post' !== $post->post_type ) { return; }
	$o = rri_ig_opts();
	if ( ! $o['on'] ) { return; }
	update_post_meta( $post->ID, '_rr_ig_pending', time() );
}, 10, 3 );

/** processa a fila: posts publicados, com slides prontos, ainda não postados */
function rri_ig_process( $max = 3 ) {
	$o = rri_ig_opts();
	if ( ! $o['on'] || ! $o['token'] || ! $o['uid'] ) { return; }
	if ( get_transient( 'rri_ig_lock' ) ) { return; }
	set_transient( 'rri_ig_lock', 1, 10 * MINUTE_IN_SECONDS );
	rri_ig_refresh();
	$q = get_posts( array( 'post_type' => array( 'post', 'rr_insta' ), 'post_status' => 'publish', 'numberposts' => 20, 'fields' => 'ids', 'meta_key' => '_rr_ig_pending', 'orderby' => 'date', 'order' => 'ASC' ) );
	$done = 0;
	foreach ( $q as $pid ) {
		if ( $done >= $max ) { break; }
		if ( get_post_meta( $pid, '_rr_ig_id', true ) ) { delete_post_meta( $pid, '_rr_ig_pending' ); continue; }
		$quando = (int) get_post_meta( $pid, '_rr_ig_quando', true );
		if ( $quando && time() < $quando ) { continue; } // post só do Instagram agendado para mais tarde
		if ( ! get_post_meta( $pid, '_rr_car_slides', true ) ) {
			/* ainda sem carrossel: espera até 6 horas, depois desiste */
			if ( time() - (int) get_post_meta( $pid, '_rr_ig_pending', true ) > 6 * HOUR_IN_SECONDS ) { delete_post_meta( $pid, '_rr_ig_pending' ); }
			continue;
		}
		/* foto para conferir: fica esperando (sem gastar tentativa) até alguém clicar em Gerar os slides de novo */
		if ( get_post_meta( $pid, '_rr_foto_conferir', true ) ) {
			if ( ! get_post_meta( $pid, '_rr_ig_err', true ) ) {
				update_post_meta( $pid, '_rr_ig_err', 'Segurado: uma foto escolhida não baixou. Confira as fotos e clique em Gerar os slides de novo.' );
				rri_gh_log( 'Instagram: <a href="' . esc_url( get_edit_post_link( $pid, 'url' ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a> ficou segurado para conferir as fotos' );
			}
			continue;
		}
		$tries = (int) get_post_meta( $pid, '_rr_ig_tries', true );
		if ( $tries >= 3 ) { delete_post_meta( $pid, '_rr_ig_pending' ); continue; }
		$r = rri_ig_publish( $pid );
		if ( is_wp_error( $r ) ) {
			update_post_meta( $pid, '_rr_ig_tries', $tries + 1 );
			update_post_meta( $pid, '_rr_ig_err', $r->get_error_message() );
			rri_gh_log( 'Instagram: erro ao publicar <a href="' . esc_url( get_edit_post_link( $pid, 'url' ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a> (' . esc_html( $r->get_error_message() ) . ')' );
		} else {
			rri_gh_log( 'Instagram: publicado <a href="' . esc_url( (string) get_post_meta( $pid, '_rr_ig_link', true ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a>' );
		}
		$done++;
	}
	delete_transient( 'rri_ig_lock' );
}

/* botão "Publicar no Instagram agora" no quadro do carrossel */
add_action( 'admin_post_rri_ig_now', function () {
	$pid = (int) ( $_GET['post'] ?? 0 );
	if ( ! $pid || ! current_user_can( 'edit_post', $pid ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_ig_' . $pid );
	$r = rri_ig_publish( $pid );
	if ( is_wp_error( $r ) ) { update_post_meta( $pid, '_rr_ig_err', $r->get_error_message() ); }
	wp_safe_redirect( get_edit_post_link( $pid, 'url' ) . '#rri_car' );
	exit;
} );

/** trecho do quadro do carrossel com o status do Instagram */
function rri_ig_box_status( $pid ) {
	$o = rri_ig_opts();
	$link = get_post_meta( $pid, '_rr_ig_link', true );
	if ( get_post_meta( $pid, '_rr_ig_id', true ) ) {
		echo '<p style="color:#1a7f37"><strong>Publicado no Instagram.</strong> ' . ( $link ? '<a href="' . esc_url( $link ) . '" target="_blank">Ver post</a>' : '' ) . '</p>';
		return;
	}
	if ( $err = get_post_meta( $pid, '_rr_ig_err', true ) ) { echo '<p style="color:#b32d2e">Última tentativa no Instagram deu erro: ' . esc_html( $err ) . '</p>'; }
	if ( get_post_meta( $pid, '_rr_ig_pending', true ) ) { echo '<p>Na fila para o Instagram.</p>'; }
	if ( $o['token'] && $o['uid'] ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=rri_ig_now&post=' . $pid ), 'rri_ig_' . $pid );
		echo '<p><a class="button button-primary" href="' . esc_url( $url ) . '" onclick="return confirm(\'Publicar este post no @' . esc_attr( $o['user'] ) . ' agora?\')">Publicar no Instagram agora</a></p>';
	}
}

/* quadro de configuração na página do importador */
function rri_ig_settings_box() {
	$o = rri_ig_opts();
	?>
	<div style="background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px 20px;margin:16px 0">
		<h2 style="margin-top:0">Instagram</h2>
		<?php if ( $o['uid'] ) : ?>
			<p>Conectado ao <strong>@<?php echo esc_html( $o['user'] ); ?></strong>.</p>
		<?php else : ?>
			<p>Cole aqui o token de acesso gerado no painel de desenvolvedor da Meta.</p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rri_ig_save"><?php wp_nonce_field( 'rri_ig_save' ); ?>
			<p><label>Token de acesso<br><input type="password" name="token" value="" placeholder="<?php echo $o['token'] ? 'Token salvo (deixe em branco para manter)' : 'Cole o token aqui'; ?>" style="width:100%"></label></p>
			<p><label><input type="checkbox" name="on" value="1" <?php checked( $o['on'] ); ?>> Publicar automaticamente no Instagram cada matéria nova (com carrossel) assim que ela for ao ar</label></p>
			<p><button class="button button-primary">Salvar e testar</button></p>
		</form>
	</div>
	<?php
}
add_action( 'admin_post_rri_ig_save', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_ig_save' );
	$o = rri_ig_opts();
	$t = trim( (string) wp_unslash( $_POST['token'] ?? '' ) );
	if ( $t ) { $o['token'] = $t; $o['refreshed'] = time(); }
	$on = empty( $_POST['on'] ) ? 0 : 1;
	if ( $on && ! $o['on'] ) { $o['desde'] = time(); }
	$o['on'] = $on;
	update_option( 'rri_ig', $o, false );
	$r = $o['token'] ? rri_ig_check() : new WP_Error( 'rri_ig', 'Sem token.' );
	$msg = is_wp_error( $r ) ? 'Instagram: não consegui conectar (' . $r->get_error_message() . ').' : 'Instagram conectado ao @' . $r['user'] . ( $on ? '. Publicação automática ligada.' : '. Publicação automática desligada.' );
	wp_safe_redirect( add_query_arg( 'rri_ok', rawurlencode( $msg ), admin_url( 'tools.php?page=rr-importador' ) ) );
	exit;
} );

/* correção única (3.11.1): posts de hoje cuja capa veio em AVIF saíram sem foto no Instagram.
   Gera os slides de novo e coloca na fila para publicar outra vez. */
add_action( 'init', function () {
	if ( get_option( 'rri_fix_3111' ) ) { return; }
	update_option( 'rri_fix_3111', 1, false );
	$q = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 20, 'date_query' => array( array( 'after' => '2 days ago' ) ), 'fields' => 'ids', 'meta_key' => '_rr_ig_id' ) );
	foreach ( $q as $pid ) {
		$f = (string) get_attached_file( (int) get_post_thumbnail_id( $pid ) );
		if ( ! preg_match( '/\.avif$/i', $f ) ) { continue; }
		rri_car_render( $pid );
		if ( get_post_meta( $pid, '_rr_car_semfoto', true ) || get_post_meta( $pid, '_rr_foto_conferir', true ) ) { continue; }
		delete_post_meta( $pid, '_rr_ig_id' );
		delete_post_meta( $pid, '_rr_ig_link' );
		update_post_meta( $pid, '_rr_ig_pending', time() );
	}
}, 99 );

/* correção única (3.11.2): o carrossel do Steve Jobs saiu com a mesma foto dos dois lados. Publica de novo com os slides novos. */
add_action( 'init', function () {
	if ( get_option( 'rri_fix_3112' ) ) { return; }
	$p = get_page_by_path( 'steve-jobs', OBJECT, 'post' );
	if ( ! $p || ! get_post_meta( $p->ID, '_rr_ig_id', true ) ) { update_option( 'rri_fix_3112', 1, false ); return; }
	$car = json_decode( (string) get_post_meta( $p->ID, '_rr_carrossel', true ), true );
	if ( ! is_array( $car ) || 'dupla' === ( $car['capa_estilo'] ?? '' ) ) { return; } // espera o carrossel corrigido chegar do GitHub
	update_option( 'rri_fix_3112', 1, false );
	rri_car_render( $p->ID );
	delete_post_meta( $p->ID, '_rr_ig_id' );
	delete_post_meta( $p->ID, '_rr_ig_link' );
	update_post_meta( $p->ID, '_rr_ig_pending', time() );
}, 99 );


/* limpeza: 3 dias depois de ir para o Instagram, apaga os slides (o Instagram guarda a cópia dele).
   Nos posts só do Instagram, apaga também as fotos baixadas, que não aparecem no site. */
function rri_ig_cleanup( $max = 15 ) {
	$q = get_posts( array( 'post_type' => array( 'post', 'rr_insta' ), 'post_status' => 'any', 'numberposts' => $max, 'fields' => 'ids',
		'meta_query' => array( array( 'key' => '_rr_ig_quando_postado', 'value' => time() - 3 * DAY_IN_SECONDS, 'compare' => '<', 'type' => 'NUMERIC' ), array( 'key' => '_rr_car_limpo', 'compare' => 'NOT EXISTS' ) ) ) );
	$up = wp_upload_dir();
	foreach ( $q as $pid ) {
		foreach ( glob( trailingslashit( $up['basedir'] ) . 'carrossel/' . $pid . '/*.jpg' ) ?: array() as $f ) { @unlink( $f ); }
		@rmdir( trailingslashit( $up['basedir'] ) . 'carrossel/' . $pid );
		if ( 'rr_insta' === get_post_type( $pid ) ) {
			foreach ( get_attached_media( 'image', $pid ) as $m ) { wp_delete_attachment( $m->ID, true ); }
		}
		update_post_meta( $pid, '_rr_car_limpo', 1 );
	}
}
add_action( 'rri_depois_da_busca', 'rri_ig_cleanup' );

/* correção única (3.25.0): tira o crédito da foto dos slides que ainda não foram para o Instagram */
add_action( 'init', function () {
	if ( get_option( 'rri_fix_3250' ) ) { return; }
	update_option( 'rri_fix_3250', 1, false );
	$q = get_posts( array( 'post_type' => array( 'post', 'rr_insta' ), 'post_status' => array( 'publish', 'future' ), 'numberposts' => 40, 'fields' => 'ids', 'meta_key' => '_rr_carrossel' ) );
	foreach ( $q as $pid ) {
		if ( get_post_meta( $pid, '_rr_ig_id', true ) ) { continue; }
		rri_car_render( $pid );
	}
}, 99 );
