/* Eleição 2026: apuração ao vivo (dados do TSE através do próprio site) */
(function () {
  var C = window.RREL; if (!C) return;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var fmt = function (n) { return Math.round(n || 0).toLocaleString('pt-BR'); };
  var pct = function (n) { return (n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%'; };
  var esc = function (t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var norm = function (t) { return String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); };
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SIL = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12.5a4.8 4.8 0 1 0 0-9.6 4.8 4.8 0 0 0 0 9.6zm0 1.7c-4.6 0-8.6 2.6-9.4 7.8h18.8c-.8-5.2-4.8-7.8-9.4-7.8z"/></svg>';
  function photo(base, c, cls) {
    return '<span class="photo ' + (cls || '') + '">' + SIL + '<img src="' + esc(base + c.sq + '.jpeg') + '" alt="" loading="lazy" onerror="this.remove()"></span>';
  }
  function get(path) {
    if (C.demo) path += (path.indexOf('?') < 0 ? '?' : '&') + 'demo=1';
    if (C.antes && /[?&]el_antes=1/.test(location.search)) path += (path.indexOf('?') < 0 ? '?' : '&') + 'el_antes=1';
    return fetch(C.rest + path, { headers: { 'X-WP-Nonce': C.nonce }, credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); });
  }
  var UFS = ['ac','al','ap','am','ba','ce','df','es','go','ma','mt','ms','mg','pa','pb','pr','pe','pi','rj','rn','rs','ro','rr','sc','sp','se','to'];
  var UFN = { ac:'Acre',al:'Alagoas',ap:'Amapá',am:'Amazonas',ba:'Bahia',ce:'Ceará',df:'Distrito Federal',es:'Espírito Santo',go:'Goiás',ma:'Maranhão',mt:'Mato Grosso',ms:'Mato Grosso do Sul',mg:'Minas Gerais',pa:'Pará',pb:'Paraíba',pr:'Paraná',pe:'Pernambuco',pi:'Piauí',rj:'Rio de Janeiro',rn:'Rio Grande do Norte',rs:'Rio Grande do Sul',ro:'Rondônia',rr:'Roraima',sc:'Santa Catarina',sp:'São Paulo',se:'Sergipe',to:'Tocantins',br:'Brasil',zz:'Exterior' };

  /* antes das 17h: recarrega a página sozinha quando as urnas fecham */
  if (C.antes && C.urnas > Date.now() && C.urnas - Date.now() < 864e5) { // só no próprio dia (o setTimeout não aceita esperas longas)
    setTimeout(function () { location.reload(); }, C.urnas - Date.now() + 5000);
  }
  function countdown() {
    var el = $$('.js-cd'); if (!el.length) return;
    var tick = function () {
      var s = Math.max(0, Math.floor((C.urnas - Date.now()) / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
      var t = (h > 23 ? Math.floor(h / 24) + 'd ' + (h % 24) + 'h' : [h, m, x].map(function (v) { return (v < 10 ? '0' : '') + v; }).join(':'));
      el.forEach(function (e) { e.textContent = t; });
    };
    tick(); setInterval(tick, 1000);
  }

  /* ================= PÁGINA INICIAL ================= */
  function home() {
    var faces = $('#el-faces');
    if (faces) get('eleicao?c=pres&uf=br&t=' + C.fase).then(function (d) {
      if (!d || !d.ok) return;
      var l = d.cands.slice().sort(function () { return Math.random() - .5; }).slice(0, 7);
      faces.innerHTML = l.map(function (c) { return photo(d.foto, c, 'xs'); }).join('') + '<small>' + (C.fase === 2 ? d.cands.length + ' no 2º turno para presidente' : d.cands.length + ' candidatos a presidente') + '</small>';
    });
    countdown();
    var mini = $('#el-mini');
    var slides = $$('#el-rot .feature.mini'), dots = $$('#el-rot .dots i'), ri = 0;
    if (slides.length > 1) setInterval(function () {
      slides[ri].classList.remove('on'); dots[ri] && dots[ri].classList.remove('on');
      ri = (ri + 1) % slides.length;
      slides[ri].classList.add('on'); dots[ri] && dots[ri].classList.add('on');
    }, reduce ? 8000 : 5000);
    if (!mini) return;
    function load() {
      get('eleicao?c=pres&uf=br&t=' + C.fase).then(function (d) {
        if (!d || !d.ok) { mini.innerHTML = '<div class="nores">' + esc((d && d.erro) || 'Não foi possível carregar agora.') + '</div>'; return; }
        if (d.antes) {
          mini.innerHTML = d.cands.map(function (c) {
            return '<div class="crow">' + photo(d.foto, c, 'sm') + '<span class="nm">' + esc(c.nome) + '<span>' + esc(c.partido) + '</span></span><span class="nr"><small>Nº</small>' + esc(c.n) + '</span></div>';
          }).join('');
          return;
        }
        $$('.js-pst').forEach(function (e) { e.textContent = pct(d.pst); });
        $$('.js-pstbar').forEach(function (e) { e.style.width = d.pst + '%'; });
        $$('.js-hora').forEach(function (e) { e.textContent = d.hora ? d.hora.split(' ').pop() : ''; });
        $$('.js-hora-w').forEach(function (e) { e.hidden = !d.hora; });
        mini.innerHTML = d.cands.slice(0, 4).map(function (c, i) {
          return '<div class="mrow' + (i === 0 && d.pst > 0 ? ' lead1' : '') + '">' + photo(d.foto, c, 'xs') + '<span class="nm">' + esc(c.nome) + '<small>' + esc(c.partido) + '</small></span><span class="pct num">' + pct(c.p) + '</span><span class="track"><i style="width:' + c.p.toFixed(2) + '%"></i></span></div>';
        }).join('');
        if (!d.final) setTimeout(load, 30000);
      }).catch(function () { setTimeout(load, 30000); });
    }
    load();
  }

  /* ================= APURAÇÃO ================= */
  function apuracao() {
    var tabs = $('#el-tabs'); if (!tabs) return;
    var qs = new URLSearchParams(location.search);
    var turno = C.fase === 2 && qs.get('t') !== '1' ? 2 : 1;
    var CG = {};
    function lista() { return turno === 2 ? C.cargos2 : C.cargos; }
    function montaCG() { CG = {}; lista().forEach(function (c) { CG[c.k] = c; }); }
    montaCG();
    var S = { c: CG[qs.get('cargo')] ? qs.get('cargo') : lista()[0].k, uf: (qs.get('uf') || '').toLowerCase(), mu: qs.get('mu') || '', muNome: '', q: '', all: false, data: null, timer: 0 };
    var cities = {}, CI = $('#el-city'), CL = $('#el-clist'), opts = [], act = -1;

    function montaTabs() {
      tabs.innerHTML = (C.fase === 2 ? '<span class="turnos" role="group" aria-label="Turno"><button type="button" data-t="1"' + (turno === 1 ? ' aria-pressed="true"' : '') + '>1º turno</button><button type="button" data-t="2"' + (turno === 2 ? ' aria-pressed="true"' : '') + '>2º turno</button></span>' : '') +
        lista().map(function (c) { return '<button role="tab" type="button" data-c="' + c.k + '">' + esc(c.nome) + '</button>'; }).join('');
    }
    montaTabs();
    $('#el-states').innerHTML = '<button type="button" class="br" data-uf="br">Brasil</button>' + UFS.map(function (u) { return '<button type="button" data-uf="' + u + '">' + u.toUpperCase() + '</button>'; }).join('');

    function cargo() { return CG[S.c]; }
    function fixUF() {
      var c = cargo();
      if (c.ufs && c.ufs.length && c.ufs.indexOf(S.uf) < 0) { S.uf = c.ufs[0]; S.mu = ''; }
      if (!S.uf || ((S.uf === 'br' || S.uf === 'zz') && !c.br)) { S.uf = c.br ? 'br' : 'sp'; S.mu = ''; }
      if (S.uf === 'br') S.mu = '';
      if (c.mun && !S.mu && C.demo && S.uf === 'sp') { S.mu = '71072'; S.muNome = 'São Paulo'; }
    }
    function paintControls() {
      var c = cargo();
      $$('button[data-c]', tabs).forEach(function (b) { b.setAttribute('aria-selected', b.dataset.c === S.c); });
      var sel = $('#el-uf');
      sel.innerHTML = (c.br ? '<option value="br">Brasil</option>' : '') + UFS.map(function (u) {
        var off = c.ufs && c.ufs.length && c.ufs.indexOf(u) < 0;
        return '<option value="' + u + '"' + (off ? ' disabled' : '') + '>' + UFN[u] + '</option>';
      }).join('') + (c.br ? '<option value="zz">Exterior</option>' : '');
      sel.value = S.uf;
      $('#el-br').hidden = !c.br;
      $('#el-br').setAttribute('aria-pressed', S.uf === 'br');
      $$('#el-states button').forEach(function (b) {
        var u = b.dataset.uf;
        b.hidden = u === 'br' && !c.br;
        b.disabled = !!(c.ufs && c.ufs.length && u !== 'br' && c.ufs.indexOf(u) < 0);
        b.setAttribute('aria-pressed', u === S.uf);
      });
      CI.value = S.mu ? S.muNome : '';
      $('#el-combo').hidden = S.uf === 'zz';
      $('#el-q').placeholder = c.prop ? 'Busque seu candidato pelo nome, partido ou número' : 'Busque pelo nome, partido ou número';
      var where = S.mu ? S.muNome + ' (' + S.uf.toUpperCase() + ')' : UFN[S.uf];
      $('#el-crumb').innerHTML = 'Mostrando: <b>' + esc(c.nome) + '</b> em <b>' + esc(where) + '</b>';
      $('#el-stw').textContent = where;
      var u = new URL(location.href); u.searchParams.set('cargo', S.c); u.searchParams.set('uf', S.uf); if (C.fase === 2) u.searchParams.set('t', turno);
      if (S.mu) u.searchParams.set('mu', S.mu); else u.searchParams.delete('mu');
      history.replaceState(null, '', u);
    }
    function load() {
      clearTimeout(S.timer);
      var key = S.c + S.uf + S.mu;
      get('eleicao?c=' + S.c + '&uf=' + S.uf + '&mu=' + S.mu + '&t=' + turno).then(function (d) {
        if (key !== S.c + S.uf + S.mu) return;
        S.data = d; render();
        if (d && d.ok && !d.antes && !d.final) S.timer = setTimeout(load, 30000);
        else if (!d || !d.ok) S.timer = setTimeout(load, 60000);
      }).catch(function () { S.timer = setTimeout(load, 30000); });
    }
    function go() { fixUF(); paintControls(); S.data = null; $('#el-list').innerHTML = '<div class="nores">Carregando…</div>'; $('#el-top').innerHTML = ''; load(); }

    function status(d) {
      var h = '';
      if (d && d.ok && d.antes) h = '<span class="chip">Resultados a partir das 17h (horário de Brasília)</span><span class="chip"><span class="livedot g"></span>Faltam <b class="js-cd num"></b></span>';
      else if (d && d.ok && d.final) h = '<span class="chip ok">Apuração encerrada' + (d.hora ? ' · ' + esc(d.hora) : '') + '</span>';
      else if (d && d.ok && d.semvotos) h = '<span class="aovivo"><span class="livedot"></span>AO VIVO</span><span class="chip">Aguardando os primeiros números do TSE</span>';
      else if (d && d.ok) h = '<span class="aovivo"><span class="livedot"></span>AO VIVO</span>' + (d.hora ? '<span class="chip">Atualizado às ' + esc(d.hora.split(' ').pop()) + '</span>' : '');
      $('#el-status').innerHTML = h + '<span class="fonte">Dados: TSE</span>';
      if (d && d.antes) countdown();
    }
    function badge(c) {
      var b = '', st = c.st || '';
      if (st.indexOf('Eleito') === 0) b = '<span class="badge el">Eleito</span>';
      else if (st.indexOf('2º turno') === 0) b = '<span class="badge t2">2º turno</span>';
      else if (st.indexOf('Suplente') === 0) b = '<span class="badge sp">Suplente</span>';
      else if (st.indexOf('Não eleito') === 0) b = '<span class="badge ne">Não eleito</span>';
      if (/sub judice/i.test(c.dvt)) b += '<span class="badge an">Sub judice</span>';
      else if (/anulad/i.test(c.dvt)) b += '<span class="badge an">Votos anulados</span>';
      return b;
    }
    function render() {
      var d = S.data, c = cargo();
      status(d);
      if (!d || !d.ok) {
        $('#el-top').innerHTML = '<div class="panel-h"><h2>' + esc(c.nome) + '</h2></div>' + (c.nota ? '<div class="fict" style="margin:12px 18px 0">' + esc(c.nota) + '</div>' : '');
        $('#el-list').innerHTML = '<div class="nores">' + esc((d && d.erro) || 'Carregando…') + '</div>';
        $('#el-stats').innerHTML = '';
        if (d && d.precisa_cidade) { CI.focus(); }
        return;
      }
      var L = d.antes || d.semvotos;
      var where = S.mu ? S.muNome + ' (' + S.uf.toUpperCase() + ')' : UFN[S.uf];
      var top = '<div class="panel-h"><h2>' + esc((L ? 'Quem concorre a ' + c.nome.toLowerCase() : c.nome) + ' · ' + where) + '</h2><span class="sub">' +
        (L ? d.cands.length + ' candidatos' : (c.prop ? 'mais votados' : '% dos votos válidos')) + (d.vagas > 1 && !c.prop ? ' · ' + d.vagas + ' vagas' : '') + '</span></div>';
      if (d.semvotos) top += '<div class="ur"><div class="row"><span>Ainda não há votos apurados. Os números aparecem aqui sozinhos.</span></div></div>';
      else if (d.antes) top += '<div class="ur"><div class="row"><span>A apuração começa às 17h. Deixe esta página aberta: os números aparecem sozinhos.</span></div></div>';
      else top += '<div class="ur"><div class="row"><span>Urnas apuradas</span><b class="num">' + pct(d.pst) + '</b></div><div class="bar"><i style="width:' + d.pst + '%"></i></div></div>';
      if (c.nota) top += '<div class="fict">' + esc(c.nota) + '</div>';
      if (d.bench && d.bench.length) top += '<div class="bench">' + d.bench.map(function (b) { return '<span>' + esc(b.nome) + ': ' + b.vagas + (b.vagas > 1 ? ' vagas' : ' vaga') + '</span>'; }).join('') + '</div>';
      $('#el-top').innerHTML = top;
      renderList();
      var t = d.tot;
      $('#el-stats').innerHTML = t ? [['Votos válidos', t.validos, t.pvalidos], ['Brancos', t.brancos, t.pbrancos], ['Nulos', t.nulos, t.pnulos], ['Abstenção', t.abst, t.pabst]].map(function (x) {
        return '<div><b class="num">' + fmt(x[1]) + '</b><span>' + x[0] + ' · ' + pct(x[2]) + '</span></div>';
      }).join('') : '<div><b>8h às 17h</b><span>horário da votação</span></div><div><b>17h</b><span>primeiros resultados</span></div>';
    }
    function renderList() {
      var d = S.data, c = cargo(); if (!d || !d.ok) return;
      var L = d.antes || d.semvotos;
      var q = norm(S.q.trim());
      var rows = d.cands.map(function (x, i) { return { c: x, i: i }; });
      if (q) rows = rows.filter(function (r) { return norm(r.c.nome).indexOf(q) >= 0 || norm(r.c.partido).indexOf(q) >= 0 || norm(r.c.vice).indexOf(q) >= 0 || r.c.n.indexOf(q) === 0; });
      var lim = q || S.all ? rows.length : (c.prop ? 20 : 15);
      var html = rows.length ? '<ol class="cands">' + rows.slice(0, lim).map(function (r) {
        var x = r.c, i = r.i, win = !d.antes && d.pst > 0 && i < d.vagas && !c.prop;
        var line = esc(x.partido) + ' · nº ' + esc(x.n) + (x.vice && !c.prop && d.vagas === 1 ? ' · Vice: ' + esc(x.vice) : '') + (c.prop && !d.antes && d.pst > 0 ? ' · ' + (i + 1) + 'º' : '');
        return '<li class="cand' + (win || /^Eleito/.test(x.st) ? ' win' : '') + '">' + photo(d.foto, x) + '<div style="min-width:0"><div class="nm">' + esc(x.nome) + ' ' + badge(x) + '</div><div class="pty">' + line + '</div></div>' +
          (L ? '<span class="nr"><small>NA URNA</small>' + esc(x.n) + '</span>'
            : '<div><div class="pc num">' + pct(x.p) + '</div><div class="vt num">' + fmt(x.v) + ' votos</div></div><span class="track"><i style="width:' + Math.min(100, x.p).toFixed(2) + '%"></i></span>') + '</li>';
      }).join('') + '</ol>' : '<div class="nores">Nenhum candidato encontrado para “' + esc(S.q) + '”. Confira o nome ou tente o número.</div>';
      if (rows.length > lim) html += '<button class="more" type="button" id="el-more">Ver todos os ' + fmt(rows.length) + ' candidatos</button>';
      $('#el-list').innerHTML = html;
      var m = $('#el-more'); if (m) m.onclick = function () { S.all = true; renderList(); };
    }

    /* busca de cidade */
    function loadCities() {
      if (cities[S.c]) return Promise.resolve(cities[S.c]);
      return get('eleicao-cidades?c=' + S.c).then(function (d) { cities[S.c] = d || {}; return cities[S.c]; });
    }
    function hl(name, q) { if (!q) return esc(name); var i = norm(name).indexOf(q); if (i < 0) return esc(name); return esc(name.slice(0, i)) + '<mark>' + esc(name.slice(i, i + q.length)) + '</mark>' + esc(name.slice(i + q.length)); }
    function openList() {
      CL.hidden = false; CI.setAttribute('aria-expanded', 'true');
      if (!cities[S.c]) CL.innerHTML = '<li class="empty">Carregando cidades…</li>';
      loadCities().then(function (all) {
        var q = norm(CI.value.trim()), pool = [], c = cargo();
        var ufs = S.uf === 'br' ? UFS : [S.uf];
        ufs.forEach(function (u) { if (c.ufs && c.ufs.length && c.ufs.indexOf(u) < 0) return; (all[u] || []).forEach(function (m) { pool.push({ cd: m[0], nm: m[1], cap: m[2], uf: u }); }); });
        if (q && S.mu && q === norm(S.muNome)) q = '';
        var a = [], b = [];
        pool.forEach(function (m) { var n = norm(m.nm), i = n.indexOf(q); if (i === 0) a.push(m); else if (i > 0) b.push(m); });
        if (!q) { a = pool.filter(function (m) { return m.cap; }).concat(pool.filter(function (m) { return !m.cap; })); b = []; }
        opts = a.concat(b).slice(0, 80); act = opts.length ? 0 : -1;
        var html = S.mu ? '<li data-i="-2"><span>Ver ' + esc(UFN[S.uf]) + ' inteiro</span></li>' : '';
        if (!q && S.uf === 'br') html += '<li class="empty">Digite o nome da sua cidade</li>';
        else if (!opts.length) html += '<li class="empty">Nenhuma cidade encontrada</li>';
        if (q || S.uf !== 'br') html += opts.map(function (m, i) { return '<li role="option" data-i="' + i + '" aria-selected="' + (i === act) + '"><span>' + hl(m.nm, q) + '</span><small>' + m.uf.toUpperCase() + '</small></li>'; }).join('');
        CL.innerHTML = html;
      });
    }
    function closeList() { CL.hidden = true; CI.setAttribute('aria-expanded', 'false'); }
    function pick(i) {
      if (i === -2) { S.mu = ''; S.muNome = ''; closeList(); CI.blur(); go(); return; }
      var m = opts[i]; if (!m) return;
      S.uf = m.uf; S.mu = m.cd; S.muNome = m.nm; S.q = ''; $('#el-q').value = ''; S.all = false;
      closeList(); CI.blur(); go();
    }
    CI.addEventListener('focus', function () { CI.select(); openList(); });
    CI.addEventListener('input', openList);
    $('#el-ctg').addEventListener('click', function () { if (CL.hidden) { CI.focus(); } else closeList(); });
    CI.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault(); if (!opts.length) return;
        act = (act + (e.key === 'ArrowDown' ? 1 : -1) + opts.length) % opts.length;
        $$('#el-clist li[data-i]').forEach(function (li) { var on = +li.dataset.i === act; li.setAttribute('aria-selected', on); if (on) li.scrollIntoView({ block: 'nearest' }); });
      } else if (e.key === 'Enter') { e.preventDefault(); if (act >= 0) pick(act); }
      else if (e.key === 'Escape') { closeList(); CI.blur(); }
    });
    CL.addEventListener('mousedown', function (e) { var li = e.target.closest('li[data-i]'); if (li) { e.preventDefault(); pick(+li.dataset.i); } });
    document.addEventListener('click', function (e) { if (!e.target.closest('#el-combo')) closeList(); });

    tabs.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.t) { turno = +b.dataset.t; montaCG(); if (!CG[S.c]) S.c = lista()[0].k; montaTabs(); S.q = ''; $('#el-q').value = ''; S.all = false; go(); return; }
      S.c = b.dataset.c; S.q = ''; $('#el-q').value = ''; S.all = false;
      go();
    });
    $('#el-uf').addEventListener('change', function () { S.uf = this.value; S.mu = ''; S.all = false; go(); });
    $('#el-br').addEventListener('click', function () { S.uf = 'br'; S.mu = ''; S.all = false; go(); });
    $('#el-states').addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b || b.disabled) return;
      S.uf = b.dataset.uf; S.mu = ''; S.all = false; go();
      $('#el-res').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    });
    $('#el-q').addEventListener('input', function () { S.q = this.value; renderList(); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden && S.data && S.data.ok && !S.data.antes && !S.data.final) load(); });

    /* cidade vinda do link (?mu=) */
    if (S.mu) { loadCities().then(function (all) { (all[S.uf] || []).forEach(function (m) { if (m[0] === S.mu) S.muNome = m[1]; }); paintControls(); }); }
    go();
    if (location.hash === '#cidade') setTimeout(function () { CI.focus(); }, 300);
  }

  function start() { home(); apuracao(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
