<?php
/**
 * Carrossel do Instagram: monta os slides (1080x1350) a partir do carrossel.json de cada matéria.
 * "formato": "carrossel" (padrão) ou "unico" (só a capa, post de imagem única para notícia urgente).
 * "estilo": "caixa_alta" (padrão do carrossel) ou "frase" (padrão do unico: texto normal, alinhado à esquerda).
 *
 * Formato do carrossel.json (escrito pela rotina):
 * {
 *   "gancho": "BETS PROIBIDAS: QUEM GANHA É O SUPERMERCADO",   (texto da capa, caixa alta)
 *   "chamada": "DESLIZE PARA VER",                              (tarja pequena acima do gancho)
 *   "capa": "capa" | "arquivo-da-imagem.jpg",                    (foto da capa)
 *   "slides": [
 *     {"tipo": "texto", "titulo": "O QUE DIZ A MP", "texto": "==Prazo:== bets fora do ar até **6 de outubro**.", "foto": "capa", "fonte": "Agência Senado"},
 *     {"tipo": "numero", "numero": "R$ 117 bi", "texto": "é quanto ...", "foto": "arquivo.jpg"},
 *     {"tipo": "ranking", "posicao": "10º", "nome": "SERGIO RAMOS", "detalhe": "180 jogos", "foto": "arquivo.jpg"},
 *     {"tipo": "foto", "foto": "arquivo.jpg"},
 *     {"tipo": "final"}
 *   ],
 *   "legenda": "Texto do post no Instagram..."
 * }
 * No texto: ==rótulo== sai em verde e negrito; **trecho** sai em negrito branco; linha em branco separa parágrafos.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RRI_CAR_W', 1080 );
define( 'RRI_CAR_H', 1350 );

function rri_car_font( $k ) {
	$f = array(
		'black' => 'Archivo_900Black.ttf',
		'xbold' => 'Archivo_800ExtraBold.ttf',
		'reg'   => 'IBMPlexSans_400Regular.ttf',
		'semi'  => 'IBMPlexSans_600SemiBold.ttf',
		'bold'  => 'IBMPlexSans_700Bold.ttf',
	);
	if ( 'brim' === $k ) { return __DIR__ . '/assets/brim-face.ttf'; }
	return __DIR__ . '/assets/fontes/' . $f[ $k ];
}

/** foto de referência do carrossel -> caminho do arquivo e crédito */
function rri_car_photo( $pid, $ref, $foco = '' ) {
	$ref = trim( (string) $ref );
	$att = 0;
	if ( '' === $ref || 'capa' === $ref ) {
		$att = (int) get_post_thumbnail_id( $pid );
	} else {
		$want = sanitize_title( pathinfo( $ref, PATHINFO_FILENAME ) );
		foreach ( get_attached_media( 'image', $pid ) as $m ) {
			$fn = sanitize_title( pathinfo( (string) get_attached_file( $m->ID ), PATHINFO_FILENAME ) );
			if ( $fn === $want || 0 === strpos( $fn, $want . '-' ) || 0 === strpos( $fn, $want ) ) { $att = $m->ID; break; }
		}
		if ( ! $att ) { $GLOBALS['rri_car_falhou'] = 1; $att = (int) get_post_thumbnail_id( $pid ); } // foto do slide não existe: segura o Instagram
	}
	if ( ! $att ) { return null; }
	$file = get_attached_file( $att );
	if ( ! $file || ! file_exists( $file ) ) { return null; }
	$cap = trim( wp_strip_all_tags( (string) wp_get_attachment_caption( $att ) ) );
	if ( $cap && false !== ( $p = stripos( $cap, 'Foto:' ) ) ) { $cap = trim( substr( $cap, $p ) ); }
	elseif ( $cap ) { $cap = 'Foto: ' . $cap; }
	$focus = get_post_meta( $att, '_rr_focus', true );
	$fx = 50; $fy = 40;
	$md = wp_get_attachment_metadata( $att );
	if ( ! empty( $md['width'] ) && ! empty( $md['height'] ) && $md['height'] > $md['width'] * 1.15 ) { $fy = 22; } // retrato: o rosto costuma ficar em cima
	if ( $focus && 'none' !== $focus && preg_match( '/^([\d.]+),([\d.]+)$/', $focus, $m ) ) { $fx = (float) $m[1]; $fy = (float) $m[2]; }
	/* foco escolhido no post ("x,y" em %, ex.: "80,45" = o assunto está à direita) */
	/* terceiro número opcional = zoom ("50,50,1.6" aproxima 1,6 vez no ponto) */
	$z = 1;
	if ( preg_match( '/^\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?$/', (string) $foco, $m ) ) { $fx = max( 0, min( 100, (float) $m[1] ) ); $fy = max( 0, min( 100, (float) $m[2] ) ); if ( ! empty( $m[3] ) ) { $z = max( 1, min( 3, (float) $m[3] ) ); } }
	return array( 'file' => $file, 'credit' => $cap, 'fx' => $fx, 'fy' => $fy, 'z' => $z, 'id' => $att );
}

function rri_car_load( $file ) {
	if ( function_exists( 'wp_raise_memory_limit' ) ) { wp_raise_memory_limit( 'image' ); }
	$info = @getimagesize( $file );
	$im = null;
	if ( $info ) {
		switch ( $info[2] ) {
			case IMAGETYPE_JPEG: $im = @imagecreatefromjpeg( $file ); break;
			case IMAGETYPE_PNG:  $im = @imagecreatefrompng( $file ); break;
			case IMAGETYPE_WEBP: $im = function_exists( 'imagecreatefromwebp' ) ? @imagecreatefromwebp( $file ) : null; break;
			case IMAGETYPE_GIF:  $im = @imagecreatefromgif( $file ); break;
		}
		if ( ! $im && defined( 'IMAGETYPE_AVIF' ) && IMAGETYPE_AVIF === $info[2] && function_exists( 'imagecreatefromavif' ) ) { $im = @imagecreatefromavif( $file ); }
	}
	if ( $im ) { return $im; }
	/* formato que o GD não abre (AVIF, HEIC...): converte para JPEG com o editor do WordPress (Imagick) */
	if ( ! function_exists( 'wp_get_image_editor' ) ) { require_once ABSPATH . 'wp-includes/media.php'; }
	$ed = wp_get_image_editor( $file );
	if ( is_wp_error( $ed ) ) { return null; }
	$sz = $ed->get_size();
	if ( ! empty( $sz['width'] ) && $sz['width'] > 2000 ) { $ed->resize( 2000, null ); }
	$tmp = wp_tempnam( 'rri-car' ) . '.jpg';
	$sv = $ed->save( $tmp, 'image/jpeg' );
	if ( is_wp_error( $sv ) || empty( $sv['path'] ) ) { return null; }
	$im = @imagecreatefromjpeg( $sv['path'] );
	@unlink( $sv['path'] );
	return $im ? $im : null;
}

/** cobre um retângulo com a foto, colocando o ponto de foco (rosto) na altura $ty do retângulo */
function rri_car_cover_rect( $im, $ph, $dx, $dy, $dw, $dh, $ty = 0.38 ) {
	$src = $ph ? rri_car_load( $ph['file'] ) : null;
	if ( $ph && ! $src ) { $GLOBALS['rri_car_falhou'] = 1; }
	if ( ! $src ) {
		imagefilledrectangle( $im, $dx, $dy, $dx + $dw, $dy + $dh, imagecolorallocate( $im, 22, 51, 39 ) );
		return;
	}
	$w = imagesx( $src ); $h = imagesy( $src );
	$s = max( $dw / $w, $dh / $h ) * (float) ( $ph['z'] ?? 1 );
	$sw = $w * $s; $sh = $h * $s;
	$x = $dw / 2 - $ph['fx'] / 100 * $sw;
	$y = $dh * $ty - $ph['fy'] / 100 * $sh;
	$x = min( 0, max( $dw - $sw, $x ) );
	$y = min( 0, max( $dh - $sh, $y ) );
	/* recorta da origem só o pedaço visível */
	$sx = -$x / $s; $sy = -$y / $s;
	imagecopyresampled( $im, $src, $dx, $dy, (int) round( $sx ), (int) round( $sy ), $dw, $dh, (int) round( $dw / $s ), (int) round( $dh / $s ) );
	imagedestroy( $src );
}
function rri_car_cover( $im, $ph, $ty = 0.38 ) {
	if ( ! $ph ) { rri_car_bg_liso( $im ); $GLOBALS['rri_car_liso'] = 1; return; }
	rri_car_cover_rect( $im, $ph, 0, 0, RRI_CAR_W, RRI_CAR_H, $ty );
}

/** fundo de slide sem foto: verde da marca em degradê, com o símbolo bem apagado no canto */
function rri_car_bg_liso( $im ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H;
	$a = array( 26, 62, 46 ); $b = array( 10, 26, 19 );
	for ( $y = 0; $y < $H; $y++ ) { $t = $y / $H; imageline( $im, 0, $y, $W, $y, imagecolorallocate( $im, (int) ( $a[0] + ( $b[0] - $a[0] ) * $t ), (int) ( $a[1] + ( $b[1] - $a[1] ) * $t ), (int) ( $a[2] + ( $b[2] - $a[2] ) * $t ) ) ); }
	$sb = @imagecreatefrompng( __DIR__ . '/assets/simbolo.png' );
	if ( ! $sb ) { return; }
	$w = 700; $h = (int) round( imagesy( $sb ) * $w / imagesx( $sb ) );
	$tmp = imagecreatetruecolor( $w, $h ); imagealphablending( $tmp, false ); imagesavealpha( $tmp, true );
	imagecopyresampled( $tmp, $sb, 0, 0, 0, 0, $w, $h, imagesx( $sb ), imagesy( $sb ) );
	for ( $yy = 0; $yy < $h; $yy++ ) { for ( $xx = 0; $xx < $w; $xx++ ) { $c = imagecolorat( $tmp, $xx, $yy ); $al = ( $c >> 24 ) & 127; if ( $al < 127 ) { imagesetpixel( $tmp, $xx, $yy, ( min( 127, 127 - (int) ( ( 127 - $al ) * 0.07 ) ) << 24 ) | ( $c & 0xFFFFFF ) ); } } }
	imagealphablending( $im, true );
	imagecopy( $im, $tmp, $W - $w + 160, $H - $h + 40, 0, 0, $w, $h );
	imagedestroy( $tmp ); imagedestroy( $sb );
}

/** foto recortada em círculo, com borda */
function rri_car_circle( $im, $ph, $cx, $cy, $r, $border, $bcol ) {
	if ( ! $ph ) { return; }
	$d = $r * 2;
	$tmp = imagecreatetruecolor( $d, $d );
	rri_car_cover_rect( $tmp, $ph, 0, 0, $d, $d, 0.45 );
	imagefilledellipse( $im, $cx, $cy, $d + $border * 2, $d + $border * 2, $bcol );
	for ( $yy = 0; $yy < $d; $yy++ ) {
		for ( $xx = 0; $xx < $d; $xx++ ) {
			if ( ( $xx - $r ) * ( $xx - $r ) + ( $yy - $r ) * ( $yy - $r ) <= $r * $r ) {
				imagesetpixel( $im, $cx - $r + $xx, $cy - $r + $yy, imagecolorat( $tmp, $xx, $yy ) );
			}
		}
	}
	imagedestroy( $tmp );
}

/** escurece da linha $y0 até $y1 (alpha GD: 127 transparente, 0 opaco) */
function rri_car_grad( $im, $y0, $y1, $a0, $a1, $rgb = array( 0, 0, 0 ) ) {
	$n = max( 1, $y1 - $y0 );
	for ( $i = 0; $i <= $n; $i++ ) {
		$t = $i / $n;
		$a = (int) round( $a0 + ( $a1 - $a0 ) * ( $t * $t * ( 3 - 2 * $t ) ) );
		$c = imagecolorallocatealpha( $im, $rgb[0], $rgb[1], $rgb[2], max( 0, min( 127, $a ) ) );
		imageline( $im, 0, $y0 + $i, RRI_CAR_W, $y0 + $i, $c );
	}
}

function rri_car_dim( $im, $alpha ) {
	if ( ! empty( $GLOBALS['rri_car_liso'] ) ) { return; } // fundo verde liso não escurece
	$c = imagecolorallocatealpha( $im, 0, 0, 0, $alpha );
	imagefilledrectangle( $im, 0, 0, RRI_CAR_W, RRI_CAR_H, $c );
}

function rri_car_w( $size, $font, $txt ) {
	$b = imagettfbbox( $size, 0, $font, $txt );
	return $b[2] - $b[0];
}

/** texto com espaçamento entre letras */
function rri_car_track( $im, $size, $x, $y, $col, $font, $txt, $track ) {
	$chars = preg_split( '//u', $txt, -1, PREG_SPLIT_NO_EMPTY );
	foreach ( $chars as $ch ) {
		imagettftext( $im, $size, 0, (int) $x, (int) $y, $col, $font, $ch );
		$x += rri_car_w( $size, $font, $ch ) + $track;
	}
}
function rri_car_track_w( $size, $font, $txt, $track ) {
	$w = 0;
	foreach ( preg_split( '//u', $txt, -1, PREG_SPLIT_NO_EMPTY ) as $ch ) { $w += rri_car_w( $size, $font, $ch ) + $track; }
	return $w - $track;
}

/** quebra um texto simples em linhas que cabem em $max */
function rri_car_wrap( $size, $font, $txt, $max ) {
	$lines = array(); $cur = '';
	$ws = preg_split( '/\s+/u', trim( $txt ) );
	for ( $i = 0; $i < count( $ws ) - 1; $i++ ) { if ( preg_match( '/^(R|US|U)\$$/u', $ws[ $i ] ) ) { $ws[ $i + 1 ] = $ws[ $i ] . ' ' . $ws[ $i + 1 ]; array_splice( $ws, $i, 1 ); } }
	foreach ( $ws as $w ) {
		$try = '' === $cur ? $w : $cur . ' ' . $w;
		if ( rri_car_w( $size, $font, $try ) > $max && '' !== $cur ) { $lines[] = $cur; $cur = $w; }
		else { $cur = $try; }
	}
	if ( '' !== $cur ) { $lines[] = $cur; }
	return $lines;
}

/** texto rico (==rótulo== e **negrito**) em linhas centralizadas; devolve a altura usada */
function rri_car_rich_layout( $txt, $size, $max ) {
	$paras = preg_split( "/\n\s*\n/u", trim( str_replace( "\r", '', $txt ) ) );
	$out = array();
	foreach ( $paras as $p ) {
		$words = array();
		$parts = preg_split( '/(==.+?==|\*\*.+?\*\*)/u', $p, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		foreach ( $parts as $part ) {
			$st = 'reg';
			if ( preg_match( '/^==(.+)==$/u', $part, $m ) ) { $st = 'acc'; $part = $m[1]; }
			elseif ( preg_match( '/^\*\*(.+)\*\*$/u', $part, $m ) ) { $st = 'bold'; $part = $m[1]; }
			$toks = preg_split( '/(\s+)/u', $part, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE );
			foreach ( $toks as $t ) {
				if ( '' === trim( $t ) ) { if ( $words ) { $words[ count( $words ) - 1 ]['sp'] = true; } continue; }
				$words[] = array( 't' => $t, 's' => $st, 'sp' => false );
			}
		}
		$lines = array(); $cur = array(); $cw = 0;
		foreach ( $words as $i => $w ) {
			$font = rri_car_font( 'reg' === $w['s'] ? 'reg' : 'bold' );
			$ww = rri_car_w( $size, $font, $w['t'] );
			$gap = $cur && ( $cur[ count( $cur ) - 1 ]['sp'] ) ? rri_car_w( $size, $font, 'a a' ) - rri_car_w( $size, $font, 'aa' ) : 0;
			if ( $cur && $cw + $gap + $ww > $max ) { $lines[] = array( $cur, $cw ); $cur = array(); $cw = 0; $gap = 0; }
			$w['x'] = $cw + $gap; $w['w'] = $ww; $w['f'] = $font;
			$cur[] = $w; $cw += $gap + $ww;
		}
		if ( $cur ) { $lines[] = array( $cur, $cw ); }
		$out[] = $lines;
	}
	return $out;
}
function rri_car_rich_height( $layout, $size ) {
	$lh = $size * 1.38; $h = 0;
	foreach ( $layout as $i => $lines ) { $h += count( $lines ) * $lh + ( $i ? $size * 0.9 : 0 ); }
	return $h;
}
function rri_car_rich_draw( $im, $layout, $size, $y, $cols ) {
	$lh = $size * 1.38;
	foreach ( $layout as $i => $lines ) {
		if ( $i ) { $y += $size * 0.9; }
		foreach ( $lines as $ln ) {
			list( $words, $lw ) = $ln;
			$x0 = ( RRI_CAR_W - $lw ) / 2;
			foreach ( $words as $w ) {
				imagettftext( $im, $size, 0, (int) round( $x0 + $w['x'] ), (int) round( $y + $size ), 'acc' === $w['s'] ? $cols['acc'] : $cols['txt'], $w['f'], $w['t'] );
			}
			$y += $lh;
		}
	}
	return $y;
}
/** escolhe o maior tamanho em que o texto cabe na altura disponível */
function rri_car_fit_rich( $txt, $sizes, $max, $maxh ) {
	foreach ( $sizes as $s ) {
		$l = rri_car_rich_layout( $txt, $s, $max );
		if ( rri_car_rich_height( $l, $s ) <= $maxh ) { return array( $l, $s ); }
	}
	$s = end( $sizes );
	return array( rri_car_rich_layout( $txt, $s, $max ), $s );
}

/** etiqueta verde arredondada */
function rri_car_pill( $im, $x, $ybottom, $txt, $bg, $fg ) {
	$f = rri_car_font( 'xbold' ); $sz = 25; $tr = 2;
	$w = rri_car_track_w( $sz, $f, $txt, $tr ); $h = 50; $r = 25; $pad = 26;
	$x1 = $x + $w + $pad * 2; $y0 = $ybottom - $h;
	imagefilledrectangle( $im, $x + $r, $y0, $x1 - $r, $ybottom, $bg );
	imagefilledellipse( $im, $x + $r, $y0 + $r, $r * 2, $r * 2, $bg );
	imagefilledellipse( $im, $x1 - $r, $y0 + $r, $r * 2, $r * 2, $bg );
	rri_car_track( $im, $sz, $x + $pad, $ybottom - 14, $fg, $f, $txt, $tr );
}
function rri_car_rich_left( $im, $layout, $size, $y, $cols, $x0 ) {
	$lh = $size * 1.38;
	foreach ( $layout as $i => $lines ) {
		if ( $i ) { $y += $size * 0.9; }
		foreach ( $lines as $ln ) {
			foreach ( $ln[0] as $wd ) { imagettftext( $im, $size, 0, (int) round( $x0 + $wd['x'] ), (int) round( $y + $size ), 'acc' === $wd['s'] ? $cols['acc'] : $cols['txt'], $wd['f'], $wd['t'] ); }
			$y += $lh;
		}
	}
	return $y;
}

function rri_car_cols( $im ) {
	return array(
		'txt' => imagecolorallocate( $im, 255, 255, 255 ),
		'acc' => imagecolorallocate( $im, 126, 224, 163 ),
		'dim' => imagecolorallocatealpha( $im, 255, 255, 255, 50 ),
		'deep' => imagecolorallocate( $im, 22, 51, 39 ),
	);
}

if ( ! defined( 'RRI_CAR_LOGO_H' ) ) { define( 'RRI_CAR_LOGO_H', 62 ); }
function rri_car_logo( $im, $y = 58, $w = 210, $left = true, $dark = false ) {
	$lg = @imagecreatefrompng( __DIR__ . ( $dark ? '/assets/logo-escuro.png' : '/assets/logo-branco.png' ) );
	if ( ! $lg ) { return; }
	/* mesmo tamanho em todos os posts: altura fixa, largura pela proporção do arquivo */
	$h = RRI_CAR_LOGO_H; $w = (int) round( imagesx( $lg ) * $h / imagesy( $lg ) );
	imagecopyresampled( $im, $lg, $left ? 64 : (int) ( ( RRI_CAR_W - $w ) / 2 ), $y, 0, 0, $w, $h, imagesx( $lg ), imagesy( $lg ) );
	imagedestroy( $lg );
}

function rri_car_credit( $im, $cols, $txt, $right = true ) {
	return; // o crédito das fotos vai só na legenda do post (pedido do Pietro); no slide fica só a fonte
	if ( ! $txt ) { return; }
	$f = rri_car_font( 'reg' ); $s = 15;
	$txt = wp_html_excerpt( $txt, 90, '...' );
	while ( $s > 11 && rri_car_w( $s, $f, $txt ) > RRI_CAR_W - 140 ) { $s--; }
	$w = rri_car_w( $s, $f, $txt );
	imagettftext( $im, $s, 0, (int) ( $right ? RRI_CAR_W - 60 - $w : 60 ), RRI_CAR_H - 40, $cols['dim'], $f, $txt );
}

/** tira os == do texto e devolve [texto limpo, lista de destaque por palavra]; a pontuação acompanha a palavra */
function rri_car_flags( $g ) {
	$clean = ''; $acc = array(); $in = false;
	$n = mb_strlen( $g );
	for ( $i = 0; $i < $n; $i++ ) {
		if ( '==' === mb_substr( $g, $i, 2 ) ) { $in = ! $in; $i++; continue; }
		$ch = mb_substr( $g, $i, 1 ); $clean .= $ch; $acc[] = $in;
	}
	$flags = array(); $pos = 0; $len = mb_strlen( $clean );
	$clean2 = trim( preg_replace( '/\s+/u', ' ', $clean ) );
	foreach ( preg_split( '/\s+/u', trim( $clean ), -1, PREG_SPLIT_NO_EMPTY ) as $wd ) {
		$st = mb_strpos( $clean, $wd, $pos ); $wl = mb_strlen( $wd ); $a = 0; $t = 0;
		for ( $k = 0; $k < $wl; $k++ ) { if ( preg_match( '/[\p{L}\p{N}]/u', mb_substr( $wd, $k, 1 ) ) ) { $t++; if ( ! empty( $acc[ $st + $k ] ) ) { $a++; } } }
		$flags[] = $t ? ( $a * 2 > $t ) : false;
		$pos = $st + $wl;
	}
	return array( $clean2, $flags );
}

/** desenha um slide e devolve a imagem GD */
function rri_car_slide( $pid, $car, $sl, $n, $total ) {
	$GLOBALS['rri_car_liso'] = 0;
	$im = imagecreatetruecolor( RRI_CAR_W, RRI_CAR_H );
	imagealphablending( $im, true );
	$cols = rri_car_cols( $im );
	$tipo = $sl['tipo'] ?? 'texto';

	if ( 'capa' === $tipo ) {
		$ph = rri_car_photo( $pid, $car['capa'] ?? 'capa', $car['capa_foco'] ?? '' );
		$est = (string) ( $car['capa_estilo'] ?? 'classico' );
		if ( 'hoje' === $est ) { return rri_car_capa_hoje( $im, $pid, $car, $ph, $cols ); }
		if ( 'frase_do_dia' === $est ) { return rri_car_capa_frase( $im, $pid, $car, $ph, $cols ); }
		if ( 'urgente' === $est ) { return rri_car_capa_urgente( $im, $pid, $car, $ph, $cols ); }
		if ( 'historia' === $est ) { return rri_car_capa_historia( $im, $pid, $car, $ph, $cols ); }
		if ( 'trio' === $est ) { return rri_car_capa_trio( $im, $pid, $car, $ph, $cols ); }
		if ( 'placar' === $est ) { return rri_car_capa_placar( $im, $pid, $car, $ph, $cols ); }
		$extra = ! empty( $car['capa_extra'] ) ? rri_car_photo( $pid, $car['capa_extra'] ) : null;
		/* se as duas fotos forem a mesma (uma delas não baixou), usa a capa simples */
		if ( $extra && $ph && (int) $extra['id'] === (int) $ph['id'] ) { $extra = null; }
		if ( 'dupla' === $est && $extra ) {
			$half = RRI_CAR_W / 2;
			rri_car_cover_rect( $im, $ph, 0, 0, $half, RRI_CAR_H, 0.34 );
			rri_car_cover_rect( $im, $extra, $half, 0, $half, RRI_CAR_H, 0.34 );
			imagefilledrectangle( $im, $half - 3, 0, $half + 3, RRI_CAR_H, $cols['txt'] );
		} else {
			rri_car_cover( $im, $ph, 0.36 );
		}
		rri_car_grad( $im, 0, 230, 70, 127 );
		rri_car_grad( $im, 420, RRI_CAR_H, 127, 8 );
		rri_car_logo( $im, 58, 180 );
		if ( 'dupla' === $est && $extra ) {
			$rot = (array) ( $car['rotulos'] ?? array() );
			$fx = rri_car_font( 'black' );
			foreach ( array( 0, 1 ) as $k ) {
				if ( empty( $rot[ $k ] ) ) { continue; }
				$t = mb_strtoupper( $rot[ $k ] ); $ts = 44; while ( $ts > 22 && rri_car_w( $ts, $fx, $t ) > RRI_CAR_W / 2 - 150 ) { $ts -= 2; } $tw = rri_car_w( $ts, $fx, $t );
				$bx = (int) ( ( $k ? RRI_CAR_W * 0.75 : RRI_CAR_W * 0.25 ) - $tw / 2 );
				imagefilledrectangle( $im, $bx - 22, 190, $bx + $tw + 22, 262, $k ? $cols['acc'] : $cols['txt'] );
				imagettftext( $im, $ts, 0, $bx, (int) ( 226 + $ts * 0.5 ), $cols['deep'], $fx, $t );
			}
			imagefilledellipse( $im, RRI_CAR_W / 2, 470, 120, 120, $cols['acc'] );
			$xw = rri_car_w( 56, $fx, 'X' );
			imagettftext( $im, 56, 0, (int) ( RRI_CAR_W / 2 - $xw / 2 ), 498, $cols['deep'], $fx, 'X' );
		}
		if ( 'circulo' === $est && $extra ) {
			/* "circulo_tamanho": "pequeno" = bolinha discreta no canto, sem tapar a foto principal */
			if ( 'pequeno' === ( $car['circulo_tamanho'] ?? '' ) ) { rri_car_circle( $im, $extra, RRI_CAR_W - 170, 250, 105, 8, $cols['txt'] ); }
			else { rri_car_circle( $im, $extra, RRI_CAR_W - 230, 400, 170, 10, $cols['txt'] ); }
		}
		$unico = 'unico' === ( $car['formato'] ?? 'carrossel' );
		$frase = 'frase' === ( $car['estilo'] ?? 'caixa_alta' );
		$g = trim( (string) ( $car['gancho'] ?? get_the_title( $pid ) ) );
		/* ==palavra== sai em verde */
		list( $g, $flags ) = rri_car_flags( $g );
		if ( ! $frase ) { $g = mb_strtoupper( $g ); }
		$fb = rri_car_font( $frase ? 'bold' : 'brim' ); $x0 = 72; $max = RRI_CAR_W - $x0 - 96;
		$sizes = $frase ? array( 58, 54, 50, 46, 42, 40 ) : array( 76, 72, 68, 64, 60, 56, 52 );
		foreach ( $sizes as $s ) { $lines = rri_car_wrap( $s, $fb, $g, $max ); if ( count( $lines ) <= 4 ) { break; } }
		$lh = $s * ( $frase ? 1.5 : 1.42 ); $bottom = RRI_CAR_H - 240;
		/* subgancho: uma linha menor embaixo do gancho, que completa a promessa */
		$sub = trim( (string) ( $car['subgancho'] ?? '' ) ); $subl = array(); $fsub = rri_car_font( 'reg' ); $ss = 30;
		if ( $sub ) { $subl = rri_car_wrap( $ss, $fsub, $sub, $max ); if ( count( $subl ) > 2 ) { $ss = 26; $subl = array_slice( rri_car_wrap( $ss, $fsub, $sub, $max ), 0, 2 ); } $bottom -= count( $subl ) * $ss * 1.45 + 22; }
		$y = $bottom - count( $lines ) * $lh;
		/* véu escuro só atrás do texto: a foto continua limpa em cima */
		$vt = (int) ( $y - ( $ch_pre = 90 ) );
		rri_car_grad( $im, max( 0, $vt - 260 ), $vt - 1, 127, 42 );
		imagefilledrectangle( $im, 0, $vt, RRI_CAR_W, RRI_CAR_H, imagecolorallocatealpha( $im, 0, 0, 0, 42 ) );
		rri_car_grad( $im, $vt, RRI_CAR_H, 127, 30 );
		foreach ( $subl as $k => $sl2 ) { imagettftext( $im, $ss, 0, $x0, (int) ( $bottom + 22 + ( $k + 1 ) * $ss * 1.45 - $ss * 0.2 ), imagecolorallocatealpha( $im, 255, 255, 255, 18 ), $fsub, $sl2 ); }
		if ( $subl ) { $bottom += count( $subl ) * $ss * 1.45 + 22; }
		$ch = mb_strtoupper( trim( (string) ( $car['chamada'] ?? ( $unico ? '' : 'DESLIZE PARA VER' ) ) ) );
		if ( $ch ) { rri_car_pill( $im, $x0, (int) ( $y - 18 ), $ch, $cols['acc'], $cols['deep'] ); }
		$sp = max( $s * 0.24, rri_car_w( $s, $fb, 'A A' ) - rri_car_w( $s, $fb, 'AA' ) );
		$wi = 0;
		foreach ( $lines as $i => $ln ) {
			$x = $x0;
			$by = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.1 );
			foreach ( explode( ' ', $ln ) as $wd ) {
				$c = ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'];
				imagettftext( $im, $s, 0, (int) round( $x ) + 2, $by + 3, imagecolorallocatealpha( $im, 0, 0, 0, 70 ), $fb, $wd );
				imagettftext( $im, $s, 0, (int) round( $x ), $by, $c, $fb, $wd );
				$x += rri_car_w( $s, $fb, $wd ) + $sp; $wi++;
			}
		}
		/* linha verde fina embaixo do gancho */
		imagefilledrectangle( $im, $x0, $bottom + 26, $x0 + 110, $bottom + 32, $cols['acc'] );
		$cred = $ph['credit'] ?? '';
		if ( $extra && ! empty( $extra['credit'] ) && $extra['credit'] !== $cred ) { $cred = trim( $cred . ' · ' . str_replace( 'Foto: ', '', $extra['credit'] ) ); }
		rri_car_credit( $im, $cols, $cred );
		return $im;
	}

	if ( 'final' === $tipo || 'cta' === $tipo ) {
		/* último slide: chamada para seguir (CTA) */
		imagefilledrectangle( $im, 0, 0, RRI_CAR_W, RRI_CAR_H, $cols['deep'] );
		$sb = @imagecreatefrompng( __DIR__ . '/assets/simbolo.png' );
		if ( $sb ) {
			$w = 760; $h = (int) round( imagesy( $sb ) * $w / imagesx( $sb ) );
			$tmp = imagecreatetruecolor( $w, $h ); imagealphablending( $tmp, false ); imagesavealpha( $tmp, true );
			imagecopyresampled( $tmp, $sb, 0, 0, 0, 0, $w, $h, imagesx( $sb ), imagesy( $sb ) );
			for ( $yy = 0; $yy < $h; $yy++ ) { for ( $xx = 0; $xx < $w; $xx++ ) { $c = imagecolorat( $tmp, $xx, $yy ); $a = ( $c >> 24 ) & 127; if ( $a < 127 ) { imagesetpixel( $tmp, $xx, $yy, ( min( 127, 127 - (int) ( ( 127 - $a ) * 0.08 ) ) << 24 ) | ( $c & 0xFFFFFF ) ); } } }
			imagealphablending( $im, true );
			imagecopy( $im, $tmp, RRI_CAR_W - $w + 180, RRI_CAR_H - $h + 60, 0, 0, $w, $h );
			imagedestroy( $tmp ); imagedestroy( $sb );
		}
		rri_car_logo( $im, 58 );
		$x0 = 72; $max = RRI_CAR_W - $x0 - 100;
		$t1 = (string) ( $sl['titulo'] ?? 'O Instagram provavelmente nunca mais vai mostrar esta página para você.' );
		$t2 = (string) ( $sl['texto'] ?? 'Se você quer mais resenhas como esta, é só seguir a gente.' );
		$fb = rri_car_font( 'bold' ); $fs = rri_car_font( 'semi' );
		foreach ( array( 64, 60, 56, 52, 48 ) as $s1 ) { $l1 = rri_car_wrap( $s1, $fb, $t1, $max ); if ( count( $l1 ) <= 5 ) { break; } }
		$s2 = (int) round( $s1 * 0.72 ); $l2 = rri_car_wrap( $s2, $fs, $t2, $max );
		$lh1 = $s1 * 1.5; $lh2 = $s2 * 1.55;
		$hTot = count( $l1 ) * $lh1 + 50 + count( $l2 ) * $lh2;
		$y = (int) ( ( RRI_CAR_H - $hTot ) / 2 ) + 20;
		imagefilledrectangle( $im, $x0, $y - 34, $x0 + 90, $y - 26, $cols['acc'] );
		foreach ( $l1 as $ln ) { imagettftext( $im, $s1, 0, $x0, (int) ( $y + $s1 ), $cols['txt'], $fb, $ln ); $y += $lh1; }
		$y += 50;
		foreach ( $l2 as $ln ) { imagettftext( $im, $s2, 0, $x0, (int) ( $y + $s2 ), $cols['acc'], $fs, $ln ); $y += $lh2; }
		return $im;
	}

	/* slide sem "foto" não repete a capa: fica com o fundo verde liso (só "foto" e "item" exigem foto) */
	if ( isset( $sl['foto'] ) && '' !== trim( (string) $sl['foto'] ) ) { $ph = rri_car_photo( $pid, $sl['foto'], $sl['foco'] ?? '' ); }
	elseif ( in_array( $tipo, array( 'foto', 'item' ), true ) ) { $ph = rri_car_photo( $pid, $car['capa'] ?? 'capa', $sl['foco'] ?? '' ); }
	else { $ph = null; }

	if ( 'item' === $tipo ) { return rri_car_item( $im, $pid, $car, $sl, $ph, $cols ); }

	if ( 'foto' === $tipo ) {
		rri_car_cover( $im, $ph, 0.45 );
		rri_car_grad( $im, RRI_CAR_H - 160, RRI_CAR_H, 127, 60 );
		if ( ! empty( $sl['texto'] ) ) {
			rri_car_grad( $im, 560, RRI_CAR_H, 127, 10 );
			list( $l, $s ) = rri_car_fit_rich( $sl['texto'], array( 40, 36, 32 ), RRI_CAR_W - 180, 420 );
			rri_car_rich_draw( $im, $l, $s, RRI_CAR_H - 230 - rri_car_rich_height( $l, $s ), $cols );
		}
		rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
		rri_car_logo( $im, 58, 150, true, false );
		return $im;
	}

	if ( 'ranking' === $tipo ) {
		rri_car_cover( $im, $ph, 0.35 );
		rri_car_grad( $im, 560, RRI_CAR_H, 127, 5 );
		$fb = rri_car_font( 'brim' );
		$pos = str_replace( array( 'º', 'ª' ), '°', (string) ( $sl['posicao'] ?? $n . '°' ) );
		$pw = rri_car_w( 170, $fb, $pos );
		$by = RRI_CAR_H - 240;
		imagettftext( $im, 170, 0, 64, $by, $cols['acc'], $fb, $pos );
		$lx = 70 + $pw + 44;
		imagefilledrectangle( $im, $lx, $by - 140, $lx + 3, $by, $cols['dim'] );
		$nm = mb_strtoupper( (string) ( $sl['nome'] ?? '' ) );
		$ns = 54; while ( $ns > 34 && rri_car_w( $ns, $fb, $nm ) > RRI_CAR_W - $lx - 80 ) { $ns -= 2; }
		imagettftext( $im, $ns, 0, $lx + 40, $by - 70, $cols['txt'], $fb, $nm );
		imagettftext( $im, 40, 0, $lx + 40, $by - 8, $cols['txt'], rri_car_font( 'reg' ), (string) ( $sl['detalhe'] ?? '' ) );
		rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
		rri_car_logo( $im, 58, 150, true, false );
		return $im;
	}

	if ( 'texto_claro' === $tipo ) {
		$cream = imagecolorallocate( $im, 245, 244, 238 );
		imagefilledrectangle( $im, 0, 0, RRI_CAR_W, RRI_CAR_H, $cream );
		$lc = array( 'txt' => imagecolorallocate( $im, 22, 51, 39 ), 'acc' => imagecolorallocate( $im, 47, 138, 99 ) );
		$max = RRI_CAR_W - 170; $fx = rri_car_font( 'brim' );
		$tl = ! empty( $sl['titulo'] ) ? rri_car_wrap( 68, $fx, mb_strtoupper( $sl['titulo'] ), $max ) : array();
		list( $l, $s ) = rri_car_fit_rich( (string) ( $sl['texto'] ?? '' ), array( 44, 41, 38, 35, 32 ), $max, RRI_CAR_H - 360 - count( $tl ) * 96 );
		$h = ( $tl ? count( $tl ) * 96 + 50 : 0 ) + rri_car_rich_height( $l, $s );
		$y = ( RRI_CAR_H - $h ) / 2;
		imagefilledrectangle( $im, (int) ( RRI_CAR_W / 2 - 50 ), (int) ( $y - 60 ), (int) ( RRI_CAR_W / 2 + 50 ), (int) ( $y - 52 ), $lc['acc'] );
		foreach ( $tl as $ln ) { $w = rri_car_w( 68, $fx, $ln ); imagettftext( $im, 68, 0, (int) ( ( RRI_CAR_W - $w ) / 2 ), (int) ( $y + 80 ), $lc['txt'], $fx, $ln ); $y += 96; }
		if ( $tl ) { $y += 50; }
		rri_car_rich_draw( $im, $l, $s, $y, $lc );
		if ( ! empty( $sl['fonte'] ) ) { $f = rri_car_font( 'reg' ); $t = 'Fonte: ' . $sl['fonte']; $w = rri_car_w( 17, $f, $t ); imagettftext( $im, 17, 0, (int) ( ( RRI_CAR_W - $w ) / 2 ), RRI_CAR_H - 62, imagecolorallocate( $im, 110, 130, 120 ), $f, $t ); }
		rri_car_logo( $im, 58, 150, true, true );
		return $im;
	}

	if ( 'foto_texto' === $tipo ) {
		$ph2 = rri_car_photo( $pid, $sl['foto'] ?? 'capa', $sl['foco'] ?? '' );
		$top = 760;
		rri_car_cover_rect( $im, $ph2, 0, 0, RRI_CAR_W, $top, 0.4 );
		imagefilledrectangle( $im, 0, $top, RRI_CAR_W, RRI_CAR_H, $cols['deep'] );
		imagefilledrectangle( $im, 0, $top, RRI_CAR_W, $top + 8, $cols['acc'] );
		$max = RRI_CAR_W - 180; $fx = rri_car_font( 'brim' );
		$y = $top + 56;
		if ( ! empty( $sl['titulo'] ) ) {
			foreach ( rri_car_wrap( 54, $fx, mb_strtoupper( $sl['titulo'] ), $max ) as $ln ) { imagettftext( $im, 54, 0, 75, (int) ( $y + 68 ), $cols['acc'], $fx, $ln ); $y += 80; }
			$y += 24;
		}
		list( $l, $s ) = rri_car_fit_rich( (string) ( $sl['texto'] ?? '' ), array( 38, 35, 32, 29 ), $max, RRI_CAR_H - $y - 70 );
		/* texto alinhado à esquerda */
		$lh = $s * 1.38;
		foreach ( $l as $i => $lines ) {
			if ( $i ) { $y += $s * 0.9; }
			foreach ( $lines as $ln ) { foreach ( $ln[0] as $wd ) { imagettftext( $im, $s, 0, (int) round( 75 + $wd['x'] ), (int) round( $y + $s ), 'acc' === $wd['s'] ? $cols['acc'] : $cols['txt'], $wd['f'], $wd['t'] ); } $y += $lh; }
		}
		rri_car_credit( $im, $cols, $ph2['credit'] ?? '' );
		rri_car_logo( $im, 58, 150, true, false );
		return $im;
	}

	if ( 'comparacao' === $tipo ) {
		rri_car_cover( $im, $ph, 0.4 );
		rri_car_dim( $im, 20 );
		$fx = rri_car_font( 'brim' ); $fr = rri_car_font( 'reg' );
		$y = 300;
		if ( ! empty( $sl['titulo'] ) ) {
			foreach ( rri_car_wrap( 54, $fx, mb_strtoupper( $sl['titulo'] ), RRI_CAR_W - 180 ) as $ln ) { $w = rri_car_w( 54, $fx, $ln ); imagettftext( $im, 54, 0, (int) ( ( RRI_CAR_W - $w ) / 2 ), $y, $cols['txt'], $fx, $ln ); $y += 66; }
		}
		$cols2 = array( (array) ( $sl['esquerda'] ?? array() ), (array) ( $sl['direita'] ?? array() ) );
		$colw = RRI_CAR_W / 2 - 80; $vy = $y + 170;
		foreach ( $cols2 as $k => $c ) {
			$cx = $k ? RRI_CAR_W * 0.75 : RRI_CAR_W * 0.25;
			$r = mb_strtoupper( (string) ( $c['rotulo'] ?? '' ) ); $rw = rri_car_track_w( 36, rri_car_font( 'xbold' ), $r, 2 );
			rri_car_track( $im, 36, $cx - $rw / 2, $vy, $k ? $cols['acc'] : $cols['txt'], rri_car_font( 'xbold' ), $r, 2 );
			$v = mb_strtoupper( (string) ( $c['valor'] ?? '' ) ); $vs = 130; while ( $vs > 50 && rri_car_w( $vs, $fx, $v ) > $colw ) { $vs -= 4; }
			$vw = rri_car_w( $vs, $fx, $v );
			imagettftext( $im, $vs, 0, (int) ( $cx - $vw / 2 ), (int) ( $vy + 40 + $vs ), $k ? $cols['acc'] : $cols['txt'], $fx, $v );
			$dy = $vy + 90 + $vs;
			foreach ( rri_car_wrap( 32, $fr, (string) ( $c['detalhe'] ?? '' ), $colw ) as $ln ) { $w = rri_car_w( 32, $fr, $ln ); imagettftext( $im, 32, 0, (int) ( $cx - $w / 2 ), (int) $dy, $cols['txt'], $fr, $ln ); $dy += 44; }
		}
		imagefilledrectangle( $im, RRI_CAR_W / 2 - 2, $vy - 40, RRI_CAR_W / 2 + 2, $vy + 330, $cols['dim'] );
		if ( ! empty( $sl['texto'] ) ) {
			list( $l, $s ) = rri_car_fit_rich( $sl['texto'], array( 38, 34, 30 ), RRI_CAR_W - 190, 300 );
			rri_car_rich_draw( $im, $l, $s, $vy + 420, $cols );
		}
		if ( ! empty( $sl['fonte'] ) ) { $t = 'Fonte: ' . $sl['fonte']; $w = rri_car_w( 17, $fr, $t ); imagettftext( $im, 17, 0, (int) ( ( RRI_CAR_W - $w ) / 2 ), RRI_CAR_H - 62, $cols['dim'], $fr, $t ); }
		rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
		rri_car_logo( $im, 58, 150, true, false );
		return $im;
	}

	if ( 'citacao' === $tipo ) {
		rri_car_cover( $im, $ph, 0.4 );
		rri_car_dim( $im, 18 );
		$fx = rri_car_font( 'brim' );
		imagettftext( $im, 300, 0, 60, 500, $cols['acc'], $fx, '“' );
		$max = RRI_CAR_W - 180; $fs = rri_car_font( 'semi' );
		$q = (string) ( $sl['texto'] ?? '' ); $qs = 58;
		while ( $qs > 34 && count( rri_car_wrap( $qs, $fs, $q, $max ) ) * $qs * 1.3 > 560 ) { $qs -= 3; }
		$y = 540;
		foreach ( rri_car_wrap( $qs, $fs, $q, $max ) as $ln ) { imagettftext( $im, $qs, 0, 75, (int) $y, $cols['txt'], $fs, $ln ); $y += $qs * 1.3; }
		if ( ! empty( $sl['autor'] ) ) {
			$a = mb_strtoupper( $sl['autor'] );
			imagefilledrectangle( $im, 75, (int) ( $y + 20 ), 135, (int) ( $y + 26 ), $cols['acc'] );
			rri_car_track( $im, 30, 75, $y + 80, $cols['acc'], rri_car_font( 'xbold' ), $a, 2 );
			if ( ! empty( $sl['contexto'] ) ) { imagettftext( $im, 28, 0, 75, (int) ( $y + 128 ), $cols['txt'], rri_car_font( 'reg' ), (string) $sl['contexto'] ); }
		}
		rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
		rri_car_logo( $im, 58, 150, true, false );
		return $im;
	}

	/* texto e numero: foto de fundo escurecida, texto à esquerda com barra verde */
	rri_car_cover( $im, $ph, 0.4 );
	rri_car_dim( $im, 22 );
	$x0 = 112; $max = RRI_CAR_W - $x0 - 100;
	$fbr = rri_car_font( 'brim' );
	$num = 'numero' === $tipo ? (string) ( $sl['numero'] ?? '' ) : '';
	$ns = 0;
	if ( '' !== $num ) { $num = mb_strtoupper( $num ); $ns = 210; while ( $ns > 80 && rri_car_w( $ns, $fbr, $num ) > $max ) { $ns -= 6; } }
	$tl = ! empty( $sl['titulo'] ) ? rri_car_wrap( 62, $fbr, mb_strtoupper( $sl['titulo'] ), $max ) : array();
	$numh = $ns ? $ns * 1.4 : 0;
	list( $l, $s ) = rri_car_fit_rich( (string) ( $sl['texto'] ?? '' ), array( 44, 41, 38, 35, 32, 29 ), $max, RRI_CAR_H - 320 - $numh - count( $tl ) * 88 );
	$h = $numh + ( $tl ? count( $tl ) * 88 + 34 : 0 ) + rri_car_rich_height( $l, $s );
	$y = ( RRI_CAR_H - $h ) / 2 - 10; $ytop = $y;
	if ( $ns ) { imagettftext( $im, $ns, 0, $x0 - 6, (int) ( $y + $ns * 1.2 ), $cols['acc'], $fbr, $num ); $y += $numh; }
	foreach ( $tl as $ln ) { imagettftext( $im, 62, 0, $x0, (int) ( $y + 76 ), $ns ? $cols['txt'] : $cols['acc'], $fbr, $ln ); $y += 88; }
	if ( $tl ) { $y += 34; }
	$yend = rri_car_rich_left( $im, $l, $s, $y, $cols, $x0 );
	imagefilledrectangle( $im, 64, (int) $ytop + 6, 72, (int) $yend - 8, $cols['acc'] );
	if ( ! empty( $sl['fonte'] ) ) {
		$f = rri_car_font( 'reg' ); $t = 'Fonte: ' . $sl['fonte'];
		imagettftext( $im, 17, 0, $x0, RRI_CAR_H - 62, $cols['dim'], $f, $t );
	}
	rri_car_logo( $im, 58, 150 );
	rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
	return $im;
}

/** gera todos os slides do post e guarda em uploads/carrossel/ID/ */
function rri_car_render( $pid ) {
	$car = json_decode( (string) get_post_meta( $pid, '_rr_carrossel', true ), true );
	if ( ! is_array( $car ) ) { return new WP_Error( 'rri', 'Esta matéria não tem carrossel.' ); }
	@set_time_limit( 300 );
	$slides = 'unico' === ( $car['formato'] ?? 'carrossel' ) ? array( array( 'tipo' => 'capa' ) ) : array_merge( array( array( 'tipo' => 'capa' ) ), (array) ( $car['slides'] ?? array() ) );
	if ( 'unico' !== ( $car['formato'] ?? 'carrossel' ) ) {
		/* todo carrossel termina com o slide de CTA (seguir o perfil) */
		$last = end( $slides );
		$cta = ( $last && in_array( $last['tipo'] ?? '', array( 'final', 'cta' ), true ) ) ? array_pop( $slides ) : array( 'tipo' => 'final' );
		$slides = array_slice( $slides, 0, 9 );
		$slides[] = $cta;
	}
	$slides = array_slice( $slides, 0, 10 ); // limite do Instagram
	$up = wp_upload_dir();
	$dir = trailingslashit( $up['basedir'] ) . 'carrossel/' . $pid . '/';
	$url = trailingslashit( $up['baseurl'] ) . 'carrossel/' . $pid . '/';
	wp_mkdir_p( $dir );
	foreach ( glob( $dir . '*.jpg' ) ?: array() as $old ) { @unlink( $old ); }
	$v = substr( md5( wp_json_encode( $car ) . time() ), 0, 6 );
	$out = array();
	$GLOBALS['rri_car_falhou'] = 0;
	foreach ( $slides as $i => $sl ) {
		$im = rri_car_slide( $pid, $car, (array) $sl, $i + 1, count( $slides ) );
		$name = sprintf( 'slide-%02d-%s.jpg', $i + 1, $v );
		imagejpeg( $im, $dir . $name, 84 );
		imagedestroy( $im );
		$out[] = $url . $name;
	}
	update_post_meta( $pid, '_rr_car_slides', $out );
	if ( ! empty( $GLOBALS['rri_car_falhou'] ) ) { update_post_meta( $pid, '_rr_car_semfoto', 1 ); } else { delete_post_meta( $pid, '_rr_car_semfoto' ); }
	return $out;
}

/** guarda o carrossel vindo do importador e já gera os slides */
function rri_car_attach( $pid, $car ) {
	if ( ! is_array( $car ) || empty( $car['gancho'] ) ) { return; }
	update_post_meta( $pid, '_rr_carrossel', wp_slash( wp_json_encode( $car, JSON_UNESCAPED_UNICODE ) ) );
	rri_car_render( $pid );
}

/* quadro no editor do post */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rri_car', 'Carrossel do Instagram', function ( $post ) {
		$car = json_decode( (string) get_post_meta( $post->ID, '_rr_carrossel', true ), true );
		if ( ! is_array( $car ) ) { echo '<p>Esta matéria não tem carrossel.</p>'; return; }
		$sl = (array) get_post_meta( $post->ID, '_rr_car_slides', true );
		echo '<p><strong>Gancho:</strong> ' . esc_html( $car['gancho'] ?? '' ) . '</p>';
		echo '<div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:6px">';
		foreach ( $sl as $u ) { echo '<a href="' . esc_url( $u ) . '" target="_blank"><img src="' . esc_url( $u ) . '" style="width:160px;height:200px;object-fit:cover;border-radius:6px;display:block"></a>'; }
		echo '</div>';
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=rri_car_regen&post=' . $post->ID ), 'rri_car_' . $post->ID );
		echo '<p><a class="button" href="' . esc_url( $url ) . '">Gerar os slides de novo</a></p>';
		rri_ig_box_status( $post->ID );
		if ( ! empty( $car['legenda'] ) ) { echo '<details><summary>Legenda do post</summary><div style="white-space:pre-wrap;margin-top:6px">' . esc_html( $car['legenda'] ) . '</div></details>'; }
	}, array( 'post', 'rr_insta' ), 'normal', 'default' );
} );
add_action( 'admin_post_rri_car_regen', function () {
	$pid = (int) ( $_GET['post'] ?? 0 );
	if ( ! $pid || ! current_user_can( 'edit_post', $pid ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_car_' . $pid );
	if ( get_post_meta( $pid, '_rr_foto_conferir', true ) ) { delete_post_meta( $pid, '_rr_foto_conferir' ); delete_post_meta( $pid, '_rr_ig_err' ); } // quem clicou conferiu as fotos
	rri_car_render( $pid );
	wp_safe_redirect( get_edit_post_link( $pid, 'url' ) . '#rri_car' );
	exit;
} );


/** capa "Hoje na história": foto em tela cheia (preto e branco só em morte), moldura fina e um selo */
function rri_car_capa_hoje( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H;
	$cream = imagecolorallocate( $im, 244, 239, 227 );
	if ( $ph ) { rri_car_cover( $im, $ph, 0.3 ); }
	if ( ! empty( $car['luto'] ) ) { imagefilter( $im, IMG_FILTER_GRAYSCALE ); imagefilter( $im, IMG_FILTER_CONTRAST, -10 ); }
	rri_car_grad( $im, 0, 240, 60, 127 );
	rri_car_grad( $im, 520, $H, 127, 10 );
	rri_car_logo( $im, 58, 170 );
	/* selo, como um carimbo */
	$ha = mb_strtoupper( trim( (string) ( $car['ha'] ?? '' ) ) );
	$sw = 300; $sh = 150;
	$st = imagecreatetruecolor( $sw + 20, $sh + 20 ); imagesavealpha( $st, true ); imagealphablending( $st, false );
	imagefill( $st, 0, 0, imagecolorallocatealpha( $st, 0, 0, 0, 127 ) ); imagealphablending( $st, true );
	$c_cream = imagecolorallocate( $st, 244, 239, 227 ); $c_ink = imagecolorallocate( $st, 22, 51, 39 ); $c_mid = imagecolorallocate( $st, 47, 122, 84 );
	imagefilledrectangle( $st, 10, 10, $sw + 10, $sh + 10, $c_cream );
	imagesetthickness( $st, 3 ); imagerectangle( $st, 22, 22, $sw - 2, $sh - 2, $c_ink ); imagesetthickness( $st, 1 );
	$fb = rri_car_font( 'brim' );
	$ss = 44; while ( $ss > 24 && rri_car_w( $ss, $fb, 'HISTÓRIA' ) > $sw - 70 ) { $ss -= 2; }
	foreach ( array( array( 'HOJE NA', 82 ), array( 'HISTÓRIA', 132 ) ) as $t ) { $w = rri_car_w( $ss, $fb, $t[0] ); imagettftext( $st, $ss, 0, (int) ( 10 + ( $sw - $w ) / 2 ), $t[1], $c_ink, $fb, $t[0] ); }
	$rot = $st;
	imagecopy( $im, $rot, $W - imagesx( $rot ) - 64, 46, 0, 0, imagesx( $rot ), imagesy( $rot ) );
	imagedestroy( $st );
	/* gancho curto, ==nome== em verde */
	$g = trim( (string) ( $car['gancho'] ?? get_the_title( $pid ) ) );
	list( $g, $flags ) = rri_car_flags( $g );
	$fg = rri_car_font( 'bold' ); $x0 = 80; $max = $W - 180;
	foreach ( array( 64, 60, 56, 52, 48 ) as $s ) { $lines = rri_car_wrap( $s, $fg, $g, $max ); if ( count( $lines ) <= 3 ) { break; } }
	$lh = $s * 1.42; $bottom = $H - 240; $y = $bottom - count( $lines ) * $lh;
	if ( $ha ) { rri_car_track( $im, 24, $x0, (int) ( $y - 4 ), $cols['acc'], rri_car_font( 'xbold' ), $ha, 3 ); }
	$sp = max( $s * 0.24, rri_car_w( $s, $fg, 'A A' ) - rri_car_w( $s, $fg, 'AA' ) );
	$wi = 0;
	foreach ( $lines as $i => $ln ) {
		$x = $x0; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.2 );
		foreach ( explode( ' ', $ln ) as $wd ) {
			imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fg, $wd );
			$x += rri_car_w( $s, $fg, $wd ) + $sp; $wi++;
		}
	}
	imagefilledrectangle( $im, $x0, $bottom + 26, $x0 + 110, $bottom + 32, $cols['acc'] );
	$cred = trim( (string) ( $ph['credit'] ?? '' ) );
	if ( $cred ) { $fr = rri_car_font( 'reg' ); $cw2 = rri_car_w( 16, $fr, $cred ); imagettftext( $im, 16, 0, $W - 70 - $cw2, $H - 56, imagecolorallocatealpha( $im, 255, 255, 255, 45 ), $fr, $cred ); }
	return $im;
}

/** frase do dia: a frase é o centro. Fundo verde-escuro profundo, aspas gigantes ao fundo, frase em branco, autor embaixo */
function rri_car_capa_frase( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 90;
	$bg1 = array( 5, 15, 11 ); $bg2 = array( 12, 30, 22 );
	for ( $y = 0; $y < $H; $y++ ) { $t = $y / $H; imageline( $im, 0, $y, $W, $y, imagecolorallocate( $im, (int) ( $bg2[0] + ( $bg1[0] - $bg2[0] ) * $t ), (int) ( $bg2[1] + ( $bg1[1] - $bg2[1] ) * $t ), (int) ( $bg2[2] + ( $bg1[2] - $bg2[2] ) * $t ) ) ); }
	$soft = imagecolorallocatealpha( $im, 126, 224, 163, 112 );
	$gray = imagecolorallocatealpha( $im, 255, 255, 255, 45 );
	$fb = rri_car_font( 'brim' ); $fx = rri_car_font( 'xbold' );
	imagettftext( $im, 520, 0, $M - 30, 760, $soft, $fb, '“' );
	$sb = @imagecreatefrompng( __DIR__ . '/assets/simbolo.png' );
	if ( $sb ) {
		$w = 440; $h = (int) round( imagesy( $sb ) * $w / imagesx( $sb ) );
		$tmp = imagecreatetruecolor( $w, $h ); imagealphablending( $tmp, false ); imagesavealpha( $tmp, true );
		imagecopyresampled( $tmp, $sb, 0, 0, 0, 0, $w, $h, imagesx( $sb ), imagesy( $sb ) );
		for ( $yy = 0; $yy < $h; $yy++ ) { for ( $xx = 0; $xx < $w; $xx++ ) { $c = imagecolorat( $tmp, $xx, $yy ); $a = ( $c >> 24 ) & 127; if ( $a < 127 ) { imagesetpixel( $tmp, $xx, $yy, ( min( 127, 127 - (int) ( ( 127 - $a ) * 0.06 ) ) << 24 ) | 0xFFFFFF ); } } }
		imagealphablending( $im, true ); imagecopy( $im, $tmp, $W - $w + 100, $H - $h + 80, 0, 0, $w, $h ); imagedestroy( $tmp ); imagedestroy( $sb );
	}
	rri_car_logo( $im, 58, 170 );
	$tag = 'FRASE DO DIA'; $tw = rri_car_track_w( 22, $fx, $tag, 3 ); rri_car_track( $im, 22, $W - $M - $tw, 104, $cols['acc'], $fx, $tag, 3 );
	$fq = trim( (string) ( $car['frase'] ?? ( $car['gancho'] ?? '' ) ) );
	list( $fq, $flags ) = rri_car_flags( $fq );
	$fg = rri_car_font( 'bold' ); $max = $W - 2 * $M;
	foreach ( array( 68, 64, 60, 56, 52, 48, 44 ) as $s ) { $lines = rri_car_wrap( $s, $fg, $fq, $max ); if ( count( $lines ) <= 6 ) { break; } }
	$lh = $s * 1.34;
	$nome = mb_strtoupper( trim( (string) ( $car['autor'] ?? '' ) ) );
	$cargo = mb_strtoupper( trim( (string) ( $car['cargo'] ?? '' ) ) );
	$blockH = count( $lines ) * $lh + 110 + ( $cargo ? 40 : 0 );
	$y = (int) max( 330, ( $H - $blockH ) / 2 + 60 );
	$sp = max( $s * 0.24, rri_car_w( $s, $fg, 'A A' ) - rri_car_w( $s, $fg, 'AA' ) ); $wi = 0;
	foreach ( $lines as $i => $ln ) {
		$x = $M; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.25 );
		foreach ( explode( ' ', $ln ) as $wd ) { imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fg, $wd ); $x += rri_car_w( $s, $fg, $wd ) + $sp; $wi++; }
	}
	$y = (int) ( $y + count( $lines ) * $lh + 50 );
	imagefilledrectangle( $im, $M, $y, $M + 70, $y + 6, $cols['acc'] );
	$y += 60;
	if ( $nome ) { $ns = 40; while ( $ns > 26 && rri_car_w( $ns, $fb, $nome ) > $max ) { $ns -= 2; } imagettftext( $im, $ns, 0, $M, $y, $cols['acc'], $fb, $nome ); }
	if ( $cargo ) { $cs = 19; while ( $cs > 13 && rri_car_track_w( $cs, $fx, $cargo, 2 ) > $max ) { $cs--; } rri_car_track( $im, $cs, $M, $y + 40, $gray, $fx, $cargo, 2 ); }
	return $im;
}


/** imagem única de notícia urgente: foto em cima, painel verde-escuro sólido embaixo, etiqueta vermelha de alerta */
function rri_car_capa_urgente( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 72; $cut = 760;
	$deep = imagecolorallocate( $im, 16, 38, 29 ); $red = imagecolorallocate( $im, 214, 48, 49 );
	$tmp = imagecreatetruecolor( $W, $cut ); if ( $ph ) { rri_car_cover_rect( $tmp, $ph, 0, 0, $W, $cut, 0.32 ); } imagecopy( $im, $tmp, 0, 0, 0, 0, $W, $cut ); imagedestroy( $tmp );
	rri_car_grad( $im, 0, 220, 70, 127 );
	imagefilledrectangle( $im, 0, $cut, $W, $H, $deep );
	imagefilledrectangle( $im, 0, $cut, $W, $cut + 8, $cols['acc'] );
	rri_car_logo( $im, 58, 170 );
	/* etiqueta de alerta e hora */
	$tag = mb_strtoupper( trim( (string) ( $car['chamada'] ?? 'Urgente' ) ), 'UTF-8' ); $tag = rtrim( $tag, ':' );
	$fx = rri_car_font( 'xbold' ); $tw = rri_car_track_w( 26, $fx, $tag, 3 );
	$ty = $cut + 70;
	imagefilledrectangle( $im, $M, $ty - 44, $M + $tw + 44, $ty + 14, $red );
	imagefilledellipse( $im, $M + 24, $ty - 15, 12, 12, $cols['txt'] );
	rri_car_track( $im, 26, $M + 38, $ty, $cols['txt'], $fx, $tag, 3 );
	/* sem data: o post já sai na hora */
	/* manchete */
	list( $g, $flags ) = rri_car_flags( trim( (string) ( $car['gancho'] ?? get_the_title( $pid ) ) ) );
	$fg = rri_car_font( 'bold' ); $max = $W - 2 * $M;
	foreach ( array( 58, 54, 50, 46, 42 ) as $s ) { $lines = rri_car_wrap( $s, $fg, $g, $max ); if ( count( $lines ) <= 4 ) { break; } }
	$lh = $s * 1.38; $y = $ty + 40;
	$sp = max( $s * 0.24, rri_car_w( $s, $fg, 'A A' ) - rri_car_w( $s, $fg, 'AA' ) ); $wi = 0;
	foreach ( $lines as $i => $ln ) { $x = $M; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.2 ); foreach ( explode( ' ', $ln ) as $wd ) { imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fg, $wd ); $x += rri_car_w( $s, $fg, $wd ) + $sp; $wi++; } }
	$cred = trim( (string) ( $ph['credit'] ?? '' ) );
	if ( $cred ) { $fr = rri_car_font( 'reg' ); $cw = rri_car_w( 15, $fr, $cred ); imagettftext( $im, 15, 0, $W - $M - $cw, $cut - 22, imagecolorallocatealpha( $im, 255, 255, 255, 40 ), $fr, $cred ); }
	return $im;
}

/** placar: comparação de números em linhas, com barras proporcionais (post de dados) */
function rri_car_capa_placar( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 84;
	for ( $y = 0; $y < $H; $y++ ) { $t = $y / $H; imageline( $im, 0, $y, $W, $y, imagecolorallocate( $im, (int) ( 22 - 10 * $t ), (int) ( 51 - 23 * $t ), (int) ( 39 - 17 * $t ) ) ); }
	rri_car_logo( $im, 58, 170 );
	$fx = rri_car_font( 'xbold' ); $fb = rri_car_font( 'brim' ); $fg = rri_car_font( 'bold' ); $fr = rri_car_font( 'reg' );
	$tag = mb_strtoupper( trim( (string) ( $car['chamada'] ?? 'Em números' ) ) ); $tw = rri_car_track_w( 22, $fx, $tag, 3 ); rri_car_track( $im, 22, $W - $M - $tw, 104, $cols['acc'], $fx, $tag, 3 );
	list( $g, $flags ) = rri_car_flags( trim( (string) ( $car['gancho'] ?? '' ) ) );
	foreach ( array( 60, 56, 52, 48 ) as $s ) { $lines = rri_car_wrap( $s, $fg, $g, $W - 2 * $M ); if ( count( $lines ) <= 3 ) { break; } }
	$y = 250; $lh = $s * 1.34; $sp = max( $s * 0.24, rri_car_w( $s, $fg, 'A A' ) - rri_car_w( $s, $fg, 'AA' ) ); $wi = 0;
	foreach ( $lines as $i => $ln ) { $x = $M; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.2 ); foreach ( explode( ' ', $ln ) as $wd ) { imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fg, $wd ); $x += rri_car_w( $s, $fg, $wd ) + $sp; $wi++; } }
	$y += count( $lines ) * $lh + 80;
	$rows = array_slice( (array) ( $car['linhas'] ?? array() ), 0, 5 );
	$mx = 0; foreach ( $rows as $r ) { $mx = max( $mx, (float) ( $r['num'] ?? 0 ) ); }
	$rh = min( 170, (int) ( ( $H - 180 - $y ) / max( 1, count( $rows ) ) ) );
	$barW = $W - 2 * $M;
	foreach ( $rows as $i => $r ) {
		$ry = (int) round( $y + $i * $rh );
		$hl = ! empty( $r['destaque'] );
		$v = (string) ( $r['valor'] ?? '' ); $vs = 50; $vw = rri_car_w( $vs, $fb, $v );
		$lab = mb_strtoupper( (string) ( $r['rotulo'] ?? '' ) ); $ls = 24; while ( $ls > 15 && rri_car_track_w( $ls, $fx, $lab, 1 ) > $barW - $vw - 40 ) { $ls--; }
		rri_car_track( $im, $ls, $M, $ry + 52, imagecolorallocatealpha( $im, 255, 255, 255, 20 ), $fx, $lab, 1 );
		imagettftext( $im, $vs, 0, $W - $M - $vw, $ry + 58, $hl ? $cols['acc'] : $cols['txt'], $fb, $v );
		$frac = $mx > 0 ? max( 0.06, (float) ( $r['num'] ?? 0 ) / $mx ) : 0;
		imagefilledrectangle( $im, $M, $ry + 78, $M + $barW, $ry + 108, imagecolorallocatealpha( $im, 255, 255, 255, 115 ) );
		imagefilledrectangle( $im, $M, $ry + 78, (int) ( $M + $barW * $frac ), $ry + 108, $hl ? $cols['acc'] : imagecolorallocate( $im, 47, 122, 84 ) );
	}
	if ( ! empty( $car['fonte'] ) ) { $t = 'Fonte: ' . $car['fonte']; imagettftext( $im, 17, 0, $M, $H - 70, imagecolorallocatealpha( $im, 255, 255, 255, 50 ), $fr, $t ); }
	return $im;
}


/* texto do gancho com ==destaque==, alinhado à esquerda, a partir da linha de base de baixo */
function rri_car_hook_up( $im, $g, $x0, $bottom, $max, $sizes, $cols, $maxl = 3 ) {
	list( $g, $flags ) = rri_car_flags( $g );
	$fg = rri_car_font( 'bold' );
	foreach ( $sizes as $s ) { $lines = rri_car_wrap( $s, $fg, $g, $max ); if ( count( $lines ) <= $maxl ) { break; } }
	$lh = $s * 1.4; $y = $bottom - count( $lines ) * $lh;
	$sp = max( $s * 0.24, rri_car_w( $s, $fg, 'A A' ) - rri_car_w( $s, $fg, 'AA' ) ); $wi = 0;
	foreach ( $lines as $i => $ln ) { $x = $x0; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.2 ); foreach ( explode( ' ', $ln ) as $wd ) { imagettftext( $im, $s, 0, (int) round( $x ) + 2, $bl + 3, imagecolorallocatealpha( $im, 0, 0, 0, 70 ), $fg, $wd ); imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fg, $wd ); $x += rri_car_w( $s, $fg, $wd ) + $sp; $wi++; } }
	return (int) $y;
}

/** história real (motivacional): foto em tela cheia com faixas pretas de cinema em cima e embaixo */
function rri_car_capa_historia( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 72; $top = 150; $bot = 470;
	$black = imagecolorallocate( $im, 8, 10, 9 );
	imagefilledrectangle( $im, 0, 0, $W, $H, $black );
	$tmp = imagecreatetruecolor( $W, $H - $top - $bot + 120 ); if ( $ph ) { rri_car_cover_rect( $tmp, $ph, 0, 0, $W, imagesy( $tmp ), 0.3 ); }
	imagecopy( $im, $tmp, 0, $top, 0, 0, $W, imagesy( $tmp ) ); imagedestroy( $tmp );
	rri_car_grad( $im, $H - $bot - 200, $H - $bot + 120, 127, 0, array( 8, 10, 9 ) );
	imagefilledrectangle( $im, 0, $H - $bot + 120, $W, $H, $black );
	imagefilledrectangle( $im, 0, 0, $W, $top, $black );
	rri_car_logo( $im, 44, 160 );
	$fx = rri_car_font( 'xbold' ); $tag = mb_strtoupper( trim( (string) ( $car['chamada'] ?? 'História real' ) ) );
	$tw = rri_car_track_w( 22, $fx, $tag, 4 ); rri_car_track( $im, 22, $W - $M - $tw, 92, $cols['acc'], $fx, $tag, 4 );
	$y = rri_car_hook_up( $im, (string) ( $car['gancho'] ?? '' ), $M, $H - 150, $W - 2 * $M, array( 58, 54, 50, 46 ), $cols, 4 );
	imagefilledrectangle( $im, $M, $H - 124, $M + 110, $H - 118, $cols['acc'] );
	$cred = trim( (string) ( $ph['credit'] ?? '' ) );
	if ( $cred ) { $fr = rri_car_font( 'reg' ); $cw = rri_car_w( 15, $fr, $cred ); imagettftext( $im, 15, 0, $W - $M - $cw, $H - 50, imagecolorallocatealpha( $im, 255, 255, 255, 60 ), $fr, $cred ); }
	return $im;
}

/** curiosidades: três fotos lado a lado e a pergunta embaixo */
function rri_car_capa_trio( $im, $pid, $car, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 72;
	$fotos = array( $ph );
	foreach ( (array) ( $car['capa_extras'] ?? array() ) as $ref ) { $p2 = rri_car_photo( $pid, $ref ); if ( $p2 ) { $fotos[] = $p2; } }
	$fotos = array_slice( array_filter( $fotos ), 0, 3 );
	$n = max( 1, count( $fotos ) ); $cw = (int) ceil( $W / $n ); $ph_h = 980;
	foreach ( $fotos as $i => $f ) { rri_car_cover_rect( $im, $f, $i * $cw, 0, $cw, $ph_h, 0.35 ); if ( $i ) { imagefilledrectangle( $im, $i * $cw - 3, 0, $i * $cw + 2, $ph_h, imagecolorallocate( $im, 8, 10, 9 ) ); } }
	rri_car_grad( $im, 0, 200, 60, 127 );
	rri_car_grad( $im, 560, $ph_h, 127, 0, array( 8, 10, 9 ) );
	imagefilledrectangle( $im, 0, $ph_h, $W, $H, imagecolorallocate( $im, 8, 10, 9 ) );
	rri_car_logo( $im, 58, 170 );
	$ch = mb_strtoupper( trim( (string) ( $car['chamada'] ?? 'Curiosidades' ) ) );
	$fx = rri_car_font( 'xbold' ); $tw = rri_car_track_w( 22, $fx, $ch, 4 ); rri_car_track( $im, 22, $W - $M - $tw, 102, $cols['acc'], $fx, $ch, 4 );
	/* pergunta na fonte da marca (Brim) em caixa alta, com ==destaque== em verde */
	list( $g, $flags ) = rri_car_flags( (string) ( $car['gancho'] ?? '' ) ); $g = mb_strtoupper( $g );
	$fb = rri_car_font( 'brim' ); $max = $W - 2 * $M;
	foreach ( array( 76, 70, 64, 58, 52 ) as $s ) { $lines = rri_car_wrap( $s, $fb, $g, $max ); if ( count( $lines ) <= 3 ) { break; } }
	$lh = $s * 1.3; $y = $H - 190 - count( $lines ) * $lh;
	$sp = max( $s * 0.22, rri_car_w( $s, $fb, 'A A' ) - rri_car_w( $s, $fb, 'AA' ) ); $wi = 0;
	foreach ( $lines as $i => $ln ) { $x = $M; $bl = (int) ( $y + ( $i + 1 ) * $lh - $s * 0.15 ); foreach ( explode( ' ', $ln ) as $wd ) { imagettftext( $im, $s, 0, (int) round( $x ), $bl, ! empty( $flags[ $wi ] ) ? $cols['acc'] : $cols['txt'], $fb, $wd ); $x += rri_car_w( $s, $fb, $wd ) + $sp; $wi++; } }
	rri_car_pill( $im, $M, $H - 110, 'ARRASTA PARA VER', $cols['acc'], $cols['deep'] );
	return $im;
}

/** item de lista de curiosidades: foto em tela cheia, posição, nome, detalhe e o valor grande */
function rri_car_item( $im, $pid, $car, $sl, $ph, $cols ) {
	$W = RRI_CAR_W; $H = RRI_CAR_H; $M = 72;
	if ( $ph ) { rri_car_cover( $im, $ph, 0.4 ); }
	rri_car_grad( $im, 0, 200, 60, 127 );
	rri_car_grad( $im, 640, $H, 127, 0, array( 8, 10, 9 ) );
	rri_car_logo( $im, 58, 150 );
	$fx = rri_car_font( 'xbold' ); $fb = rri_car_font( 'brim' ); $fg = rri_car_font( 'bold' );
	$y = $H - 200;
	$val = (string) ( $sl['valor'] ?? '' ); $vs = 92; while ( $vs > 50 && rri_car_w( $vs, $fb, $val ) > $W - 2 * $M ) { $vs -= 4; }
	if ( $val ) { imagettftext( $im, $vs, 0, $M, $y, $cols['acc'], $fb, $val ); $y -= $vs + 24; }
	$nome = (string) ( $sl['nome'] ?? '' ); $ns = 50; while ( $ns > 30 && rri_car_w( $ns, $fg, $nome ) > $W - 2 * $M ) { $ns -= 2; }
	if ( $nome ) { imagettftext( $im, $ns, 0, $M + 2, $y + 3, imagecolorallocatealpha( $im, 0, 0, 0, 70 ), $fg, $nome ); imagettftext( $im, $ns, 0, $M, $y, $cols['txt'], $fg, $nome ); $y -= $ns + 26; }
	$rot = mb_strtoupper( trim( ( ! empty( $sl['posicao'] ) ? $sl['posicao'] . '  ·  ' : '' ) . (string) ( $sl['detalhe'] ?? '' ) ) );
	if ( $rot ) { $rs = 22; while ( $rs > 15 && rri_car_track_w( $rs, $fx, $rot, 2 ) > $W - 2 * $M ) { $rs--; } rri_car_track( $im, $rs, $M, $y, imagecolorallocatealpha( $im, 255, 255, 255, 25 ), $fx, $rot, 2 ); }
	if ( ! empty( $sl['fonte'] ) ) { $fr = rri_car_font( 'reg' ); imagettftext( $im, 16, 0, $M, $H - 120, imagecolorallocatealpha( $im, 255, 255, 255, 55 ), $fr, 'Fonte: ' . $sl['fonte'] ); }
	rri_car_credit( $im, $cols, $ph['credit'] ?? '' );
	return $im;
}
