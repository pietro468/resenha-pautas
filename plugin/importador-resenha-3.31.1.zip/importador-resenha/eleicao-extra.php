<?php
/**
 * Eleições 2026: "Quem está na sua urna" (candidatos), "Tira-dúvidas do eleitor" (guia),
 * botão "Eleições 2026" no topo e página inicial do período eleitoral.
 *
 * Os dados dos candidatos são gerados todo dia no GitHub (ferramentas/candidatos.py)
 * a partir dos dados abertos do TSE e ficam em candidatos/2026/ no repositório.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RRI_EL_PERIODO_FIM', '2026-10-26 00:00' ); // depois do 2º turno
define( 'RRI_EL_RAW', 'https://raw.githubusercontent.com/pietro468/resenha-pautas/main/candidatos/2026/' );

/** período eleitoral: botões, candidatos e guia no ar */
function rri_el_periodo() {
	$m = rri_el_opt()['modo'];
	if ( 'desligado' === $m ) { return false; }
	if ( 'ligado' === $m ) { return true; }
	return time() < rri_el_ts( RRI_EL_PERIODO_FIM );
}

/* ---------- dados dos candidatos (cópia guardada em arquivo) ---------- */
function rri_el_cache_dir() {
	$u = wp_upload_dir();
	$d = trailingslashit( $u['basedir'] ) . 'rr-eleicao';
	if ( ! is_dir( $d ) ) { wp_mkdir_p( $d ); @file_put_contents( $d . '/index.html', '' ); } // phpcs:ignore
	return $d;
}
/** baixa candidatos/2026/{nome}.json do GitHub no máximo a cada 3 horas */
function rri_el_arquivo( $nome ) {
	$nome = preg_replace( '/[^a-z\/]/', '', strtolower( $nome ) );
	$f    = rri_el_cache_dir() . '/' . str_replace( '/', '-', $nome ) . '.json';
	$novo = file_exists( $f ) && ( time() - filemtime( $f ) ) < 3 * HOUR_IN_SECONDS;
	if ( ! $novo && ! get_transient( 'rri_ela_' . md5( $nome ) ) ) {
		set_transient( 'rri_ela_' . md5( $nome ), 1, 5 * MINUTE_IN_SECONDS );
		$r = wp_remote_get( RRI_EL_RAW . $nome . '.json?t=' . time(), array( 'timeout' => 30 ) );
		if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) {
			$b = wp_remote_retrieve_body( $r );
			if ( is_array( json_decode( $b, true ) ) ) { @file_put_contents( $f, $b ); } // phpcs:ignore
		} elseif ( file_exists( $f ) ) {
			@touch( $f, time() - 2 * HOUR_IN_SECONDS ); // phpcs:ignore -- tenta de novo em 1 hora
		}
	}
	return file_exists( $f ) ? (string) file_get_contents( $f ) : ''; // phpcs:ignore
}
function rri_el_uf_ok( $uf ) {
	$uf = strtolower( preg_replace( '/[^a-z]/i', '', (string) $uf ) );
	return in_array( $uf, array( 'br', 'ac', 'al', 'ap', 'am', 'ba', 'ce', 'df', 'es', 'go', 'ma', 'mt', 'ms', 'mg', 'pa', 'pb', 'pr', 'pe', 'pi', 'rj', 'rn', 'rs', 'ro', 'rr', 'sc', 'sp', 'se', 'to' ), true ) ? $uf : '';
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'rri/v1', '/candidatos', array(
		'methods' => 'GET', 'permission_callback' => '__return_true',
		'callback' => function ( $r ) {
			$uf = rri_el_uf_ok( $r['uf'] );
			if ( ! $uf ) { return new WP_REST_Response( array( 'ok' => false ), 400 ); }
			$b = rri_el_arquivo( $uf );
			if ( ! $b ) { return new WP_REST_Response( array( 'ok' => false, 'erro' => 'A lista de candidatos ainda está sendo preparada. Tente de novo em alguns minutos.' ) ); }
			$res = new WP_REST_Response( json_decode( $b, true ) );
			$res->header( 'Cache-Control', 'public, max-age=600' );
			return $res;
		},
	) );
	register_rest_route( 'rri/v1', '/candidato', array(
		'methods' => 'GET', 'permission_callback' => '__return_true',
		'callback' => function ( $r ) {
			$uf = rri_el_uf_ok( $r['uf'] );
			$sq = preg_replace( '/\D/', '', (string) $r['sq'] );
			if ( ! $uf || ! $sq ) { return new WP_REST_Response( array( 'ok' => false ), 400 ); }
			$ck = 'rri_elp_' . $uf . $sq;
			$p  = get_transient( $ck );
			if ( false === $p ) {
				$all = json_decode( rri_el_arquivo( 'perfil/' . $uf ), true );
				$p   = $all['p'][ $sq ] ?? array( 'bens' => array(), 'hist' => array(), 'doad' => array(), 'forn' => array() );
				set_transient( $ck, $p, HOUR_IN_SECONDS );
			}
			$res = new WP_REST_Response( array( 'ok' => true, 'p' => $p ) );
			$res->header( 'Cache-Control', 'public, max-age=600' );
			return $res;
		},
	) );
} );

/* ---------- páginas /candidatos/ e /guia-do-eleitor/ ---------- */
function rri_el_rota() {
	$p = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' ); // phpcs:ignore
	$h = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $h && 0 === strpos( $p, $h ) ) { $p = trim( substr( $p, strlen( $h ) ), '/' ); }
	return $p;
}
function rri_el_pagina_virtual( $titulo, $desc ) {
	global $wp_query;
	$wp_query->is_404 = false;
	status_header( 200 );
	add_filter( 'pre_get_document_title', function () use ( $titulo ) { return $titulo . ' | Resenha Rentável'; }, 99 );
	add_filter( 'wpseo_title', function () use ( $titulo ) { return $titulo . ' | Resenha Rentável'; }, 99 );
	add_filter( 'wpseo_metadesc', function () use ( $desc ) { return $desc; }, 99 );
	add_filter( 'wpseo_robots', function () { return 'index, follow'; }, 99 );
	add_filter( 'body_class', function ( $c ) { return array_diff( $c, array( 'error404' ) ); } );
	add_action( 'wp_head', function () use ( $desc ) { echo '<meta name="description" content="' . esc_attr( $desc ) . '">'; }, 1 );
}
add_action( 'template_redirect', function () {
	$rota = rri_el_rota();
	if ( 'candidatos' === $rota && 'desligado' !== rri_el_opt()['modo'] ) {
		rri_el_pagina_virtual( 'Quem está na sua urna: os candidatos de 2026', 'Todos os candidatos a presidente, governador, senador e deputado em 2026: foto, número, partido, bens declarados, candidaturas anteriores e dinheiro da campanha. Dados do TSE.' );
		get_header();
		rri_el_assets();
		$v = (string) filemtime( __DIR__ . '/assets/candidatos.js' );
		echo '<script src="' . esc_url( plugin_dir_url( __FILE__ ) . 'assets/candidatos.js?v=' . $v ) . '" defer></script>';
		?>
<main id="conteudo" class="rrel rrel-ap rrel-cand">
  <section class="ap-head"><div class="wrap">
    <span class="tag">Eleições 2026</span>
    <h1>Quem está na sua urna</h1>
    <p>Todos os candidatos de 2026, com foto e número. Toque em um nome para ver o que ele declarou de bens, onde já concorreu e de onde vem o dinheiro da campanha.</p>
  </div></section>
  <div class="controls"><div class="wrap">
    <div class="tabs" role="tablist" aria-label="Cargo" id="cd-tabs"></div>
    <div class="where">
      <label for="cd-uf">Estado</label>
      <select id="cd-uf"></select>
      <div class="csearch in"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 2a8 8 0 0 1 6.32 12.9l5.39 5.4-1.41 1.4-5.4-5.39A8 8 0 1 1 10 2zm0 2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z"/></svg><input id="cd-q" type="search" autocomplete="off" placeholder="Nome, número ou partido" aria-label="Buscar candidato"></div>
    </div>
  </div></div>
  <section class="ap-body"><div class="wrap cd-grid-wrap">
    <aside class="cd-filtros" id="cd-filtros" aria-label="Filtros"></aside>
    <div class="cd-main">
      <div class="cd-bar"><b id="cd-count"></b><label>Ordenar por <select id="cd-ord">
        <option value="nome">Nome (A a Z)</option><option value="n">Número</option><option value="p">Partido</option><option value="bens">Maior patrimônio</option><option value="rec">Mais arrecadou</option>
      </select></label><button type="button" class="chip cd-fbtn" id="cd-fbtn">Filtros</button></div>
      <div class="cd-cards" id="cd-cards"><div class="nores">Carregando…</div></div>
      <button type="button" class="more" id="cd-more" hidden>Ver mais</button>
      <p class="fonte">Dados: TSE (dados abertos, atualizados todo dia). Fotos e números oficiais da Justiça Eleitoral.</p>
    </div>
  </div></section>
  <div class="cd-perfil" id="cd-perfil" hidden role="dialog" aria-modal="true" aria-label="Dados do candidato"></div>
</main>
		<?php
		get_footer();
		exit;
	}
	if ( 'guia-do-eleitor' === $rota && 'desligado' !== rri_el_opt()['modo'] ) {
		rri_el_pagina_virtual( 'Tira-dúvidas do eleitor 2026', 'Horário, documentos, ordem dos votos na urna, como justificar, multa, colinha e o que pode no dia da eleição de 4 de outubro de 2026. Tudo com fonte oficial.' );
		get_header();
		rri_el_assets();
		include __DIR__ . '/eleicao-guia.php';
		get_footer();
		exit;
	}
}, 2 );

/* ---------- botão "Eleições 2026" no topo ---------- */
add_action( 'wp_body_open', function () {
	if ( ! rri_el_periodo() || rri_el_modo() ) { return; } // no dia 4 tudo já está na tela
	$dia   = rri_el_modo();
	$antes = rri_el_antes();
	$ap    = $antes ? 'A partir de 4/10, às 17h' : 'Ao vivo agora';
	?>
<div class="rrel-elbar" id="rrel-elbar"><div class="wrap">
  <button type="button" class="rrel-elbtn" aria-expanded="false" aria-controls="rrel-elmenu"><span class="dot" aria-hidden="true"></span>Eleições 2026<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg></button>
  <div class="rrel-elmenu" id="rrel-elmenu" hidden>
    <a href="<?php echo esc_url( home_url( '/candidatos/' ) ); ?>"><b>Quem está na sua urna</b><span>Todos os candidatos, com foto, número, bens e dinheiro da campanha</span></a>
    <a href="<?php echo esc_url( home_url( '/guia-do-eleitor/' ) ); ?>"><b>Tira-dúvidas do eleitor</b><span>Horário, documentos, ordem dos votos, justificativa e o que pode no dia</span></a>
    <a href="<?php echo esc_url( home_url( '/apuracao/' ) ); ?>"><b>Apuração em tempo real</b><span><?php echo esc_html( $ap ); ?>, do Brasil até a sua cidade</span></a>
  </div>
</div></div>
<style>
.rrel-elbar{background:#fff;border-bottom:1px solid #e1e8e4;position:relative;z-index:25}
.rrel-elbar .wrap{display:flex;justify-content:flex-end;padding-block:6px;position:relative}
.rrel-elbtn{display:inline-flex;align-items:center;gap:8px;border:0;background:none;font:700 14px var(--ui,system-ui);color:#163327;cursor:pointer;padding:6px 4px;border-radius:8px}
.rrel-elbtn:hover{color:#33755a}
.rrel-elbtn .dot{width:8px;height:8px;border-radius:50%;background:<?php echo ( $dia && ! $antes ) ? '#d93a2f' : '#2f8a63'; ?>;display:inline-block}
.rrel-elbtn svg{width:16px;height:16px;fill:#33755a}
.rrel-elmenu{position:absolute;right:clamp(16px,4vw,40px);top:calc(100% + 4px);width:min(360px,calc(100vw - 32px));background:#fff;border:1px solid #e1e8e4;border-radius:14px;box-shadow:0 16px 40px rgba(19,34,27,.16);padding:8px;display:grid;gap:4px}
.rrel-elmenu[hidden]{display:none}
.rrel-elmenu a{display:grid;gap:2px;padding:12px 12px;border-radius:10px;color:#13221b}
.rrel-elmenu a:hover{background:#e4efe8}
.rrel-elmenu b{font-size:15px}
.rrel-elmenu span{font-size:13px;color:#62736b}
</style>
<script>
document.addEventListener('DOMContentLoaded',function(){var bar=document.getElementById('rrel-elbar'),top=document.querySelector('header.top');
if(top&&top.parentNode){top.parentNode.insertBefore(bar,top.nextSibling);}
var b=bar.querySelector('.rrel-elbtn'),m=document.getElementById('rrel-elmenu');
b.addEventListener('click',function(e){e.stopPropagation();m.hidden=!m.hidden;b.setAttribute('aria-expanded',!m.hidden);});
document.addEventListener('click',function(e){if(!bar.contains(e.target)){m.hidden=true;b.setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){m.hidden=true;b.setAttribute('aria-expanded','false');}});
});
</script>
	<?php
}, 5 );
