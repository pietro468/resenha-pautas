<?php
/* Caixa "Trocar capa" no editor do post: busca fotos e troca a imagem destacada com um clique */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rri_capa', 'Trocar capa por outra foto', 'rri_capa_box', 'post', 'side', 'default' );
} );

function rri_capa_box( $post ) {
	$k = rri_keys();
	if ( ! $k['pexels'] && ! $k['pixabay'] ) {
		echo '<p>Para buscar fotos aqui, coloque as chaves grátis do Pexels e do Pixabay em <a href="' . esc_url( admin_url( 'tools.php?page=rr-importador' ) ) . '">Ferramentas, Importar artigos Resenha</a>.</p>';
		return;
	}
	$q = (string) get_post_meta( $post->ID, '_rri_busca', true );
	if ( ! $q ) { $q = rri_en_query( (string) get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true ) ?: $post->post_title ); }
	?>
	<p style="margin-top:0">Busque em bancos de fotos gratuitos e clique na foto para usar como capa. Dica: busque em inglês.</p>
	<p style="display:flex;gap:6px"><input type="text" id="rri_q" value="<?php echo esc_attr( $q ); ?>" style="flex:1"><button type="button" class="button" id="rri_qbtn">Buscar</button></p>
	<div id="rri_grid" style="display:grid;grid-template-columns:1fr 1fr;gap:6px"></div>
	<p id="rri_qmsg" style="margin-bottom:0"></p>
	<script>
	(function(){
		var btn = document.getElementById("rri_qbtn"), grid = document.getElementById("rri_grid"), msg = document.getElementById("rri_qmsg"), q = document.getElementById("rri_q");
		var nonce = "<?php echo esc_js( wp_create_nonce( 'rri_capa' ) ); ?>", pid = <?php echo (int) $post->ID; ?>;
		function post(data){ var fd = new FormData(); for(var k in data) fd.append(k, data[k]); fd.append("_wpnonce", nonce); fd.append("post_id", pid); return fetch(ajaxurl, {method:"POST", body:fd, credentials:"same-origin"}).then(function(r){ return r.json(); }); }
		function search(){
			grid.innerHTML = ""; msg.textContent = "Buscando...";
			post({action:"rri_capa_busca", q:q.value}).then(function(j){
				if(!j.success || !j.data.length){ msg.textContent = "Nada encontrado. Tente outras palavras, em inglês."; return; }
				msg.textContent = "Clique numa foto para usar.";
				j.data.forEach(function(c){
					var b = document.createElement("button"); b.type = "button"; b.title = c.credit;
					b.style.cssText = "padding:0;border:2px solid transparent;border-radius:6px;overflow:hidden;cursor:pointer;background:#eee;aspect-ratio:16/10";
					var im = document.createElement("img"); im.src = c.thumb; im.alt = ""; im.style.cssText = "width:100%;height:100%;object-fit:cover;display:block";
					b.appendChild(im); grid.appendChild(b);
					b.addEventListener("click", function(){
						msg.textContent = "Trocando a capa..."; b.style.borderColor = "#2271b1";
						post({action:"rri_capa_usar", url:c.url, credit:c.credit}).then(function(r){
							if(!r.success){ msg.textContent = "Não consegui baixar essa foto. Tente outra."; return; }
							msg.innerHTML = "<strong>Capa trocada.</strong> Clique em Atualizar/Salvar para confirmar.";
							try { if(window.wp && wp.data && wp.data.dispatch("core/editor")) wp.data.dispatch("core/editor").editPost({featured_media: r.data.id}); } catch(e) {}
						});
					});
				});
			});
		}
		btn.addEventListener("click", search);
		q.addEventListener("keydown", function(e){ if(e.key === "Enter"){ e.preventDefault(); search(); } });
	})();
	</script>
	<?php
}

add_action( 'wp_ajax_rri_capa_busca', function () {
	check_ajax_referer( 'rri_capa' );
	$pid = (int) ( $_POST['post_id'] ?? 0 );
	if ( ! current_user_can( 'edit_post', $pid ) ) { wp_send_json_error(); }
	$q = sanitize_text_field( wp_unslash( $_POST['q'] ?? '' ) );
	$p = get_post( $pid );
	$c = rri_candidates( array( 'titulo' => $p->post_title, 'frase_chave' => get_post_meta( $pid, '_yoast_wpseo_focuskw', true ), 'tags' => wp_get_post_tags( $pid, array( 'fields' => 'names' ) ) ), $q, 18 );
	wp_send_json_success( array_map( function ( $x ) { return array( 'url' => $x['url'], 'thumb' => $x['thumb'] ?? $x['url'], 'credit' => $x['credit'] ); }, $c ) );
} );

add_action( 'wp_ajax_rri_capa_usar', function () {
	check_ajax_referer( 'rri_capa' );
	$pid = (int) ( $_POST['post_id'] ?? 0 );
	if ( ! current_user_can( 'edit_post', $pid ) || ! current_user_can( 'upload_files' ) ) { wp_send_json_error(); }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$url = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( ! preg_match( '/(^|\.)(pexels\.com|pixabay\.com|wikimedia\.org|staticflickr\.com|flickr\.com|openverse\.org)$/', (string) $host ) ) { wp_send_json_error(); }
	$p = get_post( $pid );
	$aid = rri_sideload_url( $url, sanitize_title( $p->post_title ) . '-capa.jpg', $pid, $p->post_title );
	if ( is_wp_error( $aid ) ) { wp_send_json_error(); }
	update_post_meta( $aid, '_wp_attachment_image_alt', $p->post_title );
	wp_update_post( array( 'ID' => $aid, 'post_excerpt' => 'Foto: ' . sanitize_text_field( wp_unslash( $_POST['credit'] ?? '' ) ) ) );
	set_post_thumbnail( $pid, $aid );
	update_post_meta( $pid, '_rri_manual_cover', 1 );
	wp_send_json_success( array( 'id' => $aid ) );
} );
