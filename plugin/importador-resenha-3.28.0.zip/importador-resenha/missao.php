<?php
/**
 * Missão 2026: página escondida com os inscritos do canal em tempo real e o progresso até as 3 metas do ano.
 * Abre em resenharentavel.com/?missao=CHAVE (a chave aparece em Ferramentas > Missão 2026) ou para o administrador logado.
 * O site guarda um retrato por dia dos números do canal para mostrar o ritmo e a projeção.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RRI_MISSAO_METAS', array( array( 'Pessimista', 35000 ), array( 'Realista', 50000 ), array( 'Otimista', 100000 ) ) );
define( 'RRI_MISSAO_FIM', '2026-12-31 23:59:59' ); // horário de Brasília
define( 'RRI_MISSAO_VIDEOS', 29 ); // vídeos longos publicados no canal (sem Shorts) até o fim do ano

function rri_missao_token() {
	$t = get_option( 'rri_missao_token' );
	if ( ! $t ) { $t = wp_generate_password( 24, false, false ); update_option( 'rri_missao_token', $t, false ); }
	return $t;
}
function rri_missao_link() { return add_query_arg( 'missao', rri_missao_token(), home_url( '/' ) ); }

/** busca os números do canal (no máximo a cada 30 minutos) e guarda um retrato por dia */
function rri_missao_coleta( $forcar = false ) {
	if ( ! defined( 'RR_YT_KEY' ) || ! defined( 'RR_YT_HANDLE' ) ) { return; }
	if ( ! $forcar && get_transient( 'rri_missao_lock' ) ) { return; }
	set_transient( 'rri_missao_lock', 1, 30 * MINUTE_IN_SECONDS );
	$r = wp_remote_get( 'https://www.googleapis.com/youtube/v3/channels?part=statistics&forHandle=' . rawurlencode( RR_YT_HANDLE ) . '&key=' . rawurlencode( RR_YT_KEY ), array( 'timeout' => 15, 'headers' => array( 'Referer' => home_url( '/' ) ) ) );
	if ( is_wp_error( $r ) ) { return; }
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	$s = $j['items'][0]['statistics'] ?? null;
	if ( ! $s || ! isset( $s['subscriberCount'] ) ) { return; }
	$hist = (array) get_option( 'rri_missao_hist', array() );
	$dia  = wp_date( 'Y-m-d' );
	$lv   = function_exists( 'rri_channel_videos' ) ? rri_channel_videos() : array();
	$lv   = is_array( $lv ) ? count( $lv ) : 0; // vídeos longos (sem Shorts e sem lives)
	$hist[ $dia ] = array( 's' => (int) $s['subscriberCount'], 'v' => (int) ( $s['viewCount'] ?? 0 ), 'n' => (int) ( $s['videoCount'] ?? 0 ), 'lv' => $lv, 't' => time() );
	/* anota o dia em que cada meta foi batida (uma vez só) */
	$bat = (array) get_option( 'rri_missao_batidas', array() );
	foreach ( RRI_MISSAO_METAS as $m ) { if ( (int) $s['subscriberCount'] >= $m[1] && empty( $bat[ 's' . $m[1] ] ) ) { $bat[ 's' . $m[1] ] = $dia; } }
	if ( $lv >= RRI_MISSAO_VIDEOS && empty( $bat['videos'] ) ) { $bat['videos'] = $dia; }
	update_option( 'rri_missao_batidas', $bat, false );
	ksort( $hist );
	update_option( 'rri_missao_hist', array_slice( $hist, -400, null, true ), false );
}
add_action( 'rri_depois_da_busca', 'rri_missao_coleta' );

/** atalho no painel: Ferramentas > Missão 2026 */
add_action( 'admin_menu', function () {
	add_management_page( 'Missão 2026', 'Missão 2026', 'manage_options', 'rri-missao', function () {
		$l = rri_missao_link();
		echo '<div class="wrap"><h1>Missão 2026</h1><p>Página escondida com os inscritos em tempo real e o progresso até as metas. Só abre com este link (não aparece no site nem no Google):</p>';
		echo '<p><input type="text" readonly value="' . esc_attr( $l ) . '" style="width:100%;max-width:720px" onclick="this.select()"></p>';
		echo '<p><a class="button button-primary" href="' . esc_url( $l ) . '" target="_blank">Abrir a página</a></p>';
		echo '<p>Mande esse link só para quem pode ver. Se ele vazar, clique em trocar a chave e o link antigo para de funcionar.</p>';
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=rri_missao_nova' ), 'rri_missao_nova' );
		echo '<p><a class="button" href="' . esc_url( $u ) . '">Trocar a chave</a></p></div>';
	} );
} );
add_action( 'admin_post_rri_missao_nova', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'rri_missao_nova' );
	delete_option( 'rri_missao_token' ); rri_missao_token();
	wp_safe_redirect( admin_url( 'tools.php?page=rri-missao' ) ); exit;
} );

add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['missao'] ) ) { return; }
	$ok = current_user_can( 'manage_options' ) || hash_equals( rri_missao_token(), (string) wp_unslash( $_GET['missao'] ) );
	if ( ! $ok ) { return; } // sem a chave, o site segue normal
	if ( ! get_option( 'rri_missao_hist' ) || isset( $_GET['atualizar'] ) ) { rri_missao_coleta( true ); }
	nocache_headers();
	header( 'X-Robots-Tag: noindex, nofollow', true );
	rri_missao_pagina();
	exit;
} );

function rri_missao_pagina() {
	$hist  = (array) get_option( 'rri_missao_hist', array() );
	$dados = array(
		'metas'  => RRI_MISSAO_METAS,
		'mvid'   => RRI_MISSAO_VIDEOS,
		'bat'    => (object) get_option( 'rri_missao_batidas', array() ),
		'fim'    => ( new DateTime( RRI_MISSAO_FIM, new DateTimeZone( 'America/Sao_Paulo' ) ) )->getTimestamp() * 1000,
		'hist'   => $hist,
		'key'    => defined( 'RR_YT_KEY' ) ? RR_YT_KEY : '',
		'handle' => defined( 'RR_YT_HANDLE' ) ? RR_YT_HANDLE : '',
	);
	$fonte = get_template_directory_uri() . '/assets/fonts/brim-combined.woff2';
	$logo  = plugins_url( 'assets/logo-branco.png', __FILE__ );
	$simb  = plugins_url( 'assets/simbolo.png', __FILE__ );
	?><!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Missão 2026</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
@font-face{font-family:"Brim";src:url(<?php echo esc_url( $fonte ); ?>) format("woff2");font-display:swap}
:root{--bg1:#0c1f17;--bg2:#050f0b;--card:rgba(255,255,255,.045);--line:rgba(255,255,255,.09);--txt:#eaf3ee;--dim:#8fa89b;--acc:#7ee0a3;--warn:#f2c46b;--c1:#9fb8ab;--c2:#7ee0a3;--c3:#f2c46b}
*{box-sizing:border-box}html,body{margin:0;overflow-x:hidden}html{background:#050f0b}
body{min-height:100vh;background:radial-gradient(1200px 700px at 80% -10%,#1d4a37 0,transparent 60%),linear-gradient(180deg,var(--bg1),var(--bg2));background-attachment:fixed;color:var(--txt);font-family:"IBM Plex Sans",system-ui,sans-serif;-webkit-font-smoothing:antialiased}
.fx{position:fixed;inset:0;overflow:hidden;pointer-events:none}
.fx::before{content:"";position:absolute;inset:0;background-image:linear-gradient(var(--line) 1px,transparent 1px),linear-gradient(90deg,var(--line) 1px,transparent 1px);background-size:64px 64px;opacity:.25;-webkit-mask-image:linear-gradient(180deg,#000,transparent 70%);mask-image:linear-gradient(180deg,#000,transparent 70%)}
.fx img{position:absolute;right:-120px;bottom:-140px;width:620px;opacity:.05}
.w{position:relative;max-width:1100px;margin:0 auto;padding:28px 20px 60px}
.top{display:flex;align-items:center;justify-content:space-between;gap:16px}
.top img{height:40px}
.live{display:inline-flex;align-items:center;gap:8px;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim)}
.live i{width:8px;height:8px;border-radius:50%;background:var(--acc);animation:p 1.8s infinite}
@keyframes p{0%{box-shadow:0 0 0 0 rgba(126,224,163,.6)}70%{box-shadow:0 0 0 10px rgba(126,224,163,0)}100%{box-shadow:0 0 0 0 rgba(126,224,163,0)}}
.tag{margin-top:40px;font-size:12px;font-weight:600;letter-spacing:.24em;text-transform:uppercase;color:var(--acc)}
h1{font-family:"Brim",Georgia,serif;font-weight:400;font-size:clamp(46px,9vw,100px);line-height:.92;margin:10px 0 6px}
.sub{color:var(--dim);font-size:16px;margin:0}
.box{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:24px;min-width:0}
.hero{margin-top:34px;display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:22px}
.big{font-family:"Brim",Georgia,serif;font-size:clamp(56px,9vw,108px);line-height:.9;color:#fff}
.lbl{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--dim);margin-top:10px}
.track{position:relative;margin:40px 0 44px;height:14px;border-radius:999px;background:rgba(255,255,255,.07)}
.track .fill{position:absolute;left:0;top:0;bottom:0;border-radius:999px;background:linear-gradient(90deg,#2f8a63,var(--acc));box-shadow:0 0 22px rgba(126,224,163,.35);width:0;transition:width 1.6s cubic-bezier(.2,.8,.2,1)}
.flag{position:absolute;top:-9px;width:2px;height:32px;background:var(--c)}
.flag b{position:absolute;bottom:34px;left:50%;transform:translateX(-50%);font-size:11px;letter-spacing:.08em;color:var(--c);white-space:nowrap;font-weight:600}
.flag.ok{box-shadow:0 0 12px var(--c)}
.flag:last-child b{left:auto;right:0;transform:none}
.flag.baixo b{bottom:auto;top:36px}
.cd{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:14px}
.cd div{background:rgba(0,0,0,.25);border:1px solid var(--line);border-radius:14px;padding:14px 6px;text-align:center}
.cd b{display:block;font-family:"Brim",Georgia,serif;font-weight:400;font-size:clamp(34px,5vw,56px);line-height:1;color:#fff;font-variant-numeric:tabular-nums}
.cd span{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--dim)}
.cdt{font-size:13px;color:var(--dim);margin-top:14px;line-height:1.5}
h2{font-size:12px;letter-spacing:.2em;text-transform:uppercase;color:var(--acc);margin:0 0 14px;font-weight:600}
.sec{margin-top:34px}
.metas{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.meta{position:relative;border-top:3px solid var(--c)}
.meta.main{background:rgba(126,224,163,.07);border-color:var(--c)}
.meta .nm{font-size:12px;letter-spacing:.2em;text-transform:uppercase;color:var(--c);font-weight:600}
.meta .alvo{font-family:"Brim",Georgia,serif;font-size:56px;line-height:1;margin:8px 0 2px;color:#fff}
.meta .pc{display:flex;align-items:baseline;gap:8px;margin-top:12px}.meta .pc b{font-family:"Brim",Georgia,serif;font-weight:400;font-size:34px;color:var(--c)}.meta .pc span{color:var(--dim);font-size:13px}
.mbar{height:8px;border-radius:999px;background:rgba(255,255,255,.07);margin-top:8px;overflow:hidden}.mbar i{display:block;height:100%;width:0;background:var(--c);border-radius:999px;transition:width 1.6s cubic-bezier(.2,.8,.2,1)}
.falta{margin-top:12px;font-size:14px;color:var(--txt)}
.rit{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:14px}
.rit div{background:rgba(0,0,0,.22);border-radius:10px;padding:10px 8px;text-align:center}
.rit b{display:block;font-family:"Brim",Georgia,serif;font-weight:400;font-size:22px;color:#fff;line-height:1.1}
.rit span{font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim)}
.st{margin-top:12px;font-size:13px;line-height:1.45;color:var(--dim)}.st.ok{color:var(--acc)}.st.no{color:var(--warn)}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.k{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim)}
.v{font-family:"Brim",Georgia,serif;font-size:38px;line-height:1.05;margin-top:8px;color:#fff}
.d{font-size:13px;color:var(--dim);margin-top:4px}
#graf{width:100%;height:240px;display:block}
.leg{display:flex;flex-wrap:wrap;gap:16px;font-size:12.5px;color:var(--dim);margin-top:10px}.leg i{display:inline-block;width:18px;height:2px;margin-right:6px;vertical-align:middle;background:var(--c)}
.vid{--c:#7ee0a3}.vrow{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.2fr);gap:20px;align-items:center}
.alvo2{font-family:"Brim",Georgia,serif;font-size:64px;line-height:1;color:#fff}.alvo2 small{font-size:34px;color:var(--dim)}
.data{display:inline-block;margin-top:10px;font-size:12px;font-weight:600;letter-spacing:.08em;color:#07140e;background:var(--c);border-radius:999px;padding:4px 10px}
#fogos{position:fixed;inset:0;pointer-events:none;z-index:50}
.banner{display:none;margin-top:24px;padding:14px 18px;border-radius:14px;background:rgba(126,224,163,.12);border:1px solid rgba(126,224,163,.4);font-size:15px}
@media (max-width:860px){.vrow{grid-template-columns:minmax(0,1fr)}}
.foot{margin-top:28px;color:var(--dim);font-size:12.5px;line-height:1.6}
@media (max-width:860px){.hero,.metas{grid-template-columns:minmax(0,1fr)}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.box{padding:18px}.v{font-size:30px}}
</style></head><body>
<canvas id="fogos"></canvas>
<div class="fx"><img src="<?php echo esc_url( $simb ); ?>" alt=""></div>
<div class="w">
	<div class="top"><img src="<?php echo esc_url( $logo ); ?>" alt="Resenha Rentável"><span class="live"><i></i><span id="upd">ao vivo</span></span></div>
	<div class="tag">Missão do ano</div>
	<h1>MISSÃO 2026</h1>
	<p class="sub">35 mil, 50 mil ou 100 mil inscritos e 29 vídeos no canal até 31 de dezembro de 2026.</p>
	<div class="banner" id="banner"></div>

	<div class="hero">
		<div class="box">
			<div class="big" id="subs">--</div>
			<div class="lbl">inscritos agora</div>
			<div class="track" id="track"><div class="fill" id="fill"></div></div>
			<div class="d" id="heroSt">--</div>
		</div>
		<div class="box">
			<h2>Contagem regressiva</h2>
			<div class="cd"><div><b id="cdD">--</b><span>dias</span></div><div><b id="cdH">--</b><span>horas</span></div><div><b id="cdM">--</b><span>min</span></div><div><b id="cdS">--</b><span>seg</span></div></div>
			<div class="cdt">até 31 de dezembro de 2026, às 23:59. <span id="cdW"></span></div>
		</div>
	</div>

	<div class="sec"><h2>As 3 metas de inscritos</h2><div class="metas" id="metas"></div></div>

	<div class="sec box vid" id="vidbox"><h2>Meta de vídeos</h2>
		<div class="vrow"><div><div class="alvo2"><span id="vq">--</span><small> / <span id="vm">--</span></small></div><div class="d">vídeos publicados no canal (sem contar Shorts)</div></div>
		<div class="rit" style="margin:0"><div><b id="vf">--</b><span>faltam</span></div><div><b id="vs">--</b><span>por semana</span></div><div><b id="vmes">--</b><span>por mês</span></div></div></div>
		<div class="mbar"><i id="vbar" style="width:0"></i></div><div class="st" id="vst"></div>
	</div>

	<div class="sec grid">
		<div class="box"><div class="k">Ritmo atual</div><div class="v" id="atual">--</div><div class="d" id="atuald">média por dia</div></div>
		<div class="box"><div class="k">Desde o início</div><div class="v" id="ganho">--</div><div class="d" id="ganhod">inscritos ganhos</div></div>
		<div class="box"><div class="k">Visualizações</div><div class="v" id="views">--</div><div class="d">total do canal</div></div>
		<div class="box"><div class="k">Vídeos</div><div class="v" id="videos">--</div><div class="d">publicados</div></div>
	</div>

	<div class="sec box"><h2>Evolução</h2><svg id="graf" viewBox="0 0 600 240" preserveAspectRatio="none"></svg><div class="leg" id="leg"></div></div>

	<p class="foot">O número de inscritos vem direto do YouTube e se atualiza sozinho a cada minuto. O YouTube mostra o total arredondado (por exemplo, 21.900), então ele sobe de 100 em 100. O ritmo atual usa os números que o site guarda uma vez por dia desde que esta página foi criada, e fica mais preciso com o passar dos dias.</p>
</div>
<script>
(function(){
var D=<?php echo wp_json_encode( $dados ); ?>, NF=new Intl.NumberFormat("pt-BR"), DAY=864e5, COR=["var(--c1)","var(--c2)","var(--c3)"], HEX=["#9fb8ab","#7ee0a3","#f2c46b"];
var hist=Object.keys(D.hist).sort().map(function(k){return {d:k,s:D.hist[k].s,v:D.hist[k].v,n:D.hist[k].n,lv:D.hist[k].lv||0};});
var cur=hist.length?hist[hist.length-1]:{s:0,v:0,n:0}, TOP=D.metas[D.metas.length-1][1];
function $(i){return document.getElementById(i);}
function tween(el,to){var from=+(el.dataset.v||0),t0=null;el.dataset.v=to;function st(ts){if(!t0)t0=ts;var p=Math.min((ts-t0)/1400,1),e=1-Math.pow(1-p,3);el.textContent=NF.format(Math.round(from+(to-from)*e));if(p<1)requestAnimationFrame(st);}requestAnimationFrame(st);}
function br(t){return new Date(t).toLocaleDateString("pt-BR");}
function pct(x){return x.toLocaleString("pt-BR",{minimumFractionDigits:1,maximumFractionDigits:1})+"%";}
function ritmo(){ if(hist.length<2)return null; var last=hist[hist.length-1],base=hist[0];
	for(var i=hist.length-1;i>=0;i--){ if((new Date(last.d)-new Date(hist[i].d))/DAY>=7){base=hist[i];break;} }
	var dias=(new Date(last.d)-new Date(base.d))/DAY; return dias>=1?{r:(last.s-base.s)/dias,dias:dias}:null; }
/* contagem regressiva */
function tick(){ var ms=Math.max(0,D.fim-Date.now()), d=Math.floor(ms/DAY), h=Math.floor(ms%DAY/36e5), m=Math.floor(ms%36e5/6e4), s=Math.floor(ms%6e4/1e3);
	$("cdD").textContent=d; $("cdH").textContent=("0"+h).slice(-2); $("cdM").textContent=("0"+m).slice(-2); $("cdS").textContent=("0"+s).slice(-2);
	$("cdW").textContent="São "+Math.floor(d/7)+" semanas e "+(d%7)+" dias."; }
tick(); setInterval(tick,1000);
function draw(){
	var s=cur.s, now=Date.now(), diasR=Math.max(1,(D.fim-now)/DAY), rt=ritmo();
	tween($("subs"),s);
	$("fill").style.width=Math.min(100,s/TOP*100)+"%";
	var tr=$("track"); [].slice.call(tr.querySelectorAll(".flag")).forEach(function(e){e.remove();});
	D.metas.forEach(function(m,i){var f=document.createElement("span");f.className="flag"+(s>=m[1]?" ok":"")+(i===0?" baixo":"");f.style.setProperty("--c",COR[i]);f.style.left=(m[1]/TOP*100)+"%";f.innerHTML="<b>"+m[0]+" "+(m[1]/1e3)+"K</b>";tr.appendChild(f);});
	var box=$("metas"); box.innerHTML=""; var batidas=0;
	D.metas.forEach(function(m,i){
		var alvo=m[1], falta=Math.max(0,alvo-s), p=Math.min(100,s/alvo*100), dia=Math.ceil(falta/diasR), sem=Math.ceil(falta/diasR*7), mes=Math.ceil(falta/diasR*30.44), st="", cls="";
		if(!falta||D.bat["s"+alvo]){st="Meta batida!";cls="ok";batidas++;}
		else if(!rt||rt.r<=0){st="Faltam "+NF.format(falta)+" inscritos.";}
		else{var q=now+falta/rt.r*DAY; if(q<=D.fim){st="No ritmo atual, bate em "+br(q)+".";cls="ok";}else{st="No ritmo atual, só em "+br(q)+". Precisa de +"+NF.format(Math.ceil(dia-rt.r))+" por dia.";cls="no";}}
		var el=document.createElement("div"); el.className="box meta"+(i===1?" main":""); el.style.setProperty("--c",COR[i]);
		el.innerHTML='<div class="nm">'+m[0]+(i===1?" · meta principal":"")+'</div><div class="alvo">'+(alvo/1e3)+'K</div>'+
			'<div class="pc"><b>'+pct(p)+'</b><span>concluída</span></div><div class="mbar"><i style="width:0"></i></div>'+
			'<div class="falta">'+(falta?"Faltam <b>"+NF.format(falta)+"</b> inscritos":"<b>Conquistada</b>")+'</div>'+
			'<div class="rit"><div><b>'+NF.format(dia)+'</b><span>por dia</span></div><div><b>'+NF.format(sem)+'</b><span>por semana</span></div><div><b>'+NF.format(mes)+'</b><span>por mês</span></div></div>'+
			'<div class="st '+cls+'">'+st+'</div>'+(D.bat["s"+alvo]?'<span class="data">Batida em '+br(new Date(D.bat["s"+alvo]+"T12:00:00"))+'</span>':'');
		box.appendChild(el); (function(bar,w){setTimeout(function(){bar.style.width=w+"%";},60);})(el.querySelector(".mbar i"),p);
	});
	var real=D.metas[1][1];
	$("heroSt").textContent=pct(Math.min(100,s/real*100))+" da meta realista ("+(real/1e3)+"K) · "+batidas+" de 3 metas batidas";
	if(!rt){$("atual").textContent="--";$("atuald").textContent="coletando dados (precisa de 2 dias)";}
	else{$("atual").textContent=(rt.r>=0?"+":"")+NF.format(Math.round(rt.r));$("atuald").textContent="por dia (média dos últimos "+Math.round(rt.dias)+" dias)";}
	var g=hist[0]?s-hist[0].s:0; $("ganho").textContent=(g>=0?"+":"")+NF.format(g); $("ganhod").textContent=hist[0]?"inscritos desde "+br(new Date(hist[0].d+"T12:00:00")):"inscritos ganhos";
	tween($("views"),cur.v); tween($("videos"),cur.n);
	/* meta de vídeos (conta do servidor, sem Shorts) */
	var lv=hist.length?(hist[hist.length-1].lv||0):0, mv=D.mvid, fv=Math.max(0,mv-lv), sem=diasR/7, meses=diasR/30.44;
	$("vq").textContent=lv; $("vm").textContent=mv; $("vf").textContent=fv;
	$("vs").textContent=(fv/sem).toLocaleString("pt-BR",{maximumFractionDigits:1}); $("vmes").textContent=(fv/meses).toLocaleString("pt-BR",{maximumFractionDigits:1});
	$("vbar").style.width=Math.min(100,lv/mv*100)+"%";
	$("vst").className="st"+(D.bat.videos||!fv?" ok":"");
	$("vst").innerHTML=D.bat.videos?'Meta batida! <span class="data">Batida em '+br(new Date(D.bat.videos+"T12:00:00"))+'</span>':(fv?"Faltam "+fv+" vídeos: um vídeo a cada "+Math.max(1,Math.floor(diasR/fv))+" dias até 31/12.":"Meta batida!");
	/* gráfico */
	var svg=$("graf"), pts=hist.map(function(h){return {t:new Date(h.d+"T12:00:00").getTime(),s:h.s};});
	if(!pts.length||pts[pts.length-1].s!==s)pts.push({t:now,s:s});
	var t0=pts[0].t, t1=D.fim, lo=Math.min(pts[0].s,s)*0.9, hi=TOP*1.04;
	function X(t){return (t-t0)/(t1-t0||1)*600;} function Y(v){return 230-(v-lo)/(hi-lo)*220;}
	var lp=pts[pts.length-1], html="";
	D.metas.forEach(function(m,i){html+='<line x1="0" x2="600" y1="'+Y(m[1])+'" y2="'+Y(m[1])+'" stroke="'+HEX[i]+'" stroke-opacity=".35" stroke-dasharray="4 6"/>'+
		'<line x1="'+X(lp.t)+'" y1="'+Y(lp.s)+'" x2="600" y2="'+Y(m[1])+'" stroke="'+HEX[i]+'" stroke-opacity=".3" stroke-dasharray="2 5"/>';});
	html+='<path d="'+pts.map(function(p,i){return (i?"L":"M")+X(p.t).toFixed(1)+" "+Y(p.s).toFixed(1);}).join(" ")+'" fill="none" stroke="#fff" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/><circle cx="'+X(lp.t)+'" cy="'+Y(lp.s)+'" r="5" fill="#fff"/>';
	svg.innerHTML=html;
	$("leg").innerHTML='<span><i style="--c:#fff"></i>inscritos</span>'+D.metas.map(function(m,i){return '<span><i style="--c:'+HEX[i]+'"></i>'+m[0]+' '+(m[1]/1e3)+'K</span>';}).join("")+'<span>pontilhado: caminho até 31/12</span>';
}
function load(){ if(!D.key)return;
	fetch("https://www.googleapis.com/youtube/v3/channels?part=statistics&forHandle="+encodeURIComponent(D.handle)+"&key="+D.key)
	.then(function(r){return r.json();}).then(function(j){var x=j.items&&j.items[0]&&j.items[0].statistics;if(!x)return;
		cur={s:+x.subscriberCount,v:+x.viewCount,n:+x.videoCount};draw();
		$("upd").textContent="ao vivo · "+new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"});}).catch(function(){});}
draw(); load(); setInterval(load,60000);
/* fogos: toda vez que a página abre, por 5 segundos, depois que alguma meta foi batida */
(function(){
	var nomes={videos:"29 vídeos"}; D.metas.forEach(function(m){nomes["s"+m[1]]=m[0]+" "+(m[1]/1e3)+"K";});
	var ks=Object.keys(D.bat||{}); if(!ks.length)return;
	ks.sort(function(a,b){return D.bat[a]<D.bat[b]?-1:1;});
	var ult=ks[ks.length-1], bn=$("banner"); bn.style.display="block";
	bn.innerHTML="🎆 Meta "+(nomes[ult]||ult)+" batida em "+br(new Date(D.bat[ult]+"T12:00:00"))+". "+(ks.length>1?ks.length+" metas batidas até agora.":"");
	if(window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches)return;
	var c=$("fogos"), x=c.getContext("2d"), W, H, ps=[], t0=performance.now(), cores=["#7ee0a3","#f2c46b","#ffffff","#9fe7ff","#ff9f7a"];
	function rs(){W=c.width=innerWidth*devicePixelRatio;H=c.height=innerHeight*devicePixelRatio;c.style.width=innerWidth+"px";c.style.height=innerHeight+"px";} rs(); addEventListener("resize",rs);
	function boom(){var cx=W*(.15+Math.random()*.7), cy=H*(.12+Math.random()*.4), cor=cores[Math.floor(Math.random()*cores.length)], n=70;
		for(var i=0;i<n;i++){var a=Math.PI*2*i/n, v=(2+Math.random()*4)*devicePixelRatio; ps.push({x:cx,y:cy,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1,c:cor});}}
	var prox=0;
	function f(now){var t=now-t0; x.globalCompositeOperation="destination-out"; x.fillStyle="rgba(0,0,0,.18)"; x.fillRect(0,0,W,H); x.globalCompositeOperation="lighter";
		if(t<4200&&now>prox){boom();prox=now+280+Math.random()*320;}
		ps=ps.filter(function(p){p.x+=p.vx;p.y+=p.vy;p.vy+=.05*devicePixelRatio;p.vx*=.985;p.vy*=.985;p.l-=.012;
			if(p.l>0){x.globalAlpha=p.l;x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,2.2*devicePixelRatio,0,7);x.fill();}return p.l>0;});
		x.globalAlpha=1;
		if(t<5000||ps.length){requestAnimationFrame(f);}else{x.clearRect(0,0,W,H);c.remove();}}
	requestAnimationFrame(f);
})();
})();
</script>
</body></html><?php
}
